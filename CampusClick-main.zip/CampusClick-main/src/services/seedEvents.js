import { createEvent } from './eventService';
import { toast } from 'react-toastify';

const DUMMY_EVENTS = [
    // CAMPUS EVENTS (Unified)
    // Upcoming
    {
        title: "Neon Nights Cultural Fest",
        description: "An electrifying evening of music, dance, and art under the stars. Join us for the biggest cultural extravaganza of the year!",
        type: "cultural",
        category: "cultural_fest",
        startDate: new Date(Date.now() + 86400000 * 5).toISOString(), // +5 days
        endDate: new Date(Date.now() + 86400000 * 5 + 14400000).toISOString(),
        bannerUrl: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=800&q=80",
        venue: "University Main Ground",
        coordinatorName: "Sarah J.",
        coordinatorPhone: "+91 98765 00001"
    },
    {
        title: "Abstract Art Exhibition",
        description: "Showcasing the finest abstract pieces from our talented student artists. A journey through colors and emotions.",
        type: "cultural",
        category: "exhibition",
        startDate: new Date(Date.now() + 86400000 * 10).toISOString(), // +10 days
        endDate: new Date(Date.now() + 86400000 * 12).toISOString(),
        bannerUrl: "https://images.unsplash.com/photo-1547891654-e66ed7ebb968?auto=format&fit=crop&w=800&q=80",
        venue: "Art Gallery, Block B",
        coordinatorName: "Amit R.",
        coordinatorPhone: "+91 98765 00002"
    },
    // Ongoing
    {
        title: "Voice of Campus Debate",
        description: "The preliminary rounds are live! Come witness the sharpest minds battle it out on stage.",
        type: "cultural",
        category: "seminar",
        startDate: new Date(Date.now() - 3600000).toISOString(), // -1 hour
        endDate: new Date(Date.now() + 7200000).toISOString(), // +2 hours
        bannerUrl: "https://images.unsplash.com/photo-1475721027767-f424029558d4?auto=format&fit=crop&w=800&q=80",
        venue: "Auditorium 1",
        coordinatorName: "Priya M.",
        coordinatorPhone: "+91 98765 00003"
    },
    {
        title: "Street Food Carnival",
        description: "Taste the flavors of India right here on campus. Stalls are open till late night!",
        type: "cultural",
        category: "cultural_fest",
        startDate: new Date(Date.now() - 7200000).toISOString(),
        endDate: new Date(Date.now() + 18000000).toISOString(),
        bannerUrl: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=800&q=80",
        venue: "Cafeteria Lawns",
        coordinatorName: "Chef Raj",
        coordinatorPhone: "+91 98765 00004"
    },
    // Past
    {
        title: "Classical Music Night",
        description: "A soulful rendition of classical ragas by the Music Society.",
        type: "cultural",
        category: "live_show",
        startDate: new Date(Date.now() - 86400000 * 10).toISOString(),
        endDate: new Date(Date.now() - 86400000 * 10 + 7200000).toISOString(),
        bannerUrl: "https://images.unsplash.com/photo-1511192336575-5a79af67a629?auto=format&fit=crop&w=800&q=80",
        venue: "Mini Auditorium",
        coordinatorName: "Anjali K.",
        coordinatorPhone: "+91 98765 00005"
    },

    // TECH HUB
    // Upcoming
    {
        title: "CodeWars 2025 Hackathon",
        description: "24-hour non-stop coding marathon. Build, Deploy, Win. Grand prizes worth 50k!",
        type: "tech",
        category: "hackathon",
        startDate: new Date(Date.now() + 86400000 * 7).toISOString(),
        endDate: new Date(Date.now() + 86400000 * 8).toISOString(),
        bannerUrl: "https://images.unsplash.com/photo-1504384308090-c54be38558ad?auto=format&fit=crop&w=800&q=80",
        venue: "Tech Park Labs",
        coordinatorName: "Dev Team",
        coordinatorPhone: "+91 99999 88888"
    },
    {
        title: "AI & ML Workshop",
        description: "Hands-on session on building Neural Networks from scratch using TensorFlow.",
        type: "tech",
        category: "workshop",
        startDate: new Date(Date.now() + 86400000 * 3).toISOString(),
        endDate: new Date(Date.now() + 86400000 * 3 + 10800000).toISOString(),
        bannerUrl: "https://images.unsplash.com/photo-1555255707-c07966088b7b?auto=format&fit=crop&w=800&q=80",
        venue: "Computer Lab 4",
        coordinatorName: "Prof. AI",
        coordinatorPhone: "+91 99999 77777"
    },
    // Ongoing
    {
        title: "Bug Bounty Hunt",
        description: "Find vulnerabilities in the tested sandbox environment. Leaderboard is live!",
        type: "tech",
        category: "quiz",
        startDate: new Date(Date.now() - 3600000).toISOString(),
        endDate: new Date(Date.now() + 86400000).toISOString(),
        bannerUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80",
        venue: "Online / Server Room",
        coordinatorName: "CyberSec Club",
        coordinatorPhone: "+91 00000 11111"
    },
    // Past
    {
        title: "Web3 Webinar",
        description: "Introduction to Blockchain and Decentralized Apps.",
        type: "tech",
        category: "webinar",
        startDate: new Date(Date.now() - 86400000 * 5).toISOString(),
        endDate: new Date(Date.now() - 86400000 * 5 + 3600000).toISOString(),
        bannerUrl: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=800&q=80",
        venue: "Google Meet",
        coordinatorName: "Blockchain SIG",
        coordinatorPhone: "+91 12312 31231"
    }
];

export const seedDatabase = async () => {
    if (!window.confirm("ARNING: This will create duplicates if run multiple times. Proceed to seed data?")) return;
    
    let count = 0;
    for (const event of DUMMY_EVENTS) {
        try {
            await createEvent(event, null);
            count++;
        } catch (error) {
            console.error("Failed to seed event:", event.title, error);
        }
    }
    toast.success(`Seeding Complete! Added ${count} events.`);
    window.location.reload(); 
};
