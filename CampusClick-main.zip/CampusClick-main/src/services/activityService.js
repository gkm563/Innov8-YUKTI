import { collection, addDoc, getDocs, query, where, limit, serverTimestamp } from "firebase/firestore";
import { db } from "./firebase";

// Collection Name
const ACTIVITY_COLLECTION = "activities";

/**
 * Log a user activity
 * @param {string} userId - UID of the user
 * @param {string} userName - Display name of the user
 * @param {string} action - 'LOGIN', 'UPLOAD', 'DELETE', 'UPDATE', 'LOGOUT'
 * @param {string} details - Human readable description (e.g., "Uploaded photo 'Sunset'")
 * @param {object} metadata - Extra data (e.g., postId, fileUrl, ip - optional)
 */
export const logActivity = async (userId, userName, action, details, metadata = {}) => {
    try {
        await addDoc(collection(db, ACTIVITY_COLLECTION), {
            userId,
            userName,
            action,
            details,
            metadata,
            timestamp: serverTimestamp()
        });
    } catch (error) {
        console.error("Error logging activity:", error);
        // Silent fail to not disrupt user flow
    }
};

/**
 * Get activities for a specific user (for User Dashboard)
 * @param {string} userId 
 * @param {number} limitCount 
 * @returns {Promise<Array>}
 */
export const getUserActivity = async (userId, limitCount = 50) => {
    try {
        const q = query(
            collection(db, ACTIVITY_COLLECTION),
            where("userId", "==", userId),
            limit(limitCount)
        );
        const snapshot = await getDocs(q);
        const activities = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

        // Client-side sort to avoid composite index requirement
        return activities.sort((a, b) => {
            const timeA = a.timestamp?.seconds || 0;
            const timeB = b.timestamp?.seconds || 0;
            return timeB - timeA;
        });
    } catch (error) {
        console.error("Error fetching user activity:", error);
        return [];
    }
};

/**
 * Get ALL activities (for Admin Dashboard)
 * @param {number} limitCount 
 * @returns {Promise<Array>}
 */
export const getAllActivities = async (limitCount = 100) => {
    try {
        const q = query(
            collection(db, ACTIVITY_COLLECTION),
            limit(limitCount)
        );
        const snapshot = await getDocs(q);
        const activities = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

        // Client-side sort
        return activities.sort((a, b) => {
            const timeA = a.timestamp?.seconds || 0;
            const timeB = b.timestamp?.seconds || 0;
            return timeB - timeA;
        });
    } catch (error) {
        console.error("Error fetching all activities:", error);
        return [];
    }
};
