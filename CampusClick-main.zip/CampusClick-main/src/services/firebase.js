import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyDVTO--_LgjsFpB3ogVSX6efDqjrSQvAn8",
  authDomain: "gkm563.firebaseapp.com",
  projectId: "gkm563",
  storageBucket: "gkm563.firebasestorage.app",
  messagingSenderId: "210090399116",
  appId: "1:210090399116:web:1dd1151c2423e6cfd2f2a9",
  measurementId: "G-9S74RZ2LW2"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Export services
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;
