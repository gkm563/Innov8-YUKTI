import { GoogleGenerativeAI } from "@google/generative-ai";

const API_KEY = import.meta.env.VITE_GEMINI_API_KEY;

let genAI = null;
let model = null;

if (API_KEY) {
  genAI = new GoogleGenerativeAI(API_KEY);
  model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
} else {
  console.warn("VITE_GEMINI_API_KEY is missing. AI features will not work.");
}

/**
 * Analyzes an image using Gemini 1.5 Flash.
 * @param {File} imageFile - The image file to analyze.
 * @returns {Promise<{safe: boolean, caption: string, category: string, reason?: string}>}
 */
export const analyzeImage = async (imageFile) => {
  if (!model) {
    throw new Error("Gemini API Key is missing.");
  }

  try {
    // Convert file to base64
    const base64Data = await fileToGenerativePart(imageFile);

    const prompt = `Analyze this image for a college community platform. 
    Strictly check for: Nudity, Sexual Content, Violence, Weapons/Explosives, Hate Symbols, or Gore.
    
    Provide a JSON response with this EXACT structure:
    {
      "caption": "A creative, engaging caption for the memory.",
      "category": "One of: Sports, Cultural, Academic, Hostel Diaries, Fest & Events, or Other",
      "isSafe": boolean, // Set to false if ANY prohibited content is detected.
      "reason": "If isSafe is false, clearly state the reason (e.g., 'Contains weapons'). If safe, leave empty."
    }
    Return ONLY raw JSON. Do not include markdown formatting.`;

    const result = await model.generateContent([prompt, base64Data]);
    const response = await result.response;
    const text = response.text();

    // Clean up markdown code blocks if present
    const cleanText = text.replace(/```json|```/g, "").trim();

    return JSON.parse(cleanText);

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw new Error("Failed to analyze image: " + error.message);
  }
};

async function fileToGenerativePart(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result.split(',')[1];
      resolve({
        inlineData: {
          data: base64String,
          mimeType: file.type
        }
      });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
