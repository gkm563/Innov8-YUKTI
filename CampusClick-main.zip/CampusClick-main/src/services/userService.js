import { db } from './firebase';
import { doc, updateDoc, arrayUnion, arrayRemove, getDoc, setDoc } from 'firebase/firestore';

// Save or Unsave an event for a user
export const toggleSaveEvent = async (userId, eventId) => {
    if (!userId || !eventId) throw new Error("Missing userId or eventId");

    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);

    if (userSnap.exists()) {
        const userData = userSnap.data();
        const savedEvents = userData.savedEvents || [];
        const isSaved = savedEvents.includes(eventId);

        if (isSaved) {
            await updateDoc(userRef, {
                savedEvents: arrayRemove(eventId)
            });
            return false; // Result is NOT saved
        } else {
            await updateDoc(userRef, {
                savedEvents: arrayUnion(eventId)
            });
            return true; // Result is SAVED
        }
    } else {
        // Create user doc if it doesn't exist (though it should)
        await setDoc(userRef, {
            savedEvents: [eventId]
        }, { merge: true });
        return true;
    }
};

// Check if an event is saved
export const isEventSaved = async (userId, eventId) => {
    if (!userId || !eventId) return false;
    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);
    if (userSnap.exists()) {
        const data = userSnap.data();
        return data.savedEvents?.includes(eventId) || false;
    }
    return false;
};
