import { db, storage } from './firebase';
import { collection, addDoc, getDocs, doc, deleteDoc, updateDoc, query, orderBy, Timestamp, arrayUnion, arrayRemove, increment, getDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';

const EVENTS_COLLECTION = 'events';

// Utility to calculate status based on dates
export const getEventStatus = (startDate, endDate) => {
    const now = new Date();
    const start = startDate instanceof Timestamp ? startDate.toDate() : new Date(startDate);
    const end = endDate instanceof Timestamp ? endDate.toDate() : new Date(endDate);

    if (now < start) return 'Upcoming';
    if (now >= start && now <= end) return 'Ongoing';
    return 'Past';
};

export const createEvent = async (eventData, bannerFile) => {
    try {
        let bannerUrl = eventData.bannerUrl || '';
        if (bannerFile) {
            const storageRef = ref(storage, `event_banners/${Date.now()}_${bannerFile.name}`);
            await uploadBytes(storageRef, bannerFile);
            bannerUrl = await getDownloadURL(storageRef);
        }

        const docRef = await addDoc(collection(db, EVENTS_COLLECTION), {
            ...eventData,
            bannerUrl,
            likes: [],
            views: 0,
            createdAt: Timestamp.now(),
            startDate: Timestamp.fromDate(new Date(eventData.startDate)),
            endDate: Timestamp.fromDate(new Date(eventData.endDate))
        });
        return docRef.id;
    } catch (error) {
        throw error;
    }
};

export const getEvents = async () => {
    try {
        const q = query(collection(db, EVENTS_COLLECTION), orderBy('startDate', 'asc'));
        const snapshot = await getDocs(q);
        return snapshot.docs.map(doc => {
            const data = doc.data();
            return {
                id: doc.id,
                ...data,
                likes: data.likes || [],
                views: data.views || 0, // Ensure views is a number
                // Handle potential missing dates safely
                status: (data.startDate && data.endDate) ? getEventStatus(data.startDate, data.endDate) : 'Upcoming'
            };
        });

    } catch (error) {
        console.error("Error fetching events:", error);
        throw error; // Rethrow so UI knows it failed
    }
};

export const deleteEvent = async (eventId) => {
    try {
        await deleteDoc(doc(db, EVENTS_COLLECTION, eventId));
    } catch (error) {
        throw error;
    }
};

export const updateEvent = async (eventId, updatedData) => {
    try {
        // Handle date conversions if they are regular strings coming from inputs
        const finalData = { ...updatedData };
        if (finalData.startDate) finalData.startDate = Timestamp.fromDate(new Date(finalData.startDate));
        if (finalData.endDate) finalData.endDate = Timestamp.fromDate(new Date(finalData.endDate));

        await updateDoc(doc(db, EVENTS_COLLECTION, eventId), finalData);
    } catch (error) {
        throw error;
    }
};

export const toggleLikeEvent = async (eventId, userId) => {
    try {
        const eventRef = doc(db, EVENTS_COLLECTION, eventId);
        const eventSnap = await getDoc(eventRef);

        if (eventSnap.exists()) {
            const eventData = eventSnap.data();
            const likes = eventData.likes || [];

            if (likes.includes(userId)) {
                await updateDoc(eventRef, {
                    likes: arrayRemove(userId)
                });
                return false; // Not liked anymore
            } else {
                await updateDoc(eventRef, {
                    likes: arrayUnion(userId)
                });
                return true; // Liked
            }
        }
    } catch (error) {
        console.error("Error toggling like:", error);
        throw error;
    }
};

export const incrementEventViews = async (eventId) => {
    try {
        const eventRef = doc(db, EVENTS_COLLECTION, eventId);
        await updateDoc(eventRef, {
            views: increment(1)
        });
    } catch (error) {
        console.error("Error incrementing views:", error);
    }
};
