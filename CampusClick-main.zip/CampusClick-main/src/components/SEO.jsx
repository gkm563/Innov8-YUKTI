import React from 'react';
import { Helmet } from 'react-helmet-async';

const SEO = ({ title, description, image, url }) => {
    const siteTitle = "CampusClick | The Living Campus Archive";
    const defaultDescription = "Preserving the legacy of our university with AI-powered archiving. Join the community to share and explore campus memories.";
    const defaultImage = "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80";
    const siteUrl = "https://campusclick.web.app"; // Replace with actual URL

    return (
        <Helmet>
            <title>{title ? `${title} | CampusClick` : siteTitle}</title>
            <meta name="description" content={description || defaultDescription} />
            <meta property="og:title" content={title || siteTitle} />
            <meta property="og:description" content={description || defaultDescription} />
            <meta property="og:image" content={image || defaultImage} />
            <meta property="og:url" content={url || siteUrl} />
            <meta name="twitter:card" content="summary_large_image" />
        </Helmet>
    );
};

export default SEO;
