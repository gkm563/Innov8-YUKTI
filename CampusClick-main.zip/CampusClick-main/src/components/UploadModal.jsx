import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Upload, Camera, Sparkles, Loader2, Link as LinkIcon, Calendar, Tag } from 'lucide-react';
import { analyzeImage } from '../services/gemini';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import Button from './ui/Button';
import Card from './ui/Card';

const UploadModal = ({ isOpen, onClose, postToEdit, onUploadStart }) => {
    const { user } = useAuth();
    const [file, setFile] = useState(null);
    const [preview, setPreview] = useState(null);
    const [caption, setCaption] = useState('');
    const [category, setCategory] = useState('Campus Life');
    const [year, setYear] = useState(new Date().getFullYear());
    const [linkedin, setLinkedin] = useState('');
    const [analyzing, setAnalyzing] = useState(false);

    useEffect(() => {
        if (postToEdit) {
            setCaption(postToEdit.caption || '');
            setCategory(postToEdit.category || 'Campus Life');
            setYear(postToEdit.year || new Date().getFullYear());
            setLinkedin(postToEdit.linkedin || '');
            setPreview(postToEdit.imageUrl || null);
            setFile(null);
        } else {
            setCaption('');
            setCategory('Campus Life');
            setYear(new Date().getFullYear());
            setLinkedin('');
            setPreview(null);
            setFile(null);
        }
    }, [postToEdit, isOpen]);

    if (!isOpen) return null;

    const handleFileChange = (e) => {
        const selected = e.target.files[0];
        if (selected) {
            setFile(selected);
            setPreview(URL.createObjectURL(selected));
            if (!postToEdit) setCaption('');
        }
    };

    const handleMagicAnalysis = async () => {
        if (!file && !postToEdit?.imageUrl) {
            toast.error("Please select an image first!");
            return;
        }

        if (!file) {
            toast.info("AI Magic mostly works on new uploads. Try uploading a new photo!");
            return;
        }

        setAnalyzing(true);
        try {
            const result = await analyzeImage(file);
            if (result) {
                setCaption(result.caption || '');
                if (['Sports', 'Cultural', 'Academic', 'Other', 'Hostel', 'Event'].includes(result.category)) {
                    setCategory(result.category);
                }
                toast.success("AI Magic: Analysis Complete! ✨");
            }
        } catch (error) {
            console.error(error);
            toast.error("AI Analysis failed. Try manual entry.");
        } finally {
            setAnalyzing(false);
        }
    };

    const handleUploadSubmit = (e) => {
        e.preventDefault();

        if (!file && !preview) {
            toast.error("Please select a photo.");
            return;
        }

        // Prepare metadata
        const metadata = {
            caption,
            category,
            year: parseInt(year),
            linkedin: linkedin || null,
        };

        // Delegate to parent
        if (onUploadStart) {
            onUploadStart(file, metadata, postToEdit);
            onClose(); // Close immediately to show background progress
        }
    };

    return (
        <AnimatePresence>
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md"
                onClick={onClose}
            >
                <motion.div
                    initial={{ scale: 0.95, opacity: 0, y: 20 }}
                    animate={{ scale: 1, opacity: 1, y: 0 }}
                    exit={{ scale: 0.95, opacity: 0, y: 20 }}
                    transition={{ type: "spring", duration: 0.5, bounce: 0.3 }}
                    className="w-full max-w-lg"
                    onClick={(e) => e.stopPropagation()}
                >
                    <Card className="overflow-hidden border-surface-200 dark:border-surface-700 bg-surface-50 dark:bg-surface-900 shadow-2xl">
                        <div className="p-5 border-b border-surface-200 dark:border-surface-700 flex justify-between items-center bg-white dark:bg-surface-800">
                            <h2 className="text-xl font-bold font-display text-surface-900 dark:text-white flex items-center gap-2">
                                <Camera className="text-primary-500" /> {postToEdit ? 'Edit Memory' : 'Share Memory'}
                            </h2>
                            <Button
                                onClick={onClose}
                                variant="ghost"
                                size="sm"
                                className="!p-2 rounded-full hover:bg-surface-100 dark:hover:bg-surface-700"
                            >
                                <X size={20} className="text-surface-500" />
                            </Button>
                        </div>

                        <form onSubmit={handleUploadSubmit} className="p-6 space-y-5">
                            {/* Image Upload Area */}
                            <div className="relative group">
                                <input
                                    type="file"
                                    accept="image/*"
                                    onChange={handleFileChange}
                                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                                />
                                <div className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center transition-all duration-300 ${preview ? 'border-primary-500 bg-primary-50/50 dark:bg-primary-900/10' : 'border-surface-300 dark:border-surface-600 hover:border-primary-400 hover:bg-surface-100 dark:hover:bg-surface-800'}`}>
                                    {preview ? (
                                        <div className="relative w-full h-48">
                                            <img src={preview} alt="Preview" className="w-full h-full object-contain rounded-lg shadow-sm" />
                                            <div className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg backdrop-blur-sm">
                                                <p className="text-white font-bold flex items-center gap-2"><Camera size={18} /> Change Photo</p>
                                            </div>
                                        </div>
                                    ) : (
                                        <>
                                            <div className="w-16 h-16 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center text-primary-600 dark:text-primary-400 mb-4 group-hover:scale-110 transition-transform">
                                                <Upload size={28} />
                                            </div>
                                            <p className="text-sm text-surface-900 dark:text-surface-200 font-bold">Click to upload photo</p>
                                            <p className="text-xs text-surface-500 mt-1">JPG, PNG up to 10MB</p>
                                        </>
                                    )}
                                </div>
                            </div>

                            {/* Caption Field with AI Magic Button */}
                            <div>
                                <div className="flex justify-between items-center mb-2">
                                    <label className="text-xs font-bold text-surface-500 uppercase tracking-wider">Caption</label>
                                    <button
                                        type="button"
                                        onClick={handleMagicAnalysis}
                                        disabled={analyzing || (!file && !postToEdit)}
                                        className="text-xs flex items-center gap-1.5 bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white px-3 py-1 rounded-full hover:shadow-lg hover:shadow-primary-500/25 disabled:opacity-50 disabled:shadow-none transition-all font-semibold"
                                    >
                                        {analyzing ? <Loader2 className="animate-spin w-3 h-3" /> : <Sparkles className="w-3 h-3" />}
                                        {analyzing ? 'Magic Working...' : 'AI Magic'}
                                    </button>
                                </div>
                                <textarea
                                    value={caption}
                                    onChange={(e) => setCaption(e.target.value)}
                                    className="w-full px-4 py-3 rounded-xl border border-surface-200 dark:border-surface-700 bg-white dark:bg-surface-800 text-surface-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none text-sm transition-shadow shadow-sm focus:shadow-md resize-none"
                                    placeholder="Describe this moment... or let AI do it!"
                                    rows="3"
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs font-bold text-surface-500 uppercase tracking-wider mb-2">Category</label>
                                    <div className="relative">
                                        <Tag className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-400 w-4 h-4" />
                                        <select
                                            value={category}
                                            onChange={(e) => setCategory(e.target.value)}
                                            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-surface-200 dark:border-surface-700 bg-white dark:bg-surface-800 text-surface-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none text-sm appearance-none"
                                        >
                                            <option>Campus Life</option>
                                            <option>Convocation</option>
                                            <option>Fest & Events</option>
                                            <option>Hostel Diaries</option>
                                            <option>Sports</option>
                                            <option>Alumni Meet</option>
                                            <option>Other</option>
                                        </select>
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-surface-500 uppercase tracking-wider mb-2">Year</label>
                                    <div className="relative">
                                        <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-400 w-4 h-4" />
                                        <input
                                            type="number"
                                            value={year}
                                            onChange={(e) => setYear(e.target.value)}
                                            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-surface-200 dark:border-surface-700 bg-white dark:bg-surface-800 text-surface-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none text-sm"
                                            min="1990"
                                            max="2030"
                                        />
                                    </div>
                                </div>
                            </div>

                            <div>
                                <label className="block text-xs font-bold text-surface-500 uppercase tracking-wider mb-2">LinkedIn (Optional)</label>
                                <div className="relative">
                                    <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-400 w-4 h-4" />
                                    <input
                                        type="url"
                                        value={linkedin}
                                        onChange={(e) => setLinkedin(e.target.value)}
                                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-surface-200 dark:border-surface-700 bg-white dark:bg-surface-800 text-surface-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none text-sm"
                                        placeholder="https://linkedin.com/in/..."
                                    />
                                </div>
                            </div>

                            <Button
                                type="submit"
                                className="w-full shadow-lg shadow-primary-500/20"
                                icon={<Upload size={20} />}
                            >
                                {postToEdit ? 'Update Memory' : 'Upload Memory'}
                            </Button>
                        </form>
                    </Card>
                </motion.div>
            </motion.div>
        </AnimatePresence>
    );
};

export default UploadModal;
