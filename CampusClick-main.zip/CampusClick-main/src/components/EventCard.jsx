import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Calendar, MapPin, ArrowRight, Eye, Heart, Bookmark, Image as ImageIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { doc, updateDoc, arrayUnion, arrayRemove } from 'firebase/firestore';
import { db } from '../services/firebase';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import { toggleLikeEvent, incrementEventViews } from '../services/eventService';
import Card from './ui/Card';
import Button from './ui/Button';

const EventCard = ({ event, onExploreGallery }) => {
    const isTech = event.type === 'tech';

    // Theme Configuration using Semantic Colors
    const theme = isTech ? {
        badge: 'bg-primary-500/10 text-primary-600 dark:text-primary-400 border-primary-500/20',
        button: 'primary',
    } : {
        badge: 'bg-secondary-500/10 text-secondary-600 dark:text-secondary-400 border-secondary-500/20',
        button: 'secondary',
    };

    const StatusBadge = ({ status }) => {
        const colors = {
            'Upcoming': 'bg-info/10 text-info border-info/20',
            'Ongoing': 'bg-success/10 text-success border-success/20 animate-pulse',
            'Past': 'bg-surface-500/10 text-surface-500 border-surface-500/20'
        };
        return (
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border backdrop-blur-md ${colors[status]}`}>
                {status}
            </span>
        );
    };

    const { user, userData } = useAuth();
    const [isSaved, setIsSaved] = useState(false);

    useEffect(() => {
        if (userData?.savedEvents) {
            setIsSaved(userData.savedEvents.includes(event.id));
        }
    }, [userData, event.id]);

    const handleSave = async (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!user) {
            toast.info("Login to save events");
            return;
        }

        const newSavedState = !isSaved;
        setIsSaved(newSavedState); // Optimistic UI

        try {
            const userRef = doc(db, 'users', user.uid);
            await updateDoc(userRef, {
                savedEvents: newSavedState ? arrayUnion(event.id) : arrayRemove(event.id)
            });
            toast.success(newSavedState ? "Event saved!" : "Event removed from saved.");
        } catch (error) {
            console.error(error);
            setIsSaved(!newSavedState); // Revert
            toast.error("Failed to update saved events");
        }
    };
    const navigate = useNavigate();

    const [likesCount, setLikesCount] = useState(event.likes?.length || 0);
    const [isLiked, setIsLiked] = useState(user && event.likes?.includes(user.uid));
    const [viewsCount, setViewsCount] = useState(event.views || 0);
    const [likeLoading, setLikeLoading] = useState(false);

    useEffect(() => {
        if (user && event.likes) {
            setIsLiked(event.likes.includes(user.uid));
        } else {
            setIsLiked(false);
        }
    }, [user, event.likes]);

    const handleLike = async (e) => {
        e.stopPropagation();
        if (!user) {
            toast.info("Please login to like events!");
            return;
        }
        if (likeLoading) return;

        setLikeLoading(true);
        const newIsLiked = !isLiked;
        setIsLiked(newIsLiked);
        setLikesCount(prev => newIsLiked ? prev + 1 : prev - 1);

        try {
            await toggleLikeEvent(event.id, user.uid);
        } catch (error) {
            setIsLiked(!newIsLiked);
            setLikesCount(prev => !newIsLiked ? prev + 1 : prev - 1);
            toast.error("Failed to update like");
        } finally {
            setLikeLoading(false);
        }
    };

    const handleInteraction = async (e) => {
        try {
            incrementEventViews(event.id);
            setViewsCount(prev => prev + 1);
        } catch (err) {
            console.error(err);
        }

        if (!user) {
            e.preventDefault();
            toast.info("Please login to register for events!");
            navigate('/auth/login');
            return;
        }
        if (!event.registrationLink) {
            e.preventDefault();
            toast.info("Registration details coming soon!");
        }
    };

    const formatDate = (date) => {
        if (!date) return 'TBA';
        const d = date.toDate ? date.toDate() : new Date(date);
        return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    };

    return (
        <Card
            hoverEffect={true}
            className="h-full flex flex-col group border-surface-200 dark:border-surface-700 overflow-hidden"
        >
            {/* Banner Image */}
            <div className="h-48 overflow-hidden relative">
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent z-10" />
                <img
                    src={event.bannerUrl}
                    alt={event.title}
                    className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4 z-20">
                    <StatusBadge status={event.status} />
                </div>
                <div className="absolute top-4 right-4 z-20">
                    <button
                        onClick={handleSave}
                        className={`p-2 rounded-full backdrop-blur-md transition-all duration-300 ${isSaved ? 'bg-primary-500 text-white shadow-lg shadow-primary-500/50' : 'bg-black/20 text-white hover:bg-black/40'}`}
                    >
                        <Bookmark size={18} fill={isSaved ? "currentColor" : "none"} />
                    </button>
                </div>
                <div className="absolute bottom-4 left-4 z-20 flex gap-2">
                    <span className={`px-2 py-0.5 rounded-md text-xs font-bold border ${theme.badge} uppercase tracking-wider backdrop-blur-sm`}>
                        {event.category}
                    </span>
                </div>
            </div>

            {/* Content */}
            <div className="p-5 flex-1 flex flex-col">
                <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold font-display text-surface-900 dark:text-white line-clamp-1 group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
                        {event.title}
                    </h3>
                </div>

                <div className="space-y-3 mb-6 flex-1">
                    <p className="text-surface-600 dark:text-surface-400 text-sm line-clamp-3 leading-relaxed">
                        {event.description}
                    </p>

                    <div className="flex items-center gap-3 text-sm text-surface-500 dark:text-surface-400 mt-4">
                        <div className="flex items-center gap-1.5 bg-surface-100 dark:bg-surface-800 px-2 py-1 rounded-md">
                            <Calendar size={14} />
                            <span>{formatDate(event.startDate)} - {formatDate(event.endDate)}</span>
                        </div>
                    </div>
                </div>

                {/* Stats Row */}
                <div className="flex items-center justify-between mb-4 pt-4 border-t border-surface-100 dark:border-surface-800/50">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={handleLike}
                            className={`flex items-center gap-1.5 text-sm font-medium transition-colors ${isLiked ? 'text-error' : 'text-surface-400 hover:text-error'}`}
                        >
                            <Heart size={18} fill={isLiked ? "currentColor" : "none"} className={likeLoading ? "animate-pulse" : ""} />
                            <span>{likesCount}</span>
                        </button>
                        <div className="flex items-center gap-1.5 text-sm font-medium text-surface-400">
                            <Eye size={18} />
                            <span>{viewsCount}</span>
                        </div>
                    </div>
                </div>

                {/* Footer / Action */}
                <div className="space-y-3">
                    <Button
                        variant={theme.button}
                        className="w-full justify-center shadow-lg shadow-primary-500/10"
                        onClick={(e) => {
                            e.stopPropagation();
                            handleInteraction(e);
                            navigate(`/events/${event.id}`);
                        }}
                    >
                        View Details <ArrowRight size={18} className="ml-2" />
                    </Button>

                    {onExploreGallery && (event.status === 'Past' || event.status === 'Ongoing') && (
                        <Button
                            variant="glass"
                            size="sm"
                            className="w-full justify-center group/btn"
                            onClick={(e) => {
                                e.stopPropagation();
                                onExploreGallery();
                            }}
                        >
                            <ImageIcon size={16} className="mr-2 group-hover/btn:scale-110 transition-transform" />
                            Explore Gallery
                        </Button>
                    )}
                </div>
            </div>
        </Card>
    );
};

export default EventCard;
