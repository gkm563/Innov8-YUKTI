import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Search, Loader2 } from 'lucide-react';
import { collection, query, where, orderBy, getDocs } from 'firebase/firestore';
import { db } from '../services/firebase';
import MasonryGrid from './MasonryGrid';
import ImageModal from './ImageModal';
import Button from './ui/Button';

const EventGalleryModal = ({ event, onClose }) => {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedPost, setSelectedPost] = useState(null);

    useEffect(() => {
        const fetchEventPosts = async () => {
            if (!event) return;
            setLoading(true);
            try {
                // Strategy: 
                // 1. Fetch posts where category matches event type (if applicable)
                // 2. Fetch posts where caption/title roughly matches event name
                // Note: Firestore doesn't support full-text search easily, so we'll fetch recent posts and filter client-side for now,
                // or rely on a specific 'eventId' field if we had one. 
                // For this legacy system, we will try to match category first.

                const postsRef = collection(db, 'posts');
                // Strict query: Category match OR exact name match? 
                // Let's match by Category first as it's cleaner.
                // Assuming event.category maps to post.category
                const q = query(
                    postsRef,
                    where('category', '==', event.category),
                    orderBy('createdAt', 'desc')
                );

                const snapshot = await getDocs(q);
                let fetchedPosts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

                // Client-side fuzzy filter for better relevance if needed
                // e.g. if category is generic like 'Cultural', filter by event name tokens
                const eventKeywords = event.title.toLowerCase().split(' ').filter(w => w.length > 3);

                if (eventKeywords.length > 0) {
                    const specificPosts = fetchedPosts.filter(post => {
                        const content = (post.caption || '') + ' ' + (post.location || '');
                        return eventKeywords.some(kw => content.toLowerCase().includes(kw));
                    });

                    // If we found specific matches, prioritize them. If very few, fall back to category.
                    if (specificPosts.length > 0) {
                        fetchedPosts = specificPosts;
                    }
                }

                setPosts(fetchedPosts);
            } catch (error) {
                console.error("Error fetching event gallery:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchEventPosts();
    }, [event]);

    return (
        <AnimatePresence>
            {event && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-6">
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={onClose}
                        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
                    />

                    <motion.div
                        initial={{ opacity: 0, scale: 0.95, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: 20 }}
                        className="relative w-full max-w-6xl h-[85vh] bg-surface-50 dark:bg-surface-900 rounded-3xl overflow-hidden shadow-2xl flex flex-col"
                    >
                        {/* Header */}
                        <div className="p-6 border-b border-surface-200 dark:border-surface-800 flex justify-between items-center bg-white dark:bg-surface-950">
                            <div>
                                <h2 className="text-2xl font-bold font-display text-surface-900 dark:text-white">
                                    {event.title} <span className="text-primary-500">Gallery</span>
                                </h2>
                                <p className="text-sm text-surface-500 dark:text-surface-400">
                                    Explored {posts.length} memories from this event
                                </p>
                            </div>
                            <Button
                                variant="ghost"
                                size="sm"
                                onClick={onClose}
                                className="!p-2 rounded-full hover:bg-surface-100 dark:hover:bg-surface-800"
                            >
                                <X size={24} />
                            </Button>
                        </div>

                        {/* Content */}
                        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar bg-surface-50 dark:bg-surface-900">
                            {loading ? (
                                <div className="h-full flex flex-col items-center justify-center text-surface-400">
                                    <Loader2 size={40} className="animate-spin mb-4 text-primary-500" />
                                    <p>Curating memories...</p>
                                </div>
                            ) : posts.length > 0 ? (
                                <MasonryGrid
                                    posts={posts}
                                    onPostClick={setSelectedPost}
                                    showUser={false} // Clean view
                                    columns={{ sm: 2, md: 3, lg: 4 }}
                                />
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center text-surface-400 opacity-60">
                                    <Search size={48} className="mb-4" />
                                    <p className="text-lg">No photos found for this event yet.</p>
                                    <p className="text-sm mt-2">Be the first to upload!</p>
                                </div>
                            )}
                        </div>
                    </motion.div>

                    {/* Image Viewer Overlay */}
                    {selectedPost && (
                        <ImageModal
                            post={selectedPost}
                            onClose={() => setSelectedPost(null)}
                        // Pass list for navigation if needed, though ImageModal might not support it yet
                        />
                    )}
                </div>
            )}
        </AnimatePresence>
    );
};

export default EventGalleryModal;
