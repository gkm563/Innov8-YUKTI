import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Heart, Share2, Info, Calendar, Tag, Edit2, Check, Linkedin, Twitter, MessageCircle, Trash2 } from 'lucide-react';
import { logActivity } from '../services/activityService';
import { useAuth } from '../context/AuthContext';
import { doc, updateDoc, increment, arrayUnion, arrayRemove, onSnapshot, deleteDoc } from 'firebase/firestore';
import { ref, deleteObject } from 'firebase/storage';
import { db, storage } from '../services/firebase';
import { toast } from 'react-toastify';

const ImageModal = ({ post, isOpen, onClose, onUpdate = () => { } }) => {
    const { user, isAdmin } = useAuth();
    const [isEditing, setIsEditing] = useState(false);
    const [editedTitle, setEditedTitle] = useState('');
    const [editedCaption, setEditedCaption] = useState('');
    const [editedCategory, setEditedCategory] = useState('');
    // const [isAdmin, setIsAdmin] = useState(false); // Removed local state
    const [likes, setLikes] = useState(0);
    const [hasLiked, setHasLiked] = useState(false);
    const [views, setViews] = useState(0);
    const [livePost, setLivePost] = useState(post); // Store the full live post data

    useEffect(() => {
        if (isOpen && post?.id) {
            document.body.style.overflow = 'hidden';
            setEditedTitle(post.title || '');
            setEditedCaption(post.caption || '');
            setEditedCategory(post.category || '');
            // setIsAdmin(localStorage.getItem('isAdmin') === 'true'); // Removed insecure check

            // Initial optimistic set
            setLikes(post.likes || 0);
            setViews(post.views || 0);
            setLivePost(post);
            if (user) {
                setHasLiked(post.likedBy?.includes(user.uid) || false);
            }

            // Real-time listener
            const postRef = doc(db, 'posts', post.id);
            const unsubscribe = onSnapshot(postRef, (docSnap) => {
                if (docSnap.exists()) {
                    const data = docSnap.data();
                    setLivePost({ id: docSnap.id, ...data });
                    setLikes(data.likes || 0);
                    setViews(data.views || 0);
                    if (user) {
                        setHasLiked(data.likedBy?.includes(user.uid) || false);
                    }
                }
            }, (error) => {
                console.error("Error listening to post updates:", error);
            });

            // Increment View Count functionality (One-time trigger per open)
            // We invoke this independently of the listener
            const incrementView = async () => {
                try {
                    await updateDoc(postRef, {
                        views: increment(1)
                    });
                } catch (error) {
                    console.error("Error incrementing view:", error);
                }
            };
            incrementView();

            return () => {
                unsubscribe();
                document.body.style.overflow = 'unset';
            };

        } else {
            document.body.style.overflow = 'unset';
            setIsEditing(false);
        }
    }, [isOpen, post, user?.uid]); // dependency on user.uid ensures liked status re-evaluates on auth change

    if (!isOpen || !post) return null;

    // Use livePost for display to show updates, fallback to prop if loading/error
    const currentPost = livePost || post;

    // Permission Logic
    const isOwner = user && (user.uid === currentPost.uploadedBy?.uid || user.uid === currentPost.userId);
    const canEdit = isOwner || isAdmin;

    const handleSave = async () => {
        if (!isOwner && !isAdmin) {
            toast.error("Unauthorized action.");
            return;
        }
        try {
            const postRef = doc(db, 'posts', post.id);
            await updateDoc(postRef, {
                title: editedTitle,
                caption: editedCaption,
                category: editedCategory
            });
            toast.success("Memory details updated!");
            setIsEditing(false);
            if (onUpdate) onUpdate();
        } catch (error) {
            console.error(error);
            toast.error("Failed to update.");
        }
    };

    const handleDelete = async () => {
        if (!isOwner && !isAdmin) {
            toast.error("Unauthorized action.");
            return;
        }
        if (window.confirm("Are you sure you want to permanently delete this memory? This action cannot be undone.")) {
            try {
                // 1. Delete from Firestore
                await deleteDoc(doc(db, 'posts', post.id));

                // Log Activity
                logActivity(
                    user.uid,
                    user.displayName || 'User',
                    'DELETE',
                    `Deleted memory '${post.caption || 'Untitled'}'`,
                    { postId: post.id, imageUrl: post.imageUrl }
                );

                toast.success("Memory deleted.");

                // 2. Delete from Storage (if image exists)
                if (post.imageUrl) {
                    try {
                        // Create a reference to the file to delete
                        // Note: We construct ref from URL or path. storage ref accepts full URL usually? 
                        // Actually ref(storage, url) works for explicit full URLs in newer SDKs, 
                        // but safer to use refFromURL if available or just pass the URL to ref if supported or parse it.
                        // Standard Firebase v9 `ref` accepts a URL (gs:// or https://).
                        const imageRef = ref(storage, post.imageUrl);
                        await deleteObject(imageRef);
                    } catch (storageError) {
                        console.warn("Storage delete failed (might be already gone):", storageError);
                    }
                }

                toast.success("Memory deleted.");
                onClose();
                if (onUpdate) onUpdate();
            } catch (error) {
                console.error("Delete error:", error);
                toast.error("Failed to delete memory.");
            }
        }
    };

    const handleLike = async (e) => {
        e.stopPropagation();
        if (!user) {
            toast.info("Please login to like memories.");
            return;
        }

        // Optimistic UI update is handled by the listener almost instantly, 
        // but for immediate feedback we can toggle local state if network is slow.
        // However, with onSnapshot, it's safer to rely on the server state to avoid desync
        // unless latency is high. For now, we'll let firestore confirm the write.

        try {
            const postRef = doc(db, 'posts', post.id);
            if (hasLiked) {
                await updateDoc(postRef, {
                    likes: increment(-1),
                    likedBy: arrayRemove(user.uid)
                });
                // Local state will update via snapshot
            } else {
                await updateDoc(postRef, {
                    likes: increment(1),
                    likedBy: arrayUnion(user.uid)
                });
                toast.success("Liked! ❤️");
            }
        } catch (error) {
            console.error("Error toggling like:", error);
            if (error.message && (error.message.includes('offline') || error.message.includes('network') || error.code === 'unavailable')) {
                toast.error("Connection blocked. Please disable AdBlocker.");
            } else if (error.code === 'permission-denied') {
                toast.error("Permission denied. Database rules might need a minute to propagate.");
            } else {
                toast.error("Failed to like post. Try again.");
            }
        }
    };

    const handleShare = (platform) => {
        const url = window.location.href; // Or specific post URL if we had dynamic routing for posts
        const text = `Check out this memory on CampusClick: ${post.caption}`;

        let shareUrl = '';
        switch (platform) {
            case 'whatsapp':
                shareUrl = `https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`;
                break;
            case 'twitter':
                shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
                break;
            case 'linkedin':
                shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`;
                break;
            default:
                if (navigator.share) {
                    navigator.share({ title: 'CampusClick', text: text, url: url });
                    return;
                }
                navigator.clipboard.writeText(url);
                toast.success("Link copied to clipboard!");
                return;
        }
        window.open(shareUrl, '_blank');
    };

    return (
        <AnimatePresence>
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/95 backdrop-blur-xl"
                onClick={onClose}
            >
                <motion.div
                    initial={{ scale: 0.95, y: 20, opacity: 0 }}
                    animate={{ scale: 1, y: 0, opacity: 1 }}
                    exit={{ scale: 0.95, y: 20, opacity: 0 }}
                    transition={{ type: "spring", duration: 0.5, bounce: 0.3 }}
                    className="bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-700 rounded-3xl overflow-hidden max-w-6xl w-full max-h-[90vh] flex flex-col md:flex-row shadow-2xl relative"
                    onClick={(e) => e.stopPropagation()}
                >
                    {/* Close Button */}
                    <button
                        onClick={onClose}
                        className="absolute top-4 right-4 z-10 p-2 bg-black/50 hover:bg-white/20 text-white rounded-full backdrop-blur-md transition-colors border border-white/10"
                    >
                        <X size={20} />
                    </button>

                    {/* Image Section */}
                    <div className="md:w-2/3 bg-black flex items-center justify-center relative overflow-hidden bg-grid-white/[0.05]">
                        <img
                            src={currentPost.imageUrl}
                            alt={currentPost.caption}
                            className="w-full h-full object-contain max-h-[50vh] md:max-h-[90vh]"
                        />
                    </div>

                    {/* Details Section */}
                    <div className="md:w-1/3 p-6 md:p-8 flex flex-col overflow-y-auto bg-white dark:bg-surface-900 text-surface-900 dark:text-white border-l border-surface-200 dark:border-surface-700">
                        <div className="mb-6">
                            <div className="flex items-center gap-3 mb-6">
                                {currentPost.uploadedBy?.photoURL ? (
                                    <img
                                        src={currentPost.uploadedBy.photoURL}
                                        alt={currentPost.userName}
                                        className="w-12 h-12 rounded-full border-2 border-primary-500 object-cover shadow-lg"
                                    />
                                ) : (
                                    <div className="w-12 h-12 bg-gradient-to-br from-primary-500 to-secondary-600 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg">
                                        {currentPost.userInitial || (currentPost.userName ? currentPost.userName[0] : 'U')}
                                    </div>
                                )}

                                <div>
                                    <h3 className="font-bold text-lg leading-tight text-surface-900 dark:text-white">{currentPost.userName || 'Contributor'}</h3>
                                    {currentPost.linkedin && (
                                        <a href={currentPost.linkedin} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 mt-0.5">
                                            <Linkedin size={12} /> Connect
                                        </a>
                                    )}
                                    {!currentPost.linkedin && <p className="text-xs text-surface-500 dark:text-surface-400">Verified Contributor</p>}
                                </div>
                            </div>

                            <div className="flex items-center justify-between mb-2">
                                <h2 className="text-xl font-bold text-surface-900 dark:text-white">Memory Details</h2>
                                <div className="flex gap-2">
                                    {(canEdit) && !isEditing && (
                                        <>
                                            <button onClick={() => setIsEditing(true)} className="text-primary-600 dark:text-primary-400 hover:bg-primary-50 dark:hover:bg-primary-900/20 p-2 rounded-lg transition-colors" title="Edit Details">
                                                <Edit2 size={18} />
                                            </button>
                                            <button onClick={handleDelete} className="text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 p-2 rounded-lg transition-colors" title="Delete Memory">
                                                <Trash2 size={18} />
                                            </button>
                                        </>
                                    )}
                                </div>
                            </div>


                            {isEditing ? (
                                <div className="mb-6 space-y-4">
                                    <div>
                                        <label className="text-xs font-bold text-surface-500 uppercase tracking-wide mb-1 block">Title</label>
                                        <input
                                            type="text"
                                            className="w-full p-3 border border-surface-200 dark:border-surface-700 rounded-xl bg-surface-50 dark:bg-surface-800 focus:ring-2 focus:ring-primary-500 outline-none text-sm text-surface-900 dark:text-white transition-colors"
                                            value={editedTitle}
                                            onChange={(e) => setEditedTitle(e.target.value)}
                                            placeholder="Memory Title"
                                        />
                                    </div>
                                    <div>
                                        <label className="text-xs font-bold text-surface-500 uppercase tracking-wide mb-1 block">Caption / Description</label>
                                        <textarea
                                            className="w-full p-3 border border-surface-200 dark:border-surface-700 rounded-xl bg-surface-50 dark:bg-surface-800 focus:ring-2 focus:ring-primary-500 outline-none text-sm text-surface-900 dark:text-white transition-colors"
                                            rows="4"
                                            value={editedCaption}
                                            onChange={(e) => setEditedCaption(e.target.value)}
                                        />
                                    </div>
                                    <div>
                                        <label className="text-xs font-bold text-surface-500 uppercase tracking-wide mb-1 block">Category / Tag</label>
                                        <input
                                            type="text"
                                            className="w-full p-3 border border-surface-200 dark:border-surface-700 rounded-xl bg-surface-50 dark:bg-surface-800 focus:ring-2 focus:ring-primary-500 outline-none text-sm text-surface-900 dark:text-white transition-colors"
                                            value={editedCategory}
                                            onChange={(e) => setEditedCategory(e.target.value)}
                                        />
                                    </div>
                                    <div className="flex justify-end gap-2 mt-2">
                                        <button onClick={() => setIsEditing(false)} className="text-xs text-surface-500 hover:text-surface-700 dark:hover:text-surface-300 px-3 py-1">Cancel</button>
                                        <button onClick={handleSave} className="bg-green-500 text-white px-3 py-1 rounded-lg text-xs font-bold flex items-center gap-1 hover:bg-green-600 shadow-lg shadow-green-500/20">
                                            <Check size={12} /> Save Changes
                                        </button>
                                    </div>
                                </div>

                            ) : (
                                <div>
                                    {currentPost.title && <h1 className="text-2xl font-bold text-surface-900 dark:text-white mb-2">{currentPost.title}</h1>}
                                    <p className="text-surface-600 dark:text-surface-300 leading-relaxed italic border-l-4 border-primary-500/30 pl-4 py-1 mb-6">
                                        "{currentPost.caption}"
                                    </p>
                                </div>
                            )}

                            <div className="space-y-4 mb-8 bg-surface-50 dark:bg-surface-800/50 p-4 rounded-xl border border-surface-100 dark:border-surface-700">
                                <div className="flex items-center gap-3 text-surface-600 dark:text-surface-400 text-sm">
                                    <Calendar className="w-4 h-4 text-primary-500" />
                                    <span>Year: <span className="font-semibold text-surface-900 dark:text-white">{currentPost.year}</span></span>
                                </div>
                                <div className="flex items-center gap-3 text-surface-600 dark:text-surface-400 text-sm">
                                    <Tag className="w-4 h-4 text-pink-500" />
                                    <span>Category: <span className="font-semibold text-surface-900 dark:text-white">{currentPost.category || 'General'}</span></span>
                                </div>
                                <div className="flex items-center gap-3 text-surface-600 dark:text-surface-400 text-sm">
                                    <Info className="w-4 h-4 text-blue-500" />
                                    <span>AI Verification: <span className="text-green-600 dark:text-green-400 font-medium">{currentPost.isSafe ? 'Passed' : 'Pending'}</span></span>
                                </div>
                                <div className="flex items-center gap-3 text-surface-600 dark:text-surface-400 text-sm">
                                    <div className="flex -space-x-1">
                                        {[1, 2, 3].map(i => <div key={i} className="w-4 h-4 rounded-full bg-surface-300 dark:bg-surface-600 border border-white dark:border-surface-800"></div>)}
                                    </div>
                                    <span>Views: <span className="font-bold text-surface-900 dark:text-white">{views}</span></span>
                                </div>
                            </div>
                        </div>

                        <div className="mt-auto space-y-4">
                            <div className="flex gap-4">
                                <button
                                    onClick={handleLike}
                                    className={`flex-1 py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-colors ${hasLiked
                                        ? 'bg-red-500 text-white hover:bg-red-600 shadow-lg shadow-red-500/20'
                                        : 'bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/30 border border-red-100 dark:border-red-900/30'
                                        }`}
                                >
                                    <Heart className={`w-5 h-5 ${hasLiked ? 'fill-current' : ''}`} /> {likes}
                                </button>
                                <button
                                    onClick={() => handleShare('native')}
                                    className="flex-1 py-3 bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 rounded-xl font-semibold hover:bg-primary-100 dark:hover:bg-primary-900/30 border border-primary-100 dark:border-primary-900/30 flex items-center justify-center gap-2 transition-colors"
                                >
                                    <Share2 className="w-5 h-5" /> Share
                                </button>
                            </div>
                            <div className="flex justify-center gap-6 pt-4 border-t border-surface-200 dark:border-surface-800">
                                <button onClick={() => handleShare('whatsapp')} className="text-surface-400 hover:text-green-500 transition-colors"><MessageCircle size={20} /></button>
                                <button onClick={() => handleShare('twitter')} className="text-surface-400 hover:text-blue-400 transition-colors"><Twitter size={20} /></button>
                                <button onClick={() => handleShare('linkedin')} className="text-surface-400 hover:text-blue-700 transition-colors"><Linkedin size={20} /></button>
                            </div>
                            <p className="text-center text-xs text-surface-400 dark:text-surface-600 mt-2">
                                Archived by CampusClick.
                            </p>
                        </div>
                    </div>
                </motion.div>
            </motion.div>
        </AnimatePresence>
    );
};

export default ImageModal;
