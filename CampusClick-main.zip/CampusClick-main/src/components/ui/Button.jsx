import React from 'react';
import { motion } from 'framer-motion';
import PropTypes from 'prop-types';

const variants = {
    primary: 'bg-primary-600 text-white hover:bg-primary-500 shadow-lg shadow-primary-500/30 hover:shadow-primary-500/50 border border-transparent',
    secondary: 'bg-secondary-600 text-white hover:bg-secondary-500 shadow-lg shadow-secondary-500/30 hover:shadow-secondary-500/50 border border-transparent',
    outline: 'bg-transparent border-2 border-primary-600 text-primary-600 hover:bg-primary-50 dark:border-primary-500 dark:text-primary-400 dark:hover:bg-primary-950/30',
    ghost: 'bg-transparent text-surface-600 hover:bg-surface-100/50 hover:text-primary-600 dark:text-surface-300 dark:hover:bg-surface-800/50 dark:hover:text-primary-400',
    glass: 'glass text-surface-900 dark:text-white hover:bg-white/80 dark:hover:bg-surface-800/80 shadow-glass border-surface-200/50 dark:border-surface-700/50',
    danger: 'bg-error text-white hover:bg-red-500 shadow-lg shadow-error/30 hover:shadow-error/50',
};

const sizes = {
    sm: 'px-3 py-1.5 text-sm',
    md: 'px-6 py-2.5 text-sm uppercase tracking-wide',
    lg: 'px-8 py-3.5 text-base',
};

const Button = ({
    children,
    variant = 'primary',
    size = 'md',
    className = '',
    isLoading = false,
    disabled = false,
    icon = null,
    onClick,
    ...props
}) => {
    const baseStyles = 'relative inline-flex items-center justify-center rounded-xl font-semibold transition-all duration-200 outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50 disabled:cursor-not-allowed';

    return (
        <motion.button
            whileHover={!disabled && !isLoading ? { scale: 1.02 } : {}}
            whileTap={!disabled && !isLoading ? { scale: 0.98 } : {}}
            className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`}
            disabled={disabled || isLoading}
            onClick={onClick}
            {...props}
        >
            {isLoading && (
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-current" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
            )}
            {!isLoading && icon && <span className="mr-2">{icon}</span>}
            {children}
        </motion.button>
    );
};

Button.propTypes = {
    children: PropTypes.node.isRequired,
    variant: PropTypes.oneOf(['primary', 'secondary', 'outline', 'ghost', 'glass', 'danger']),
    size: PropTypes.oneOf(['sm', 'md', 'lg']),
    className: PropTypes.string,
    isLoading: PropTypes.bool,
    disabled: PropTypes.bool,
    icon: PropTypes.node,
    onClick: PropTypes.func,
};

export default Button;
