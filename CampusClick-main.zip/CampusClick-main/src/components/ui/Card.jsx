import React from 'react';
import { motion } from 'framer-motion';
import PropTypes from 'prop-types';

const Card = ({
    children,
    className = '',
    variant = 'default',
    hoverEffect = false,
    ...props
}) => {
    const baseStyles = 'rounded-2xl overflow-hidden transition-all duration-300';

    const variants = {
        default: 'bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-800 shadow-sm',
        glass: 'glass-card',
        outline: 'border-2 border-surface-200 dark:border-surface-800 bg-transparent',
        elevated: 'bg-white dark:bg-surface-950 shadow-xl dark:shadow-2xl border border-surface-100 dark:border-surface-800/50',
    };

    const hoverAnimation = hoverEffect ? {
        y: -8,
        transition: { type: 'spring', stiffness: 300 }
    } : {};

    return (
        <motion.div
            whileHover={hoverAnimation}
            className={`${baseStyles} ${variants[variant]} ${className}`}
            {...props}
        >
            {children}
        </motion.div>
    );
};

Card.propTypes = {
    children: PropTypes.node.isRequired,
    className: PropTypes.string,
    variant: PropTypes.oneOf(['default', 'glass', 'outline', 'elevated']),
    hoverEffect: PropTypes.bool,
};

export default Card;
