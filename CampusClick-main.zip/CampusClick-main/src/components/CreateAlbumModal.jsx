import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, FolderPlus, Loader2 } from 'lucide-react';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../services/firebase';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import Button from './ui/Button';
import Card from './ui/Card';

const CreateAlbumModal = ({ isOpen, onClose }) => {
    const { user } = useAuth();
    const [albumName, setAlbumName] = useState('');
    const [description, setDescription] = useState('');
    const [loading, setLoading] = useState(false);

    if (!isOpen) return null;

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!albumName.trim()) {
            toast.error("Please enter an album name.");
            return;
        }

        setLoading(true);
        try {
            await addDoc(collection(db, 'albums'), {
                name: albumName,
                description,
                userId: user.uid,
                userName: user.displayName || 'User',
                createdAt: serverTimestamp(),
                itemCount: 0,
                coverImage: null
            });
            toast.success("Album created successfully! 📁");
            setAlbumName('');
            setDescription('');
            onClose();
        } catch (error) {
            console.error("Error creating album:", error);
            toast.error(`Failed to create album: ${error.message}`);
        } finally {
            setLoading(false);
        }
    };

    return (
        <AnimatePresence>
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md"
                onClick={onClose}
            >
                <motion.div
                    initial={{ scale: 0.95, opacity: 0, y: 20 }}
                    animate={{ scale: 1, opacity: 1, y: 0 }}
                    exit={{ scale: 0.95, opacity: 0, y: 20 }}
                    transition={{ type: "spring", duration: 0.5, bounce: 0.3 }}
                    className="w-full max-w-md"
                    onClick={(e) => e.stopPropagation()}
                >
                    <Card className="overflow-hidden border-surface-200 dark:border-surface-700 bg-surface-50 dark:bg-surface-900 shadow-2xl">
                        <div className="p-5 border-b border-surface-200 dark:border-surface-700 flex justify-between items-center bg-white dark:bg-surface-800">
                            <h2 className="text-xl font-bold font-display text-surface-900 dark:text-white flex items-center gap-2">
                                <FolderPlus className="text-primary-500" /> Create New Album
                            </h2>
                            <Button
                                onClick={onClose}
                                variant="ghost"
                                size="sm"
                                className="!p-2 rounded-full hover:bg-surface-100 dark:hover:bg-surface-700"
                            >
                                <X size={20} className="text-surface-500" />
                            </Button>
                        </div>

                        <form onSubmit={handleSubmit} className="p-6 space-y-5">
                            <div>
                                <label className="text-xs font-bold text-surface-500 uppercase tracking-wider mb-2 block">Album Name</label>
                                <input
                                    type="text"
                                    value={albumName}
                                    onChange={(e) => setAlbumName(e.target.value)}
                                    className="w-full px-4 py-3 rounded-xl border border-surface-200 dark:border-surface-700 bg-white dark:bg-surface-800 text-surface-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none text-sm transition-shadow shadow-sm focus:shadow-md"
                                    placeholder="e.g. Convocation 2025"
                                    autoFocus
                                />
                            </div>

                            <div>
                                <label className="text-xs font-bold text-surface-500 uppercase tracking-wider mb-2 block">Description (Optional)</label>
                                <textarea
                                    value={description}
                                    onChange={(e) => setDescription(e.target.value)}
                                    className="w-full px-4 py-3 rounded-xl border border-surface-200 dark:border-surface-700 bg-white dark:bg-surface-800 text-surface-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none text-sm transition-shadow shadow-sm focus:shadow-md resize-none"
                                    placeholder="What's this album about?"
                                    rows="3"
                                />
                            </div>

                            <Button
                                type="submit"
                                isLoading={loading}
                                className="w-full shadow-lg shadow-primary-500/20"
                                icon={<FolderPlus size={20} />}
                            >
                                Create Album
                            </Button>
                        </form>
                    </Card>
                </motion.div>
            </motion.div>
        </AnimatePresence>
    );
};

export default CreateAlbumModal;
