import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Trash2, Image as ImageIcon, Shield, AlertTriangle, Ban, CheckCircle, Edit, Mail, Send } from 'lucide-react';
import { collection, query, where, getDocs, deleteDoc, doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../services/firebase';
import { toast } from 'react-toastify';
import Button from './ui/Button';
import UploadModal from './UploadModal';

const UserDetailsModal = ({ isOpen, onClose, user, onUserUpdated }) => {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [postToEdit, setPostToEdit] = useState(null);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);

    // Delete User State
    const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
    const [deleteReason, setDeleteReason] = useState('');
    const [deletingUser, setDeletingUser] = useState(false);

    useEffect(() => {
        if (isOpen && user) {
            fetchUserPosts();
        }
    }, [isOpen, user]);

    const fetchUserPosts = async () => {
        setLoading(true);
        try {
            // Support both new auth-linked uploads and legacy uploads
            // Querying by uploadedBy.uid is the most reliable for new system
            const q = query(collection(db, 'posts'), where("uploadedBy.uid", "==", user.uid));
            const snapshot = await getDocs(q);
            const userPosts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setPosts(userPosts);
        } catch (error) {
            console.error("Error fetching user posts:", error);
            // toast.error("Could not load user uploads.");
        } finally {
            setLoading(false);
        }
    };

    const handleDeletePost = async (postId) => {
        if (!window.confirm("Delete this photo permanently?")) return;
        try {
            await deleteDoc(doc(db, 'posts', postId));
            setPosts(posts.filter(p => p.id !== postId));
            toast.success("Photo deleted.");
        } catch (error) {
            console.error("Error deleting post:", error);
            toast.error("Failed to delete photo.");
        }
    };

    const handleDeleteUser = async () => {
        if (!deleteReason.trim()) {
            toast.warning("Please provide a reason for deletion.");
            return;
        }

        setDeletingUser(true);
        try {
            // Simulate Email Sending
            console.log(`[EMAIL SIMULATION] To: ${user.email} | Subject: Account Deletion Notice | Body: Your account has been deleted by the administration. Reason: ${deleteReason}`);

            // Delete User Document
            await deleteDoc(doc(db, 'users', user.id));

            toast.success("User deleted and notification sent.");
            onUserUpdated(); // Refresh parent list
            setIsDeleteConfirmOpen(false);
            onClose();
        } catch (error) {
            console.error("Error deleting user:", error);
            toast.error("Failed to delete user.");
        } finally {
            setDeletingUser(false);
        }
    };

    const handleEditPost = (post) => {
        setPostToEdit(post);
        setIsEditModalOpen(true);
    };

    const toggleBlockUser = async () => {
        try {
            await updateDoc(doc(db, 'users', user.id), {
                isBlocked: !user.isBlocked
            });
            toast.success(`User ${user.isBlocked ? 'unblocked' : 'blocked'}.`);
            onUserUpdated();
            // We update the local user object prop implicitly by parent refresh, 
            // but for immediate UI feedback we might need to rely on parent
        } catch (error) {
            console.error("Error:", error);
            toast.error("Failed to update status.");
        }
    };

    if (!isOpen || !user) return null;

    return (
        <AnimatePresence>
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
                <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="bg-white dark:bg-surface-800 rounded-2xl w-full max-w-4xl h-[85vh] flex flex-col shadow-2xl overflow-hidden border border-surface-200 dark:border-surface-700"
                >
                    {/* Header */}
                    <div className="p-6 border-b border-surface-200 dark:border-surface-700 flex justify-between items-start bg-surface-50 dark:bg-surface-900/50">
                        <div className="flex items-center gap-4">
                            <img
                                src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName}`}
                                alt={user.displayName}
                                className="w-16 h-16 rounded-full border-4 border-white dark:border-surface-700 shadow-md"
                            />
                            <div>
                                <h2 className="text-2xl font-bold text-surface-900 dark:text-white flex items-center gap-2">
                                    {user.displayName}
                                    {user.role === 'admin' && <Shield size={18} className="text-primary-500" />}
                                </h2>
                                <p className="text-surface-500 dark:text-surface-400">{user.email}</p>
                                <div className="flex gap-2 mt-2">
                                    <span className={`px-2 py-0.5 rounded text-xs font-bold uppercase tracking-wider ${user.isBlocked ? 'bg-error/10 text-error' : 'bg-success/10 text-success'}`}>
                                        {user.isBlocked ? 'Blocked' : 'Active'}
                                    </span>
                                    <span className="bg-surface-200 dark:bg-surface-700 text-surface-600 dark:text-surface-300 px-2 py-0.5 rounded text-xs font-mono">
                                        UID: {user.uid}
                                    </span>
                                </div>
                            </div>
                        </div>
                        <button onClick={onClose} className="p-2 hover:bg-surface-200 dark:hover:bg-surface-700 rounded-full transition-colors">
                            <X size={24} className="text-surface-500" />
                        </button>
                    </div>

                    {/* Scrollable Content */}
                    <div className="flex-1 overflow-y-auto p-6">

                        {/* Stats */}
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                            <div className="p-4 rounded-xl bg-surface-50 dark:bg-surface-900/50 border border-surface-100 dark:border-surface-700">
                                <span className="text-xs text-surface-500 uppercase font-bold">Uploads</span>
                                <p className="text-2xl font-bold text-surface-900 dark:text-white">{posts.length}</p>
                            </div>
                            {/* Can add more stats if needed */}
                        </div>

                        {/* Gallery */}
                        <div className="space-y-4">
                            <h3 className="text-lg font-bold flex items-center gap-2 text-surface-900 dark:text-white">
                                <ImageIcon size={20} className="text-primary-500" />
                                User Uploads
                            </h3>

                            {loading ? (
                                <div className="py-12 text-center text-surface-500">Loading photos...</div>
                            ) : posts.length === 0 ? (
                                <div className="py-12 text-center border-2 border-dashed border-surface-200 dark:border-surface-700 rounded-xl">
                                    <p className="text-surface-500">No photos uploaded by this user.</p>
                                </div>
                            ) : (
                                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                                    {posts.map(post => (
                                        <div key={post.id} className="group relative aspect-square rounded-xl overflow-hidden bg-surface-100 dark:bg-surface-900 border border-surface-200 dark:border-surface-700">
                                            <img
                                                src={post.imageUrl}
                                                alt={post.caption}
                                                className="w-full h-full object-cover transition-transform group-hover:scale-105"
                                            />
                                            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                                <button
                                                    onClick={() => handleEditPost(post)}
                                                    className="p-3 bg-white text-primary-600 rounded-full hover:bg-primary-50 transition-colors shadow-lg"
                                                    title="Edit Post"
                                                >
                                                    <Edit size={18} />
                                                </button>
                                                <button
                                                    onClick={() => handleDeletePost(post.id)}
                                                    className="p-3 bg-white text-error rounded-full hover:bg-error hover:text-white transition-colors shadow-lg"
                                                    title="Delete Photo"
                                                >
                                                    <Trash2 size={18} />
                                                </button>
                                            </div>
                                            <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/80 to-transparent">
                                                <p className="text-xs text-white line-clamp-1">{post.caption}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Footer Actions */}
                    <div className="p-6 border-t border-surface-200 dark:border-surface-700 bg-surface-50 dark:bg-surface-900/50 flex justify-between items-center">
                        <span className="text-xs text-surface-500">Managed by Admin</span>
                        <div className="flex gap-3">
                            <Button
                                variant="outline"
                                className="text-error border-error/20 hover:bg-error/10"
                                onClick={() => setIsDeleteConfirmOpen(true)}
                            >
                                <Trash2 size={16} className="mr-2" /> Delete User Account
                            </Button>
                        </div>
                    </div>

                    {/* Delete Confirmation Overlay */}
                    {isDeleteConfirmOpen && (
                        <div className="absolute inset-0 bg-white/95 dark:bg-black/90 z-20 flex items-center justify-center p-8">
                            <div className="w-full max-w-md space-y-4 text-center">
                                <div className="mx-auto w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center text-red-500 mb-4">
                                    <AlertTriangle size={32} />
                                </div>
                                <h3 className="text-2xl font-bold text-surface-900 dark:text-white">Delete {user.displayName}?</h3>
                                <p className="text-surface-500">This action is permanent. Please provide a reason to be sent to the user via email.</p>

                                <div className="text-left mt-4">
                                    <label className="text-xs font-bold uppercase tracking-wider text-surface-400">Reason for Deletion</label>
                                    <textarea
                                        value={deleteReason}
                                        onChange={(e) => setDeleteReason(e.target.value)}
                                        className="w-full mt-2 p-3 bg-surface-50 dark:bg-surface-800 border border-surface-200 dark:border-surface-700 rounded-xl focus:ring-2 focus:ring-red-500 outline-none resize-none"
                                        rows="3"
                                        placeholder="e.g. Violation of community guidelines regarding hate speech..."
                                    ></textarea>
                                </div>

                                <div className="flex gap-3 justify-center mt-6">
                                    <Button
                                        variant="ghost"
                                        onClick={() => setIsDeleteConfirmOpen(false)}
                                        disabled={deletingUser}
                                    >
                                        Cancel
                                    </Button>
                                    <Button
                                        className="bg-red-500 hover:bg-red-600 text-white border-none shadow-lg shadow-red-500/20"
                                        onClick={handleDeleteUser}
                                        isLoading={deletingUser}
                                        icon={<Send size={16} />}
                                    >
                                        Delete & Notify
                                    </Button>
                                </div>
                            </div>
                        </div>
                    )}

                </motion.div>

                {/* Edit Post Modal - Reusing UploadModal */}
                <UploadModal
                    isOpen={isEditModalOpen}
                    onClose={() => { setIsEditModalOpen(false); setPostToEdit(null); }}
                    postToEdit={postToEdit}
                />
            </div>
        </AnimatePresence>
    );
};

export default UserDetailsModal;
