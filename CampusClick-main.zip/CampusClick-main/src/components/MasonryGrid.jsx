import React, { useEffect, useState } from 'react';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../services/firebase';
import ImageCard from './ImageCard';
import ImageModal from './ImageModal';
import { Plus, Search, Loader2 } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import UploadModal from './UploadModal';
import { useAuth } from '../context/AuthContext';
import Button from './ui/Button';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { storage } from '../services/firebase';
import { addDoc, serverTimestamp, updateDoc, doc } from 'firebase/firestore';
import { analyzeImage } from '../services/gemini';
import { toast } from 'react-toastify';
import { logActivity } from '../services/activityService';
import UploadProgressCard from './UploadProgressCard';

const MasonryGrid = ({ selectedYear }) => {
    const { user } = useAuth();
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedPost, setSelectedPost] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [isUploadOpen, setIsUploadOpen] = useState(false);

    // Background Upload State
    const [uploadState, setUploadState] = useState({
        active: false,
        minimized: true,
        progress: 0,
        status: 'idle',
        file: null,
        resultMessage: ''
    });

    const handleUploadStart = async (file, metadata) => {
        setUploadState({
            active: true,
            minimized: true,
            progress: 0,
            status: 'uploading',
            file: file,
            resultMessage: ''
        });

        try {
            // 1. Upload File
            const storageRef = ref(storage, `memories/${user.uid}/${Date.now()}_${file.name}`);
            const uploadTask = uploadBytesResumable(storageRef, file);

            uploadTask.on('state_changed',
                (snapshot) => {
                    const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                    setUploadState(prev => ({ ...prev, progress }));
                },
                (error) => {
                    console.error("Upload error:", error);
                    setUploadState(prev => ({ ...prev, status: 'error', resultMessage: 'Upload failed.' }));
                },
                async () => {
                    // Upload complete
                    const imageUrl = await getDownloadURL(uploadTask.snapshot.ref);
                    setUploadState(prev => ({ ...prev, status: 'analyzing', progress: 100 }));

                    // 2. AI Analysis
                    try {
                        const aiResult = await analyzeImage(file);
                        let safetyStatus = 'approved';
                        let safetyReason = '';

                        if (!aiResult.isSafe) {
                            safetyStatus = 'pending_review';
                            safetyReason = aiResult.reason || "AI detected potential violation.";
                            setUploadState(prev => ({ ...prev, status: 'flagged', resultMessage: `Flagged: ${safetyReason}` }));
                            toast.error(`Upload Flagged: ${safetyReason}`);
                        } else {
                            setUploadState(prev => ({ ...prev, status: 'success', resultMessage: 'Successfully uploaded!' }));
                            toast.success("Upload Successful!");
                        }

                        // 3. Save to Firestore
                        await addDoc(collection(db, 'posts'), {
                            ...metadata,
                            imageUrl,
                            userId: user.uid,
                            uploadedBy: {
                                uid: user.uid,
                                displayName: user.displayName || 'Contributor',
                                photoURL: user.photoURL || null
                            },
                            userName: user.displayName || 'Contributor',
                            userInitial: (user.displayName || 'C')[0].toUpperCase(),
                            status: safetyStatus,
                            flagReason: safetyReason,
                            likes: 0,
                            views: 0,
                            createdAt: serverTimestamp(),
                            timestamp: serverTimestamp() // Add legacy timestamp for compatibility
                        });

                        // Log Activity
                        logActivity(user.uid, user.displayName, 'UPLOAD', `Uploaded new memory`, { imageUrl });

                    } catch (error) {
                        console.error("AI/Save error:", error);
                        setUploadState(prev => ({ ...prev, status: 'error', resultMessage: 'Processing failed.' }));
                    }
                }
            );
        } catch (error) {
            console.error("Start error:", error);
            setUploadState(prev => ({ ...prev, status: 'error', resultMessage: error.message }));
        }
    };

    useEffect(() => {
        // Fetch all posts - relying on client-side sort to handle mixed 'timestamp' vs 'createdAt' fields
        let q = query(collection(db, 'posts'));

        const unsubscribe = onSnapshot(q, (snapshot) => {
            const fetchedPosts = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            }));

            // Robust Client-side Sort
            fetchedPosts.sort((a, b) => {
                const timeA = a.timestamp?.seconds || a.createdAt?.seconds || 0;
                const timeB = b.timestamp?.seconds || b.createdAt?.seconds || 0;
                return timeB - timeA;
            });

            setPosts(fetchedPosts);
            setLoading(false);
        }, (error) => {
            console.error("Firestore Error:", error);
            if (error.code === 'permission-denied') {
                console.error("Database Error: Access blocked.");
            }
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    const filteredPosts = posts.filter(post => {
        const isApproved = post.status === 'approved' || !post.status;
        if (!isApproved) return false;

        const matchYear = selectedYear === 'All' || (post.year && post.year.toString() === selectedYear);
        const matchSearch = !searchQuery ||
            (post.category && post.category.toLowerCase().includes(searchQuery.toLowerCase())) ||
            (post.caption && post.caption.toLowerCase().includes(searchQuery.toLowerCase()));
        return matchYear && matchSearch;
    });

    if (loading) {
        return (
            <div className="flex justify-center py-20">
                <Loader2 className="w-8 h-8 animate-spin text-primary-500" />
            </div>
        )
    }

    return (
        <div className="relative min-h-[500px]">
            {/* Search Bar */}
            <div className="relative max-w-lg mx-auto mb-10">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-surface-400" />
                </div>
                <input
                    type="text"
                    className="block w-full pl-11 pr-4 py-3 border border-surface-200 dark:border-surface-700 rounded-full leading-5 bg-white dark:bg-surface-800/50 backdrop-blur-sm text-surface-900 dark:text-white placeholder-surface-400 focus:outline-none focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500 transition-all shadow-sm focus:shadow-md"
                    placeholder="Search memories (e.g., 'convocation', 'library')"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
            </div>

            {filteredPosts.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 text-center px-4 border-2 border-dashed border-surface-200 dark:border-surface-700 rounded-3xl bg-surface-50/50 dark:bg-surface-800/20">
                    <div className="bg-primary-50 dark:bg-primary-900/20 p-5 rounded-full mb-6">
                        <Plus className="w-10 h-10 text-primary-500" />
                    </div>
                    <h3 className="text-xl font-bold text-surface-900 dark:text-white mb-2">No memories found</h3>
                    <p className="text-surface-500 dark:text-surface-400 max-w-sm mb-8">
                        {searchQuery ? "Try checking your spelling or using different keywords." : "The gallery is looking a bit empty! Be the first to share a moment."}
                    </p>
                    <Button
                        onClick={() => user ? setIsUploadOpen(true) : window.location.href = '/auth/login'}
                        variant="primary"
                        icon={<Plus size={18} />}
                    >
                        Share First Memory
                    </Button>
                </div>
            ) : (
                <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6 px-0 pb-20">
                    <AnimatePresence>
                        {filteredPosts.map(post => (
                            <ImageCard
                                key={post.id}
                                post={post}
                                onClick={(post) => setSelectedPost(post)}
                            />
                        ))}
                    </AnimatePresence>
                </div>
            )}

            <ImageModal
                post={selectedPost}
                isOpen={!!selectedPost}
                onClose={() => setSelectedPost(null)}
            />

            <UploadModal
                isOpen={isUploadOpen}
                onClose={() => setIsUploadOpen(false)}
                onUploadStart={handleUploadStart}
            />

            <UploadProgressCard
                uploadState={uploadState}
                onClose={() => setUploadState(prev => ({ ...prev, active: false }))}
            />

            {/* Floating Action Button */}
            <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="fixed bottom-8 right-8 z-40"
            >
                <Button
                    onClick={() => user ? setIsUploadOpen(true) : window.location.href = '/auth/login'}
                    variant="primary"
                    size="lg"
                    className="rounded-full shadow-xl shadow-primary-500/30 px-6"
                >
                    <Plus className="w-5 h-5 mr-2" />
                    {user ? "Share Memory" : "Login to Share"}
                </Button>
            </motion.div>
        </div>
    );
};

export default MasonryGrid;
