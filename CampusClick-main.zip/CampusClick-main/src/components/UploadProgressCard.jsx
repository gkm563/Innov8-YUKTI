import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Minimize2, Maximize2, X, Check, AlertTriangle, Loader2, Sparkles, Image as ImageIcon } from 'lucide-react';

const UploadProgressCard = ({ uploadState, onClose, onMaximize }) => {
    const { status, progress, file, resultMessage, minimized } = uploadState;
    const [preview, setPreview] = useState(null);

    useEffect(() => {
        if (file) {
            const url = URL.createObjectURL(file);
            setPreview(url);
            return () => URL.revokeObjectURL(url);
        }
    }, [file]);

    if (!uploadState.active) return null;

    const isComplete = status === 'success' || status === 'error' || status === 'flagged';

    return (
        <AnimatePresence>
            <motion.div
                initial={{ y: 100, opacity: 0, scale: 0.9 }}
                animate={{ y: 0, opacity: 1, scale: 1 }}
                exit={{ y: 100, opacity: 0, scale: 0.9 }}
                className={`fixed bottom-6 right-6 z-50 bg-surface-50 dark:bg-surface-900 border border-surface-200 dark:border-surface-700 shadow-2xl rounded-2xl overflow-hidden transition-all duration-300 ${minimized ? 'w-80' : 'w-96'}`}
            >
                {/* Header / Minimized View */}
                <div className="p-4 flex items-center gap-4 bg-surface-100 dark:bg-surface-800">
                    <div className="relative w-12 h-12 rounded-lg overflow-hidden bg-surface-200 dark:bg-surface-700 flex-shrink-0">
                        {preview ? (
                            <img src={preview} alt="Upload" className="w-full h-full object-cover" />
                        ) : (
                            <ImageIcon className="absolute inset-0 m-auto text-surface-400" size={20} />
                        )}
                        {status === 'success' && (
                            <div className="absolute inset-0 bg-green-500/80 flex items-center justify-center">
                                <Check size={20} className="text-white" />
                            </div>
                        )}
                        {(status === 'error' || status === 'flagged') && (
                            <div className="absolute inset-0 bg-red-500/80 flex items-center justify-center">
                                <X size={20} className="text-white" />
                            </div>
                        )}
                    </div>

                    <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-sm text-surface-900 dark:text-white truncate">
                            {status === 'success' ? 'Upload Complete' :
                                status === 'flagged' ? 'Upload Rejected' :
                                    status === 'error' ? 'Upload Failed' :
                                        'Uploading Memory...'}
                        </h4>
                        <p className="text-xs text-surface-500 truncate">
                            {status === 'uploading' && `Uploading... ${Math.round(progress)}%`}
                            {status === 'analyzing' && <span className="flex items-center gap-1 text-primary-500"><Sparkles size={10} /> AI Analyzing...</span>}
                            {status === 'success' && "Visible in gallery"}
                            {status === 'flagged' && "unsafe content detected"}
                            {status === 'error' && "Please try again"}
                        </p>
                    </div>

                    <div className="flex gap-1">
                        {/* {minimized ? (
                            <button onClick={onMaximize} className="p-1.5 hover:bg-surface-200 dark:hover:bg-surface-700 rounded-md transition-colors text-surface-500">
                                <Maximize2 size={16} />
                            </button>
                        ) : (
                            <button onClick={onMinimize} className="p-1.5 hover:bg-surface-200 dark:hover:bg-surface-700 rounded-md transition-colors text-surface-500">
                                <Minimize2 size={16} />
                            </button>
                        )} */}
                        {isComplete && (
                            <button onClick={onClose} className="p-1.5 hover:bg-red-100 dark:hover:bg-red-900/30 text-surface-500 hover:text-red-500 rounded-md transition-colors">
                                <X size={16} />
                            </button>
                        )}
                    </div>
                </div>

                {/* Expanded / Progress Bar Area */}
                {!isComplete && (
                    <div className="px-4 pb-4 bg-surface-100 dark:bg-surface-800">
                        <div className="h-1.5 w-full bg-surface-200 dark:bg-surface-700 rounded-full overflow-hidden">
                            <motion.div
                                className={`h-full ${status === 'analyzing' ? 'bg-primary-500' : 'bg-green-500'}`}
                                initial={{ width: 0 }}
                                animate={{ width: `${progress}%` }}
                                transition={{ duration: 0.2 }}
                            />
                        </div>
                    </div>
                )}

                {/* Result Message Area */}
                {resultMessage && !minimized && (
                    <div className={`p-3 text-xs border-t ${status === 'flagged' || status === 'error' ? 'bg-red-50 dark:bg-red-900/10 border-red-100 dark:border-red-900/30 text-red-600 dark:text-red-400' : 'bg-green-50 dark:bg-green-900/10 border-green-100 dark:border-green-900/30 text-green-600 dark:text-green-400'}`}>
                        {resultMessage}
                    </div>
                )}

            </motion.div>
        </AnimatePresence>
    );
};

export default UploadProgressCard;
