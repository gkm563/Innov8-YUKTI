import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Upload, Calendar, Type, FileText, Link as LinkIcon, MapPin, Trophy, Users, AlertCircle, DollarSign, Clock, CheckCircle } from 'lucide-react';
import { createEvent, updateEvent } from '../services/eventService';
import { toast } from 'react-toastify';

const AdminEventModal = ({ isOpen, onClose, onEventAdded, eventToEdit }) => {
    const [loading, setLoading] = useState(false);
    const [activeTab, setActiveTab] = useState('basic'); // basic, details, logistics, extras

    const [formData, setFormData] = useState({
        title: '',
        description: '',
        type: 'cultural', // cultural, tech
        category: 'webinar',
        startDate: '',
        endDate: '',
        venue: '',
        registrationLink: '',
        coordinatorName: '',
        coordinatorPhone: '',
        // New Fields
        prizePool: '',
        teamSizeMin: '1',
        teamSizeMax: '1',
        audience: '', // e.g. "All Students", "CS Dept Only"
        registrationDeadline: '',
        rules: '',
        sponsors: ''
    });

    const [banner, setBanner] = useState(null);
    const [bannerPreview, setBannerPreview] = useState('');

    useEffect(() => {
        if (eventToEdit) {
            // Populate form for editing
            setFormData({
                title: eventToEdit.title || '',
                description: eventToEdit.description || '',
                type: eventToEdit.type || 'cultural',
                category: eventToEdit.category || 'webinar',
                startDate: eventToEdit.startDate?.toDate ? eventToEdit.startDate.toDate().toISOString().slice(0, 16) : (eventToEdit.startDate || '').slice(0, 16),
                endDate: eventToEdit.endDate?.toDate ? eventToEdit.endDate.toDate().toISOString().slice(0, 16) : (eventToEdit.endDate || '').slice(0, 16),
                venue: eventToEdit.venue || '',
                registrationLink: eventToEdit.registrationLink || '',
                coordinatorName: eventToEdit.coordinatorName || '',
                coordinatorPhone: eventToEdit.coordinatorPhone || '',
                // New Fields
                prizePool: eventToEdit.prizePool || '',
                teamSizeMin: eventToEdit.teamSizeMin || '1',
                teamSizeMax: eventToEdit.teamSizeMax || '1',
                audience: eventToEdit.audience || '',
                registrationDeadline: eventToEdit.registrationDeadline?.toDate ? eventToEdit.registrationDeadline.toDate().toISOString().slice(0, 16) : (eventToEdit.registrationDeadline || '').slice(0, 16),
                rules: eventToEdit.rules || '',
                sponsors: eventToEdit.sponsors || ''
            });
            setBanner(null);
            setBannerPreview(eventToEdit.bannerUrl || '');
        } else {
            // Reset for new event
            setFormData({
                title: '', description: '', type: 'cultural', category: 'webinar',
                startDate: '', endDate: '', venue: '', registrationLink: '',
                coordinatorName: '', coordinatorPhone: '',
                prizePool: '', teamSizeMin: '1', teamSizeMax: '1', audience: '',
                registrationDeadline: '', rules: '', sponsors: ''
            });
            setBanner(null);
            setBannerPreview('');
            setActiveTab('basic');
        }
    }, [eventToEdit, isOpen]);

    // Dynamic Categories based on Type
    const categories = formData.type === 'tech' ? [
        { value: 'hackathon', label: 'Hackathon' },
        { value: 'workshop', label: 'Tech Workshop' },
        { value: 'quiz', label: 'Tech Quiz' },
        { value: 'webinar', label: 'Webinar' },
    ] : [
        { value: 'cultural_fest', label: 'Cultural Fest' },
        { value: 'seminar', label: 'Seminar' },
        { value: 'live_show', label: 'Live Show' },
        { value: 'exhibition', label: 'Exhibition' },
        { value: 'other', label: 'Other' }
    ];

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!eventToEdit && !banner) {
            toast.error("Please upload a banner image!");
            return;
        }

        setLoading(true);
        try {
            // Pre-process date fields
            const dataToSubmit = { ...formData };
            // Note: eventService handles Timestamp conversion for startDate/endDate. 
            // We might need to ensure registrationDeadline is handled there too or convert here if service doesn't.
            // Let's rely on service or update service later. For now, strings are passed, service handles start/end.

            if (eventToEdit) {
                await updateEvent(eventToEdit.id, dataToSubmit);
                toast.success("Event Updated Successfully!");
            } else {
                await createEvent(dataToSubmit, banner);
                toast.success("Event Created Successfully!");
            }
            onEventAdded();
            onClose();
        } catch (error) {
            console.error(error);
            toast.error(`Failed to ${eventToEdit ? 'update' : 'create'} event.`);
        } finally {
            setLoading(false);
        }
    };

    const handleBannerChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setBanner(file);
            setBannerPreview(URL.createObjectURL(file));
        }
    };

    if (!isOpen) return null;

    const tabs = [
        { id: 'basic', label: 'Basic Info', icon: FileText },
        { id: 'details', label: 'Details', icon: Type },
        { id: 'logistics', label: 'Logistics', icon: MapPin },
        { id: 'extras', label: 'Extras', icon: Trophy },
    ];

    return (
        <AnimatePresence>
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
                <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="bg-white dark:bg-gray-800 rounded-2xl w-full max-w-4xl h-[90vh] flex flex-col shadow-2xl border border-gray-100 dark:border-gray-700 overflow-hidden"
                >
                    {/* Header */}
                    <div className="p-6 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center bg-gray-50 dark:bg-gray-800/50">
                        <div>
                            <h2 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                                {eventToEdit ? <><CheckCircle className="text-blue-500" /> Edit Event</> : <><CheckCircle className="text-green-500" /> Create New Event</>}
                            </h2>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Fill in the details to publish to the campus hub.</p>
                        </div>
                        <button onClick={onClose} className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full transition-colors">
                            <X size={24} className="text-gray-500" />
                        </button>
                    </div>

                    <div className="flex flex-1 overflow-hidden">
                        {/* Sidebar Tabs */}
                        <div className="w-64 bg-gray-50 dark:bg-gray-800/30 border-r border-gray-100 dark:border-gray-700 p-4 space-y-2 hidden md:block">
                            {tabs.map(tab => (
                                <button
                                    key={tab.id}
                                    onClick={() => setActiveTab(tab.id)}
                                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === tab.id
                                            ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30'
                                            : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
                                        }`}
                                >
                                    <tab.icon size={18} />
                                    {tab.label}
                                </button>
                            ))}
                        </div>

                        {/* Form Content */}
                        <div className="flex-1 overflow-y-auto p-6 md:p-8">
                            <form onSubmit={handleSubmit} className="space-y-8">

                                {/* Basic Info Tab */}
                                {activeTab === 'basic' && (
                                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">

                                        {/* Banner */}
                                        <div className="space-y-2">
                                            <label className="label">Event Banner</label>
                                            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl h-48 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-500 transition-colors bg-gray-50 dark:bg-gray-900/50 relative overflow-hidden group">
                                                <input type="file" accept="image/*" onChange={handleBannerChange} className="absolute inset-0 opacity-0 cursor-pointer z-10" />
                                                {bannerPreview ? (
                                                    <img src={bannerPreview} alt="Preview" className="absolute inset-0 w-full h-full object-cover" />
                                                ) : (
                                                    <div className="text-center p-4">
                                                        <Upload className="w-10 h-10 text-gray-400 mb-2 mx-auto" />
                                                        <span className="text-sm text-gray-500">Drag & drop or click to upload</span>
                                                    </div>
                                                )}
                                                {bannerPreview && (
                                                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                                        <span className="text-white font-medium">Change Image</span>
                                                    </div>
                                                )}
                                            </div>
                                        </div>

                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                            <div className="form-group">
                                                <label className="label">Event Title</label>
                                                <input
                                                    required
                                                    type="text"
                                                    value={formData.title}
                                                    onChange={e => setFormData({ ...formData, title: e.target.value })}
                                                    className="input-field"
                                                    placeholder="e.g. Annual Tech Fest 2024"
                                                />
                                            </div>
                                            <div className="form-group">
                                                <label className="label">Event Type</label>
                                                <select
                                                    value={formData.type}
                                                    onChange={(e) => {
                                                        const newType = e.target.value;
                                                        setFormData(prev => ({
                                                            ...prev,
                                                            type: newType,
                                                            category: newType === 'tech' ? 'hackathon' : 'cultural_fest'
                                                        }));
                                                    }}
                                                    className="input-field"
                                                >
                                                    <option value="cultural">Campus Event (Cultural)</option>
                                                    <option value="tech">Tech Hub (Hackathon)</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div className="form-group">
                                            <label className="label">Category</label>
                                            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                                {categories.map(cat => (
                                                    <button
                                                        type="button"
                                                        key={cat.value}
                                                        onClick={() => setFormData({ ...formData, category: cat.value })}
                                                        className={`px-4 py-2 rounded-lg text-sm font-medium border transition-all ${formData.category === cat.value
                                                                ? 'bg-indigo-50 dark:bg-indigo-900/30 border-indigo-500 text-indigo-600 dark:text-indigo-400'
                                                                : 'border-gray-200 dark:border-gray-700 text-gray-500 hover:bg-gray-50 dark:hover:bg-gray-800'
                                                            }`}
                                                    >
                                                        {cat.label}
                                                    </button>
                                                ))}
                                            </div>
                                        </div>
                                    </motion.div>
                                )}

                                {/* Details Tab */}
                                {activeTab === 'details' && (
                                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
                                        <div className="form-group">
                                            <label className="label">Full Description</label>
                                            <textarea
                                                required
                                                value={formData.description}
                                                onChange={e => setFormData({ ...formData, description: e.target.value })}
                                                className="input-field min-h-[150px]"
                                                placeholder="Describe the event, agenda, and excitement..."
                                            />
                                        </div>

                                        <div className="form-group">
                                            <label className="label">Rules & Guidelines</label>
                                            <textarea
                                                value={formData.rules}
                                                onChange={e => setFormData({ ...formData, rules: e.target.value })}
                                                className="input-field min-h-[100px]"
                                                placeholder="- Rule 1&#10;- Rule 2&#10;- Rule 3"
                                            />
                                        </div>

                                        <div className="form-group">
                                            <label className="label">Sponsors / Partners (Optional)</label>
                                            <input
                                                type="text"
                                                value={formData.sponsors}
                                                onChange={e => setFormData({ ...formData, sponsors: e.target.value })}
                                                className="input-field"
                                                placeholder="e.g. Google, Red Bull (Comma separated)"
                                            />
                                        </div>
                                    </motion.div>
                                )}

                                {/* Logistics Tab */}
                                {activeTab === 'logistics' && (
                                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                            <div className="form-group">
                                                <label className="label">Start Date & Time</label>
                                                <input type="datetime-local" required value={formData.startDate} onChange={e => setFormData({ ...formData, startDate: e.target.value })} className="input-field" />
                                            </div>
                                            <div className="form-group">
                                                <label className="label">End Date & Time</label>
                                                <input type="datetime-local" required value={formData.endDate} onChange={e => setFormData({ ...formData, endDate: e.target.value })} className="input-field" />
                                            </div>
                                        </div>

                                        <div className="form-group">
                                            <label className="label">Venue / Location</label>
                                            <div className="relative">
                                                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                                                <input type="text" required value={formData.venue} onChange={e => setFormData({ ...formData, venue: e.target.value })} className="input-field pl-10" placeholder="e.g. Main Auditorium" />
                                            </div>
                                        </div>

                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                            <div className="form-group">
                                                <label className="label">Coordinator Name</label>
                                                <input type="text" value={formData.coordinatorName} onChange={e => setFormData({ ...formData, coordinatorName: e.target.value })} className="input-field" placeholder="Name" />
                                            </div>
                                            <div className="form-group">
                                                <label className="label">Coordinator Phone</label>
                                                <input type="tel" value={formData.coordinatorPhone} onChange={e => setFormData({ ...formData, coordinatorPhone: e.target.value })} className="input-field" placeholder="Phone" />
                                            </div>
                                        </div>
                                    </motion.div>
                                )}

                                {/* Extras Tab */}
                                {activeTab === 'extras' && (
                                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
                                        <div className="form-group">
                                            <label className="label flex items-center justify-between">
                                                Registration Link
                                                <span className="text-xs font-normal text-gray-500">(Leave empty if no registration)</span>
                                            </label>
                                            <div className="relative">
                                                <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                                                <input type="url" value={formData.registrationLink} onChange={e => setFormData({ ...formData, registrationLink: e.target.value })} className="input-field pl-10" placeholder="https://forms.google.com/..." />
                                            </div>
                                        </div>

                                        <div className="form-group">
                                            <label className="label">Registration Deadline</label>
                                            <input type="datetime-local" value={formData.registrationDeadline} onChange={e => setFormData({ ...formData, registrationDeadline: e.target.value })} className="input-field" />
                                        </div>

                                        <div className="form-group">
                                            <label className="label">Target Audience</label>
                                            <input type="text" value={formData.audience} onChange={e => setFormData({ ...formData, audience: e.target.value })} className="input-field" placeholder="e.g. Open to all years, CS Dept only" />
                                        </div>

                                        {/* Hackathon Specifics */}
                                        {formData.type === 'tech' && (
                                            <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl border border-indigo-100 dark:border-indigo-800 space-y-4">
                                                <h4 className="font-bold text-indigo-700 dark:text-indigo-300 flex items-center gap-2">
                                                    <Trophy size={18} /> Hackathon Specs
                                                </h4>

                                                <div className="form-group">
                                                    <label className="label">Prize Pool</label>
                                                    <div className="relative">
                                                        <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                                                        <input type="text" value={formData.prizePool} onChange={e => setFormData({ ...formData, prizePool: e.target.value })} className="input-field pl-10" placeholder="e.g. ₹50,000" />
                                                    </div>
                                                </div>

                                                <div className="grid grid-cols-2 gap-4">
                                                    <div className="form-group">
                                                        <label className="label">Min Team Size</label>
                                                        <input type="number" min="1" value={formData.teamSizeMin} onChange={e => setFormData({ ...formData, teamSizeMin: e.target.value })} className="input-field" />
                                                    </div>
                                                    <div className="form-group">
                                                        <label className="label">Max Team Size</label>
                                                        <input type="number" min="1" value={formData.teamSizeMax} onChange={e => setFormData({ ...formData, teamSizeMax: e.target.value })} className="input-field" />
                                                    </div>
                                                </div>
                                            </div>
                                        )}
                                    </motion.div>
                                )}
                            </form>
                        </div>
                    </div>

                    {/* Footer Actions */}
                    <div className="p-6 border-t border-gray-100 dark:border-gray-700 bg-white dark:bg-gray-800 flex justify-end gap-3 z-10">
                        <button
                            onClick={onClose}
                            className="px-6 py-2.5 rounded-xl font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={handleSubmit}
                            disabled={loading}
                            className="px-8 py-2.5 rounded-xl font-bold bg-indigo-600 text-white shadow-lg shadow-indigo-500/30 hover:bg-indigo-700 transition-all flex items-center gap-2"
                        >
                            {loading ? <span className="animate-spin">⏳</span> : <><CheckCircle size={18} /> Save Event</>}
                        </button>
                    </div>
                </motion.div>

                {/* CSS Helper for Labels/Inputs */}
                <style>{`
                    .label { display: block; font-size: 0.875rem; font-weight: 600; color: #374151; margin-bottom: 0.5rem; }
                    .dark .label { color: #D1D5DB; }
                    .input-field { 
                        width: 100%; padding: 0.75rem 1rem; border-radius: 0.75rem; 
                        border: 1px solid #E5E7EB; background-color: #F9FAFB; 
                        color: #111827; outline: none; transition: all 0.2s;
                    }
                    .input-field:focus { box-shadow: 0 0 0 2px #6366F1; border-color: #6366F1; }
                    .dark .input-field { 
                        border-color: #4B5563; background-color: #374151; color: #FFFFFF; 
                    }
                `}</style>
            </div>
        </AnimatePresence>
    );
};

export default AdminEventModal;
