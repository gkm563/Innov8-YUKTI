import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Loader2 } from 'lucide-react';

const RequireAdmin = ({ children }) => {
    const { user, isAdmin, loading } = useAuth();
    const location = useLocation();

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-background-light dark:bg-background-dark">
                <Loader2 className="animate-spin h-10 w-10 text-primary-500" />
            </div>
        );
    }

    if (!user || !isAdmin) {
        // Redirect to admin login if not admin
        return <Navigate to="/admin" state={{ from: location }} replace />;
    }

    return children;
};

export default RequireAdmin;
