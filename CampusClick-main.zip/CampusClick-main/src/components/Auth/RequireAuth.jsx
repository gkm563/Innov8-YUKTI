import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Loader2 } from 'lucide-react';

const RequireAuth = ({ children }) => {
    const { user, loading, isBlocked } = useAuth();
    const location = useLocation();

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-background-light dark:bg-background-dark">
                <Loader2 className="animate-spin h-10 w-10 text-primary-500" />
            </div>
        );
    }

    if (!user) {
        return <Navigate to="/auth/login" state={{ from: location }} replace />;
    }

    if (isBlocked) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center bg-background-light dark:bg-background-dark p-4 text-center">
                <h1 className="text-2xl font-bold text-error mb-2">Access Denied</h1>
                <p className="text-surface-600 dark:text-surface-300">Your account has been restricted. Please contact support.</p>
            </div>
        );
    }

    return children;
};

export default RequireAuth;
