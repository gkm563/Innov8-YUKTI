import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Heart, Calendar, Image as ImageIcon } from 'lucide-react';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db } from '../services/firebase';
import ImageModal from './ImageModal';

const UserUploadsModal = ({ isOpen, onClose, user }) => {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedPost, setSelectedPost] = useState(null);
    const [isImageModalOpen, setIsImageModalOpen] = useState(false);

    useEffect(() => {
        if (isOpen && user) {
            fetchUserPosts();
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = 'unset';
            setPosts([]);
        }
    }, [isOpen, user]);

    const fetchUserPosts = async () => {
        setLoading(true);
        try {
            const q = query(
                collection(db, 'posts'),
                where('uploadedBy.uid', '==', user.id)
            );
            const snapshot = await getDocs(q);
            const userPosts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

            // Client-side sort to avoid index requirement
            userPosts.sort((a, b) => {
                const timeA = a.createdAt?.seconds || 0;
                const timeB = b.createdAt?.seconds || 0;
                return timeB - timeA;
            });

            setPosts(userPosts);
        } catch (error) {
            console.error("Error fetching user posts:", error);
        } finally {
            setLoading(false);
        }
    };

    if (!isOpen || !user) return null;

    return (
        <AnimatePresence>
            {isOpen && (
                <>
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-40 bg-black/80 backdrop-blur-sm"
                        onClick={onClose}
                    />
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: 20 }}
                        className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none"
                    >
                        <div className="bg-surface-50 dark:bg-surface-900 w-full max-w-5xl h-[80vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col pointer-events-auto border border-surface-200 dark:border-surface-700">

                            {/* Header */}
                            <div className="p-6 border-b border-surface-200 dark:border-surface-700 flex justify-between items-center bg-surface-100 dark:bg-surface-800">
                                <div className="flex items-center gap-4">
                                    <div className="relative">
                                        <img
                                            src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName}&background=random`}
                                            alt={user.displayName}
                                            className="w-16 h-16 rounded-full border-4 border-surface-50 dark:border-surface-700 shadow-md"
                                        />
                                        <div className="absolute -bottom-1 -right-1 bg-primary-600 text-white text-xs font-bold px-2 py-0.5 rounded-full border-2 border-surface-100 dark:border-surface-800">
                                            #{user.rank || 'N/A'}
                                        </div>
                                    </div>
                                    <div>
                                        <h2 className="text-2xl font-bold text-surface-900 dark:text-white">{user.displayName}</h2>
                                        <p className="text-surface-500">{posts.length} Contributions</p>
                                    </div>
                                </div>
                                <button onClick={onClose} className="p-2 hover:bg-surface-200 dark:hover:bg-surface-700 rounded-full transition-colors">
                                    <X size={24} className="text-surface-500" />
                                </button>
                            </div>

                            {/* Content */}
                            <div className="flex-1 overflow-y-auto p-6 bg-surface-50 dark:bg-surface-900 text-surface-900 dark:text-white">
                                {loading ? (
                                    <div className="flex items-center justify-center h-full">
                                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
                                    </div>
                                ) : posts.length > 0 ? (
                                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                                        {posts.map(post => (
                                            <motion.div
                                                key={post.id}
                                                whileHover={{ scale: 1.02 }}
                                                className="aspect-square rounded-xl overflow-hidden cursor-pointer relative group bg-surface-200 dark:bg-surface-800"
                                                onClick={() => { setSelectedPost(post); setIsImageModalOpen(true); }}
                                            >
                                                <img src={post.imageUrl} alt={post.caption} className="w-full h-full object-cover" />
                                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white font-bold">
                                                    <Heart size={16} className="fill-white" /> {post.likes || 0}
                                                </div>
                                            </motion.div>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="flex flex-col items-center justify-center h-full text-surface-400">
                                        <ImageIcon size={48} className="mb-4 opacity-50" />
                                        <p>No uploads yet.</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </motion.div>

                    {/* View Image Modal */}
                    <ImageModal
                        isOpen={isImageModalOpen}
                        onClose={() => setIsImageModalOpen(false)}
                        post={selectedPost}
                    />
                </>
            )}
        </AnimatePresence>
    );
};

export default UserUploadsModal;
