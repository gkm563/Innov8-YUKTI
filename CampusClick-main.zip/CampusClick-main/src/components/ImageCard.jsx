import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Trash2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { doc, updateDoc, increment, arrayUnion, arrayRemove, deleteDoc } from 'firebase/firestore';
import { db } from '../services/firebase';
import { toast } from 'react-toastify';
import Card from './ui/Card';

const ImageCard = ({ post, onClick }) => {
  const { user, isAdmin } = useAuth();

  // Safe defaults
  const initialLikes = post.likes || 0;

  const [likesCount, setLikesCount] = useState(initialLikes);
  const [isLiked, setIsLiked] = useState(user && post.likedBy?.includes(user.uid));
  const [isLikeLoading, setIsLikeLoading] = useState(false);

  const handleLike = async (e) => {
    e.stopPropagation(); // Stop opening the modal

    if (!user) {
      toast.info("Please login to like memories.", {
        icon: "🔒"
      });
      return;
    }
    if (isLikeLoading) return;

    setIsLikeLoading(true);

    // Optimistic Update
    const previousLikes = likesCount;
    const previousIsLiked = isLiked;

    const newIsLiked = !isLiked;
    const newLikesCount = newIsLiked ? likesCount + 1 : likesCount - 1;

    setLikesCount(newLikesCount);
    setIsLiked(newIsLiked);

    try {
      const postRef = doc(db, 'posts', post.id);
      if (previousIsLiked) {
        // Unliking
        await updateDoc(postRef, {
          likes: increment(-1),
          likedBy: arrayRemove(user.uid)
        });
      } else {
        // Liking
        await updateDoc(postRef, {
          likes: increment(1),
          likedBy: arrayUnion(user.uid)
        });
      }
    } catch (error) {
      console.error("Like error:", error);
      toast.error("Failed to update like");
      // Revert
      setLikesCount(previousLikes);
      setIsLiked(previousIsLiked);
    } finally {
      setIsLikeLoading(false);
    }
  };

  const handleDelete = async (e) => {
    e.stopPropagation();
    if (window.confirm("Are you sure you want to delete this post?")) {
      try {
        await deleteDoc(doc(db, 'posts', post.id));
        toast.success("Post deleted.");
      } catch (error) {
        toast.error("Failed to delete post.");
      }
    }
  }

  const canDelete = user && (user.uid === post.uploadedBy?.uid || isAdmin);

  return (
    <Card
      variant="glass"
      hoverEffect={true}
      onClick={() => onClick(post)}
      className="break-inside-avoid mb-6 cursor-pointer group border-surface-200 dark:border-surface-700/50 p-0 overflow-hidden"
    >
      <div className="relative overflow-hidden">
        <img
          src={post.imageUrl}
          alt={post.category || 'Memory'}
          className="w-full h-auto object-cover transform group-hover:scale-105 transition-transform duration-700 ease-out"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Admin/Owner Actions */}
        {canDelete && (
          <div className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button
              className="p-2 bg-red-600/80 hover:bg-red-600 text-white rounded-full shadow-lg backdrop-blur-sm transition-colors"
              onClick={handleDelete}
              title="Delete Post"
            >
              <Trash2 size={16} />
            </button>
          </div>
        )}
      </div>

      <div className="p-3 flex items-center justify-between bg-surface-50 dark:bg-surface-800/50 backdrop-blur-sm border-t border-surface-200 dark:border-surface-700/50">
        <div className="flex items-center gap-2">
          {post.uploadedBy?.photoURL ? (
            <img
              src={post.uploadedBy.photoURL}
              alt={post.userName || 'User'}
              className="w-7 h-7 rounded-full object-cover border border-primary-200 dark:border-primary-500/30"
              loading="lazy"
            />
          ) : (
            <div className="w-7 h-7 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center text-primary-600 dark:text-primary-400 text-xs font-bold border border-primary-200 dark:border-primary-500/30">
              {post.userInitial || (post.userName ? post.userName[0] : 'U')}
            </div>
          )}
          <span className="text-xs font-medium text-surface-700 dark:text-surface-300 truncate max-w-[100px]">
            {post.userName || 'Contributor'}
          </span>
        </div>

        <button
          onClick={handleLike}
          className={`flex items-center gap-1 transition-all px-2 py-1 rounded-full text-xs font-medium
                ${isLiked
              ? 'bg-red-500/10 text-red-500 hover:bg-red-500/20'
              : 'text-surface-500 dark:text-surface-400 hover:text-red-500 hover:bg-surface-100 dark:hover:bg-surface-700'
            }`}
        >
          <Heart className={`w-3.5 h-3.5 transition-transform ${isLiked ? 'fill-current scale-110' : 'group-hover:scale-110'}`} />
          <span>{likesCount}</span>
        </button>
      </div>
    </Card>
  );
};

export default ImageCard;
