import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, LogOut, User, LayoutDashboard, Sun, Moon, ChevronRight } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import Button from '../ui/Button';

const Header = () => {
    const { user, logout, isAdmin } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    const { theme, toggleTheme } = useTheme();
    const [isScrolled, setIsScrolled] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 20);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const handleLogOut = async () => {
        try {
            await logout();
            navigate('/');
        } catch (error) {
            console.error("Failed to log out", error);
        }
    };

    const navLinks = [
        { name: 'Gallery', path: '/gallery' },
        { name: 'Events', path: '/events' },
        { name: 'Timeline', path: '/timeline' },
        { name: 'Insights', path: '/insights' },
        { name: 'Leaderboard', path: '/leaderboard' },
        { name: 'Tech Hub', path: '/tech-hub' },
    ];

    if (user && !isAdmin) {
        navLinks.push({ name: 'Dashboard', path: '/dashboard' });
    }

    if (isAdmin) {
        navLinks.push({ name: 'Admin Panel', path: '/admin/dashboard' });
    }

    const isAuthPage = location.pathname.startsWith('/auth') || location.pathname.startsWith('/admin/');
    const showBackground = isScrolled || isAuthPage;

    return (
        <motion.header
            initial={{ y: -100 }}
            animate={{ y: 0 }}
            className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'py-2' : 'py-4'}`}
        >
            <div className={`mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 transition-all duration-300 ${isScrolled ? 'w-[95%] md:w-[90%]' : 'w-full'}`}>
                <div className={`relative flex items-center justify-between px-6 py-3 transition-all duration-300 ${showBackground
                    ? 'bg-white/80 dark:bg-surface-950/80 backdrop-blur-xl border border-surface-200/50 dark:border-surface-800/50 rounded-full shadow-lg shadow-black/5 dark:shadow-black/20'
                    : 'bg-transparent'
                    }`}>

                    {/* Logo */}
                    <Link to="/" className="flex items-center gap-2 group flex-shrink-0">
                        <div className="w-9 h-9 rounded-xl bg-primary-600 flex items-center justify-center text-white font-bold text-lg shadow-lg shadow-primary-500/30 group-hover:scale-105 transition-transform">
                            V
                        </div>
                        <span className="hidden sm:block text-xl font-display font-bold tracking-tight text-surface-900 dark:text-white group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
                            CampusClick
                        </span>
                    </Link>



                    {/* Desktop Navigation */}
                    <nav className="hidden xl:flex items-center gap-6">
                        {navLinks.map((link) => (
                            <Link
                                key={link.path}
                                to={link.path}
                                className={`text-sm font-medium transition-colors hover:text-primary-600 dark:hover:text-primary-400 relative group px-2 py-1 ${location.pathname === link.path ? 'text-primary-600 dark:text-primary-400' : 'text-surface-600 dark:text-surface-300'
                                    }`}
                            >
                                {link.name}
                                {location.pathname === link.path && (
                                    <motion.span
                                        layoutId="underline"
                                        className="absolute -bottom-1 left-0 w-full h-0.5 bg-primary-600 dark:bg-primary-400 rounded-full"
                                    />
                                )}
                            </Link>
                        ))}
                    </nav>

                    {/* Right Section */}
                    <div className="hidden md:flex items-center gap-3 flex-shrink-0">
                        <button
                            onClick={toggleTheme}
                            className="p-2 text-surface-500 dark:text-surface-400 hover:text-surface-900 dark:hover:text-white transition-colors rounded-full hover:bg-surface-100 dark:hover:bg-surface-800"
                        >
                            {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
                        </button>

                        {user ? (
                            <div className="flex items-center gap-3 pl-3 border-l border-surface-200 dark:border-surface-700">
                                <Link to="/profile">
                                    <img
                                        src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName || 'User'}&background=random`}
                                        alt="Profile"
                                        className="w-9 h-9 rounded-full ring-2 ring-transparent hover:ring-primary-500 transition-all object-cover cursor-pointer"
                                    />
                                </Link>
                                <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={handleLogOut}
                                    className="!p-2 text-error hover:bg-error/10 hover:text-error"
                                    title="Sign Out"
                                >
                                    <LogOut size={18} />
                                </Button>
                            </div>
                        ) : (
                            <div className="flex items-center gap-3">
                                <Link to="/auth/login">
                                    <Button variant="ghost" size="sm">Login</Button>
                                </Link>
                                <Link to="/auth/register">
                                    <Button variant="primary" size="sm" className="shadow-lg shadow-primary-500/25">Get Started</Button>
                                </Link>
                            </div>
                        )}
                    </div>

                    {/* Mobile Menu Button */}
                    <button
                        className="md:hidden p-2 text-surface-600 dark:text-surface-300 hover:text-surface-900 dark:hover:text-white"
                        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                    >
                        {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
                    </button>
                </div>
            </div>

            {/* Mobile Menu Overlay */}
            <AnimatePresence>
                {isMobileMenuOpen && (
                    <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="md:hidden bg-white/95 dark:bg-background-dark/95 backdrop-blur-xl border-t border-surface-200 dark:border-surface-800 overflow-hidden absolute top-full left-0 right-0 shadow-xl"
                    >
                        <div className="flex flex-col p-4 space-y-2">
                            {navLinks.map((link) => (
                                <Link
                                    key={link.path}
                                    to={link.path}
                                    onClick={() => setIsMobileMenuOpen(false)}
                                    className="flex items-center justify-between text-lg font-medium text-surface-600 dark:text-surface-300 p-3 hover:bg-surface-50 dark:hover:bg-surface-800 rounded-xl transition-colors"
                                >
                                    {link.name} <ChevronRight size={16} className="opacity-50" />
                                </Link>
                            ))}
                            <div className="my-2 border-t border-surface-200 dark:border-surface-800"></div>
                            {user ? (
                                <>
                                    <Link to="/profile" onClick={() => setIsMobileMenuOpen(false)} className="flex items-center gap-3 p-3 text-surface-600 dark:text-surface-300 hover:bg-surface-50 dark:hover:bg-surface-800 rounded-xl">
                                        <User size={18} /> Profile
                                    </Link>
                                    <button onClick={() => { handleLogOut(); setIsMobileMenuOpen(false); }} className="flex items-center gap-3 p-3 text-error w-full text-left hover:bg-error/5 rounded-xl">
                                        <LogOut size={18} /> Sign Out
                                    </button>
                                </>
                            ) : (
                                <div className="grid grid-cols-2 gap-3 mt-2">
                                    <Link to="/auth/login" onClick={() => setIsMobileMenuOpen(false)}>
                                        <Button variant="ghost" className="w-full justify-center">Login</Button>
                                    </Link>
                                    <Link to="/auth/register" onClick={() => setIsMobileMenuOpen(false)}>
                                        <Button variant="primary" className="w-full justify-center">Sign Up</Button>
                                    </Link>
                                </div>
                            )}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </motion.header>
    );
};

export default Header;
