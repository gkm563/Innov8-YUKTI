import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Shield, LayoutDashboard, Image as ImageIcon, Calendar, Sun, Moon, LogOut, Menu, X, Users, Activity } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

const AdminLayout = ({ children }) => {
    const navigate = useNavigate();
    const location = useLocation();
    const { theme, toggleTheme } = useTheme();
    const [isSidebarOpen, setIsSidebarOpen] = useState(false); // Default closed on mobile

    const isActive = (path) => location.pathname === path;

    return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white transition-colors duration-300 flex">

            {/* Mobile Sidebar Toggle */}
            <div className="fixed top-20 left-4 z-50 lg:hidden">
                <button
                    onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                    className="p-2 bg-white dark:bg-gray-800 rounded-lg shadow-md border border-gray-200 dark:border-gray-700"
                >
                    {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
                </button>
            </div>

            {/* Sidebar */}
            <aside className={`fixed inset-y-0 left-0 z-40 w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 transition-transform duration-300 pt-24 pb-4`}>
                <div className="h-full flex flex-col px-4">
                    <div className="mb-8 px-2">
                        <div className="flex items-center gap-2 mb-2">
                            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
                                <Shield size={18} fill="currentColor" />
                            </div>
                            <h2 className="text-lg font-black text-gray-800 dark:text-white uppercase tracking-tight">Admin<span className="text-indigo-600">Portal</span></h2>
                        </div>
                        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-green-100 dark:bg-green-900/30 border border-green-200 dark:border-green-800">
                            <span className="relative flex h-2 w-2">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                            </span>
                            <span className="text-[10px] font-bold text-green-700 dark:text-green-400 uppercase tracking-wider">System Online</span>
                        </div>
                    </div>

                    <nav className="flex-1 space-y-2">
                        <button
                            onClick={() => navigate('/admin/dashboard?section=memories')}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/admin/dashboard') && (!location.search || location.search.includes('memories')) ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-300' : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700'}`}
                        >
                            <LayoutDashboard size={18} /> Overview
                        </button>
                        <button
                            onClick={() => navigate('/admin/dashboard?section=events')}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/admin/dashboard') && location.search.includes('events') ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-300' : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700'}`}
                        >
                            <Calendar size={18} /> Events & Hackathons
                        </button>
                        <button
                            onClick={() => navigate('/admin/users')}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/admin/users') ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-300' : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700'}`}
                        >
                            <Users size={18} /> User Management
                        </button>
                        <button
                            onClick={() => navigate('/admin/moderation')}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/admin/moderation') ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-300' : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700'}`}
                        >
                            <Shield size={18} /> Moderation
                        </button>
                        <button
                            onClick={() => navigate('/admin/activity')}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/admin/activity') ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-300' : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700'}`}
                        >
                            <Activity size={18} /> Activity Log
                        </button>
                    </nav>

                    <div className="pt-4 border-t border-gray-200 dark:border-gray-700 space-y-2">
                        <button
                            onClick={toggleTheme}
                            className="w-full flex items-center gap-3 px-4 py-3 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-xl transition-all font-medium"
                        >
                            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
                            {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
                        </button>
                        <button
                            onClick={() => { localStorage.removeItem('isAdmin'); navigate('/'); }}
                            className="w-full flex items-center gap-3 px-4 py-3 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-all font-medium"
                        >
                            <LogOut size={18} /> Secure Exit
                        </button>
                    </div>
                </div>
            </aside>

            {/* Main Content Wrapper */}
            <main className="flex-1 lg:ml-64 p-4 lg:p-8 pt-24 overflow-y-auto min-h-screen">
                {children}
            </main>
        </div>
    );
};

export default AdminLayout;
