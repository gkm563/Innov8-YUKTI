import React from 'react';
import { Link } from 'react-router-dom';
import { Github, Twitter, Linkedin, Heart, Shield, HelpCircle, FileText, Map, Zap, Facebook, Instagram, Youtube, Chrome, Globe } from 'lucide-react';

const Footer = () => {
    return (
        <footer className="bg-surface-50 dark:bg-surface-900 border-t border-surface-200 dark:border-surface-800 pt-16 pb-8 text-sm transition-colors duration-300">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
                    {/* Column 1: Platform */}
                    <div>
                        <div className="flex items-center gap-2 mb-6">
                            <div className="w-8 h-8 rounded-xl bg-primary-600 flex items-center justify-center text-white font-bold shadow-lg shadow-primary-500/30">C</div>
                            <span className="text-xl font-display font-bold text-surface-900 dark:text-white">CampusClick</span>
                        </div>
                        <p className="text-surface-500 dark:text-surface-400 mb-6 leading-relaxed">
                            Preserving our college's digital legacy through AI. Bridging the gap between seniors and juniors, one memory at a time.
                        </p>
                        <div className="flex gap-3 flex-wrap">
                            <SocialIcon icon={<Linkedin size={18} />} href="https://linkedin.com/in/gkm563" color="hover:bg-[#0077b5]" />
                            <SocialIcon icon={<Twitter size={18} />} href="https://twitter.com/gkm563" color="hover:bg-[#1DA1F2]" />
                            <SocialIcon icon={<Github size={18} />} href="https://github.com/gkm563" color="hover:bg-black dark:hover:bg-white dark:hover:text-black" />
                            <SocialIcon icon={<Instagram size={18} />} href="https://instagram.com/gkm3563" color="hover:bg-gradient-to-tr hover:from-yellow-400 hover:via-red-500 hover:to-purple-500" />
                            <SocialIcon icon={<Facebook size={18} />} href="https://facebook.com/gkm563" color="hover:bg-[#1877F2]" />
                            <SocialIcon icon={<Youtube size={18} />} href="https://www.youtube.com/@GKM563" color="hover:bg-[#FF0000]" />
                            <SocialIcon icon={<Chrome size={18} />} href="https://www.google.com/search?q=who+is+gautam+kumar+maurya+gkm&oq=who+is&gs_lcrp=EgZjaHJvbWUqBggBECMYJzIKCAAQRRixAxiABDIGCAEQIxgnMgYIAhAjGCcyBwgDEAAYgAQyEAgEEAAYgwEYsQMYgAQYigUyCggFEAAYsQMYgAQyBwgGEAAYgAQyBggHEEUYPNIBCDg0ODFqMGoxqAIAsAIA&sourceid=chrome&ie=UTF-8" color="hover:bg-[#4285F4]" />
                            <SocialIcon icon={<Globe size={18} />} href="https://gkm563.github.io/gkmportfolio/" color="hover:bg-emerald-500" />
                        </div>
                    </div>

                    {/* Column 2: Discover */}
                    <div>
                        <h3 className="text-surface-900 dark:text-white font-bold mb-6">Discover</h3>
                        <ul className="space-y-4">
                            <FooterLink to="/about" icon={<Heart size={16} />} label="About Us" />
                            <FooterLink to="/gallery" icon={<FileText size={16} />} label="Smart Gallery" />
                            <FooterLink to="/features" icon={<Zap size={16} />} label="Features" />
                            <FooterLink to="/security" icon={<Shield size={16} />} label="Security & AI" />
                        </ul>
                    </div>

                    {/* Column 3: Support */}
                    <div>
                        <h3 className="text-surface-900 dark:text-white font-bold mb-6">Support</h3>
                        <ul className="space-y-4">
                            <FooterLink to="/help" icon={<HelpCircle size={16} />} label="Help Center" />
                            <FooterLink to="/sitemap" icon={<Map size={16} />} label="Site Map" />
                            <FooterLink to="/contact" label="Contact Us" />
                        </ul>
                    </div>

                    {/* Column 4: Legal */}
                    <div>
                        <h3 className="text-surface-900 dark:text-white font-bold mb-6">Legal</h3>
                        <ul className="space-y-4">
                            <FooterLink to="/privacy" label="Privacy Policy" />
                            <FooterLink to="/terms" label="Terms of Use" />
                            <FooterLink to="/subscription" label="Subscription" />
                        </ul>
                    </div>
                </div>

                <div className="border-t border-surface-200 dark:border-surface-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
                    <p className="text-surface-500">
                        © {new Date().getFullYear()} CampusClick. All rights reserved. Built with <Heart size={14} className="inline text-error mx-1" /> by Team Innov8.
                    </p>
                    <div className="flex gap-6 text-surface-500">
                        <Link to="/privacy" className="hover:text-primary-500 transition-colors">Privacy</Link>
                        <Link to="/terms" className="hover:text-primary-500 transition-colors">Terms</Link>
                        <Link to="/cookies" className="hover:text-primary-500 transition-colors">Cookies</Link>
                    </div>
                </div>
            </div>
        </footer>
    );
};

const FooterLink = ({ to, icon, label }) => (
    <li>
        <Link to={to} className="text-surface-500 dark:text-surface-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors flex items-center gap-2 group">
            {icon && <span className="group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">{icon}</span>}
            {label}
        </Link>
    </li>
);

const SocialIcon = ({ icon, href, color = "hover:bg-primary-600" }) => (
    <a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        className={`w-10 h-10 rounded-full bg-surface-100 dark:bg-surface-800 flex items-center justify-center text-surface-500 dark:text-surface-400 ${color} hover:text-white transition-all transform hover:scale-110 shadow-sm`}
    >
        {icon}
    </a>
);

export default Footer;
