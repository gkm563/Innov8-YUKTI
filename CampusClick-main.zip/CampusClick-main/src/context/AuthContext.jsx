import { createContext, useContext, useEffect, useState } from "react";
import { auth, googleProvider, db } from "../services/firebase";
import { signInWithPopup, signOut, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword } from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp, addDoc, collection } from "firebase/firestore";
import { toast } from "react-toastify";
import { logActivity } from "../services/activityService";

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [userData, setUserData] = useState(null); // Firestore data (role, isBlocked, etc.)
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        // Sync with Firestore
        try {
          const userRef = doc(db, "users", currentUser.uid);
          const userSnap = await getDoc(userRef);

          if (userSnap.exists()) {
            setUserData(userSnap.data());
          } else {
            // Create new user doc if doesn't exist
            const newUserData = {
              uid: currentUser.uid,
              email: currentUser.email,
              displayName: currentUser.displayName || "User",
              photoURL: currentUser.photoURL,
              role: "user", // Default role
              isBlocked: false,
              createdAt: serverTimestamp(),
              lastLogin: serverTimestamp(),
              savedEvents: []
            };
            await setDoc(userRef, newUserData);
            setUserData(newUserData);
          }

          // Log Login (Audit) - Optional: Could limit to only explicitly triggered logins to reduce noise
          // For now, we update lastLogin in the user doc
          await setDoc(userRef, { lastLogin: serverTimestamp() }, { merge: true });

        } catch (error) {
          console.error("Error fetching user data:", error);
          toast.error("Error loading user profile.");
        }
      } else {
        setUser(null);
        setUserData(null);
      }
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const logAudit = async (event, status, details = {}) => {
    if (!user) return;
    try {
      await addDoc(collection(db, "audit_logs"), {
        event,
        uid: user.uid,
        email: user.email,
        timestamp: serverTimestamp(),
        status,
        ...details
      });
    } catch (e) {
      console.error("Audit log failed:", e);
    }
  };

  const loginWithGoogle = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      // Log Activity
      if (result.user) {
        logActivity(result.user.uid, result.user.displayName || 'Google User', 'LOGIN', 'Logged in via Google');
      }
      return result;
    } catch (error) {
      console.error("Login Error:", error);
      throw error;
    }
  };

  const login = async (email, password) => {
    try {
      const result = await signInWithEmailAndPassword(auth, email, password);
      if (result.user) {
        const name = result.user.displayName || email.split('@')[0];
        logActivity(result.user.uid, name, 'LOGIN', 'Logged in with email');
      }
      return result;
    } catch (error) {
      throw error;
    }
  }

  const signup = async (email, password) => {
    try {
      const result = await createUserWithEmailAndPassword(auth, email, password);
      if (result.user) {
        logActivity(result.user.uid, 'New User', 'SIGNUP', 'Account created');
      }
      return result;
    } catch (error) {
      throw error;
    }
  }

  const logout = async () => {
    try {
      if (user) {
        await logActivity(user.uid, user.displayName || 'User', 'LOGOUT', 'Logged out');
      }
      await signOut(auth);
      setUserData(null);
    } catch (error) {
      console.error("Logout Error:", error);
    }
  };

  // Derived Permissions
  const isAdmin = userData?.role === 'admin';
  const isBlocked = userData?.isBlocked === true;

  const value = {
    user,
    userData,
    isAdmin,
    isBlocked,
    loginWithGoogle,
    login,
    signup,
    logout,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
