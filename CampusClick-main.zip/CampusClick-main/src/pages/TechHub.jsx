import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { getEvents } from '../services/eventService';
import EventCard from '../components/EventCard';
import { Terminal, Cpu, Code, Wifi, Monitor, Filter, Search } from 'lucide-react';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';

const TechHub = () => {
    const [events, setEvents] = useState([]);
    const [filteredEvents, setFilteredEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('Upcoming');
    const [categoryFilter, setCategoryFilter] = useState('All');
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetch = async () => {
            try {
                const allEvents = await getEvents();
                // Filter only Tech type
                const techEvents = allEvents.filter(e => e.type === 'tech');
                setEvents(techEvents);
            } catch (err) {
                console.error(err);
                if (err.code === 'permission-denied') {
                    setError("Access Denied: Please check permissions.");
                } else {
                    setError("Unable to load tech events.");
                }
            } finally {
                setLoading(false);
            }
        };
        fetch();
    }, []);

    useEffect(() => {
        let result = events.filter(e => e.status === activeTab);
        if (categoryFilter !== 'All') {
            result = result.filter(e => e.category === categoryFilter.toLowerCase());
        }
        setFilteredEvents(result);
    }, [events, activeTab, categoryFilter]);

    const categories = [
        { name: 'All', icon: Terminal },
        { name: 'Hackathon', icon: Code },
        { name: 'Workshop', icon: Cpu },
        { name: 'Webinar', icon: Wifi },
        { name: 'Quiz', icon: Monitor },
    ];

    return (
        <div className="min-h-screen pt-4 pb-20 bg-background-light dark:bg-background-dark">
            {/* Morphing Background */}
            <div className="fixed inset-0 pointer-events-none overflow-hidden">
                <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary-500/10 rounded-full blur-[100px] animate-pulse-slow" />
                <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-secondary-500/10 rounded-full blur-[100px] animate-pulse-slow delay-1000" />
            </div>

            <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                {/* Header */}
                <div className="text-center mb-16 pt-8">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="inline-block px-4 py-1.5 mb-6 rounded-full glass border border-primary-500/30 text-primary-600 dark:text-primary-400 font-mono text-sm tracking-wider"
                    >
                        SYSTEM.INIT(TECH_HUB)
                    </motion.div>
                    <motion.h1
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="text-5xl md:text-7xl font-bold mb-6 font-display tracking-tight text-surface-900 dark:text-white"
                    >
                        Tech<span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-500 to-secondary-500">.Hub</span>
                    </motion.h1>
                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="text-xl text-surface-600 dark:text-surface-300 max-w-2xl mx-auto leading-relaxed"
                    >
                        Decode. Compile. Conquer. The central node for hackathons and tech innovation.
                    </motion.p>
                </div>

                <div className="flex flex-col lg:flex-row gap-10">
                    {/* Sidebar Filter */}
                    <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.3 }}
                        className="w-full lg:w-72 flex-shrink-0"
                    >
                        <Card variant="glass" className="p-6 sticky top-24 border border-surface-200 dark:border-surface-700/50">
                            <h3 className="font-bold text-surface-900 dark:text-white uppercase text-xs mb-6 tracking-widest flex items-center gap-2">
                                <Filter size={14} className="text-secondary-500" /> Filter Mode
                            </h3>
                            <div className="space-y-2">
                                {categories.map(cat => (
                                    <button
                                        key={cat.name}
                                        onClick={() => setCategoryFilter(cat.name)}
                                        className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm border ${categoryFilter === cat.name
                                            ? 'bg-primary-500/10 text-primary-600 dark:text-primary-400 border-primary-500/20 shadow-sm'
                                            : 'text-surface-600 dark:text-surface-400 border-transparent hover:bg-surface-100 dark:hover:bg-surface-800'
                                            }`}
                                    >
                                        <cat.icon size={18} className={categoryFilter === cat.name ? 'text-primary-500' : ''} />
                                        <span>{cat.name}</span>
                                    </button>
                                ))}
                            </div>
                        </Card>
                    </motion.div>

                    {/* Main Content */}
                    <div className="flex-1">
                        {/* Tabs */}
                        <div className="flex gap-4 mb-8 border-b border-surface-200 dark:border-surface-700 pb-1 overflow-x-auto">
                            {['Upcoming', 'Ongoing', 'Past'].map(tab => (
                                <button
                                    key={tab}
                                    onClick={() => setActiveTab(tab)}
                                    className={`px-4 py-3 font-medium text-sm transition-all relative whitespace-nowrap ${activeTab === tab
                                        ? 'text-primary-600 dark:text-primary-400'
                                        : 'text-surface-500 dark:text-surface-400 hover:text-surface-800 dark:hover:text-surface-200'
                                        }`}
                                >
                                    {tab}
                                    {activeTab === tab && (
                                        <motion.div
                                            layoutId="activeTabHub"
                                            className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary-500"
                                        />
                                    )}
                                </button>
                            ))}
                        </div>

                        {/* Grid */}
                        {error ? (
                            <div className="text-center py-20 rounded-2xl bg-error/5 border border-error/10">
                                <h3 className="text-lg font-bold mb-2 text-error">System Error</h3>
                                <p className="text-surface-600 dark:text-surface-400">{error}</p>
                            </div>
                        ) : loading ? (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {[1, 2, 3, 4].map(n => (
                                    <div key={n} className="h-96 rounded-2xl bg-surface-100 dark:bg-surface-800 animate-pulse" />
                                ))}
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <AnimatePresence mode="popLayout">
                                    {filteredEvents.length > 0 ? (
                                        filteredEvents.map(event => (
                                            <EventCard key={event.id} event={event} />
                                        ))
                                    ) : (
                                        <motion.div
                                            initial={{ opacity: 0 }}
                                            animate={{ opacity: 1 }}
                                            className="col-span-full py-24 text-center border-2 border-dashed border-surface-200 dark:border-surface-700 rounded-3xl"
                                        >
                                            <div className="w-16 h-16 bg-surface-100 dark:bg-surface-800 rounded-full flex items-center justify-center mx-auto mb-4 text-surface-400">
                                                <Search size={24} />
                                            </div>
                                            <p className="text-surface-500 dark:text-surface-400 font-medium">No results found in {activeTab}</p>
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </div>
                        )}

                    </div>
                </div>
            </div>
        </div>
    );
};

export default TechHub;
