import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Search, Filter, Loader2, Sparkles, Image as ImageIcon, Heart, MessageSquare, MoreVertical, X, Calendar, Share2, Grid, List as ListIcon, Upload } from 'lucide-react';
import { collection, query, orderBy, onSnapshot, where, doc, deleteDoc, updateDoc, addDoc, serverTimestamp, getDoc } from 'firebase/firestore';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../services/firebase';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import { analyzeImage } from '../services/gemini';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import SEO from '../components/SEO';
import UploadModal from '../components/UploadModal';
import CreateAlbumModal from '../components/CreateAlbumModal';
import ImageModal from '../components/ImageModal';
import UploadProgressCard from '../components/UploadProgressCard';
import EventCard from '../components/EventCard';
import { logActivity, getUserActivity } from '../services/activityService';
import { Clock, Activity, Bookmark } from 'lucide-react';

const ActivityList = ({ userId }) => {
    const [activities, setActivities] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetch = async () => {
            const data = await getUserActivity(userId);
            setActivities(data);
            setLoading(false);
        };
        if (userId) fetch();
    }, [userId]);

    if (loading) return <div className="text-center py-10"><Loader2 className="animate-spin mx-auto text-primary-500" /></div>;

    if (activities.length === 0) return (
        <div className="text-center py-12 bg-surface-50 dark:bg-surface-800 rounded-2xl border border-surface-200 dark:border-surface-700">
            <Activity className="w-12 h-12 text-surface-400 mx-auto mb-3" />
            <h3 className="text-surface-600 dark:text-surface-300">No recent activity</h3>
        </div>
    );

    return (
        <div className="space-y-4">
            {activities.map((act) => (
                <div key={act.id} className="flex items-start gap-4 p-4 bg-white dark:bg-surface-800 rounded-xl border border-surface-200 dark:border-surface-700 shadow-sm">
                    <div className={`p-2 rounded-full flex-shrink-0 ${act.action === 'LOGIN' ? 'bg-green-100 text-green-600' :
                        act.action === 'UPLOAD' ? 'bg-blue-100 text-blue-600' :
                            act.action === 'DELETE' ? 'bg-red-100 text-red-600' :
                                'bg-gray-100 text-gray-600'
                        }`}>
                        {act.action === 'LOGIN' ? <Sparkles size={16} /> :
                            act.action === 'UPLOAD' ? <ImageIcon size={16} /> :
                                act.action === 'DELETE' ? <X size={16} /> : <Activity size={16} />}
                    </div>
                    <div className="flex-1">
                        <p className="text-surface-900 dark:text-white font-medium">{act.details}</p>
                        <p className="text-xs text-surface-500 mt-1 flex items-center gap-1">
                            <Clock size={12} />
                            {act.timestamp?.toDate ? act.timestamp.toDate().toLocaleString() : 'Just now'}
                        </p>
                    </div>
                </div>
            ))}
        </div>
    );
};

const SavedEventsList = ({ savedEventIds }) => {
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchSavedEvents = async () => {
            if (!savedEventIds || savedEventIds.length === 0) {
                setLoading(false);
                return;
            }

            try {
                const eventPromises = savedEventIds.map(id => getDoc(doc(db, 'events', id)));
                const eventSnapshots = await Promise.all(eventPromises);
                const fetchedEvents = eventSnapshots
                    .filter(snap => snap.exists())
                    .map(snap => ({ id: snap.id, ...snap.data() }));
                setEvents(fetchedEvents);
            } catch (error) {
                console.error("Error fetching saved events:", error);
                toast.error("Failed to load saved events.");
            } finally {
                setLoading(false);
            }
        };

        fetchSavedEvents();
    }, [savedEventIds]);

    if (loading) return <div className="text-center py-20"><Loader2 className="animate-spin mx-auto text-primary-600" size={32} /></div>;

    if (events.length === 0) return (
        <div className="text-center py-20 bg-surface-50 dark:bg-surface-800/50 rounded-2xl border-2 border-dashed border-surface-200 dark:border-surface-700">
            <div className="w-16 h-16 bg-surface-100 dark:bg-surface-700 rounded-full flex items-center justify-center mx-auto mb-4 text-surface-400">
                <Bookmark size={32} />
            </div>
            <h3 className="text-lg font-bold text-surface-900 dark:text-white mb-1">No saved events</h3>
            <p className="text-surface-500 mb-6">Events you save will appear here for quick access.</p>
        </div>
    );

    return (
        <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {events.map(event => (
                <div key={event.id} className="h-full">
                    <EventCard event={event} />
                </div>
            ))}
        </div>
    );
};

const Dashboard = () => {
    const { user, userData } = useAuth(); // userData needed for savedEvents
    const [activeTab, setActiveTab] = useState('uploads');
    const [viewMode, setViewMode] = useState('grid');
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
    const [isAlbumModalOpen, setIsAlbumModalOpen] = useState(false);
    const [selectedPost, setSelectedPost] = useState(null);
    const [isImageModalOpen, setIsImageModalOpen] = useState(false);

    // Background Upload State
    const [uploadState, setUploadState] = useState({
        active: false,
        minimized: true,
        progress: 0,
        status: 'idle', // idle, uploading, analyzing, success, flagged, error
        file: null,
        resultMessage: ''
    });

    useEffect(() => {
        if (!user) return;

        let activeUnsubscribe = null;

        // Function to handle the snapshot update
        const handleSnapshot = (snapshot) => {
            const userPosts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

            // Client-side sort if needed (redundant if using orderBy, but harmless)
            userPosts.sort((a, b) => {
                const dateA = a.createdAt?.seconds || 0;
                const dateB = b.createdAt?.seconds || 0;
                return dateB - dateA;
            });

            setPosts(userPosts);
            setLoading(false);
        };

        // 1. Try Optimized Query (Index Required)
        const q = query(
            collection(db, 'posts'),
            where('uploadedBy.uid', '==', user.uid),
            orderBy('createdAt', 'desc')
        );

        // Wrapper to manage subscription switching
        try {
            activeUnsubscribe = onSnapshot(q, handleSnapshot, (error) => {
                console.error("Optimized query failed:", error);

                // 2. Fallback Query (No Index / Client-Side Sort)
                if (error.code === 'failed-precondition' || error.code === 'permission-denied') {
                    console.warn("Falling back to simple query (client-side sort)");
                    const fallbackQ = query(
                        collection(db, 'posts'),
                        where('uploadedBy.uid', '==', user.uid)
                    );

                    // Replace the active error-ed listener with the new one
                    activeUnsubscribe = onSnapshot(fallbackQ, handleSnapshot, (err) => {
                        console.error("Fallback query failed:", err);
                        setLoading(false);
                        if (err.code === 'permission-denied') {
                            toast.error("Access denied. Please check your connection.");
                        }
                    });
                } else {
                    setLoading(false);
                }
            });
        } catch (err) {
            console.error("Query setup error:", err);
            setLoading(false);
        }

        return () => {
            if (activeUnsubscribe) activeUnsubscribe();
        };
    }, [user]);

    const handleUploadStart = async (file, metadata, postToEdit) => {
        setUploadState({
            active: true,
            minimized: true,
            progress: 0,
            status: 'uploading',
            file: file,
            resultMessage: ''
        });

        try {
            let imageUrl = postToEdit?.imageUrl;

            // 1. Upload File (if new file)
            if (file) {
                const storageRef = ref(storage, `memories/${user.uid}/${Date.now()}_${file.name}`);
                const uploadTask = uploadBytesResumable(storageRef, file);

                uploadTask.on('state_changed',
                    (snapshot) => {
                        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                        setUploadState(prev => ({ ...prev, progress }));
                    },
                    (error) => {
                        console.error("Upload error:", error);
                        setUploadState(prev => ({ ...prev, status: 'error', resultMessage: 'Upload failed.' }));
                    },
                    async () => {
                        // Upload complete
                        imageUrl = await getDownloadURL(uploadTask.snapshot.ref);
                        setUploadState(prev => ({ ...prev, status: 'analyzing', progress: 100 }));

                        // 2. AI Analysis
                        try {
                            const aiResult = await analyzeImage(file);

                            let safetyStatus = 'approved';
                            let safetyReason = '';

                            if (!aiResult.isSafe) {
                                safetyStatus = 'pending_review';
                                safetyReason = aiResult.reason || "AI detected potential policy violation.";
                                setUploadState(prev => ({
                                    ...prev,
                                    status: 'flagged',
                                    resultMessage: `Flagged: ${safetyReason}`
                                }));
                                toast.error(`Upload Flagged: ${safetyReason}`);
                            } else {
                                setUploadState(prev => ({
                                    ...prev,
                                    status: 'success',
                                    resultMessage: 'Successfully uploaded!'
                                }));
                                toast.success("Upload Successful!");
                            }

                            // 3. Save to Firestore
                            const postData = {
                                ...metadata,
                                imageUrl,
                                userId: user.uid, // Add explicit userId for queries
                                uploadedBy: {
                                    uid: user.uid,
                                    displayName: user.displayName || 'Contributor',
                                    photoURL: user.photoURL || null
                                },
                                userName: user.displayName || 'Contributor',
                                userInitial: (user.displayName || 'C')[0].toUpperCase(),
                                status: safetyStatus,
                                flagReason: safetyReason,
                                updatedAt: serverTimestamp()
                            };

                            if (postToEdit) {
                                await updateDoc(doc(db, 'posts', postToEdit.id), postData);
                            } else {
                                await addDoc(collection(db, 'posts'), {
                                    ...postData,
                                    likes: 0,
                                    views: 0,
                                    createdAt: serverTimestamp(), // distinct from updatedAt
                                    timestamp: serverTimestamp() // Add legacy timestamp for compatibility
                                });

                                // Log Activity
                                logActivity(
                                    user.uid,
                                    user.displayName,
                                    'UPLOAD',
                                    `Uploaded new memory '${metadata.caption || 'Untitled'}'`,
                                    { category: metadata.category, imageUrl }
                                );
                            }

                        } catch (aiError) {
                            console.error("AI Analysis error:", aiError);
                            setUploadState(prev => ({ ...prev, status: 'error', resultMessage: 'AI Analysis failed.' }));
                        }
                    }
                );
            } else if (postToEdit) {
                // Only updating metadata
                await updateDoc(doc(db, 'posts', postToEdit.id), {
                    ...metadata,
                    updatedAt: serverTimestamp()
                });
                setUploadState(prev => ({ ...prev, status: 'success', progress: 100, resultMessage: 'Updated successfully!' }));
                toast.success("Memory updated!");
            }

        } catch (error) {
            console.error("Process error:", error);
            setUploadState(prev => ({ ...prev, status: 'error', resultMessage: error.message }));
        }
    };

    const handleEditPost = (post) => {
        setSelectedPost(post);
        setIsUploadModalOpen(true);
    };

    const filteredPosts = posts.filter(post => {
        const captionMatch = typeof post.caption === 'string' && post.caption.toLowerCase().includes(searchQuery.toLowerCase());
        const categoryMatch = typeof post.category === 'string' && post.category.toLowerCase().includes(searchQuery.toLowerCase());
        return captionMatch || categoryMatch;
    });

    return (
        <div className="min-h-screen pt-24 pb-20 bg-background-light dark:bg-background-dark">
            <SEO title="User Dashboard" />

            {/* Floating Upload Progress */}
            <UploadProgressCard
                uploadState={uploadState}
                onClose={() => setUploadState(prev => ({ ...prev, active: false }))}
            />

            <UploadModal
                isOpen={isUploadModalOpen}
                onClose={() => { setIsUploadModalOpen(false); setSelectedPost(null); }}
                postToEdit={selectedPost}
                onUploadStart={handleUploadStart}
            />

            <CreateAlbumModal
                isOpen={isAlbumModalOpen}
                onClose={() => setIsAlbumModalOpen(false)}
            />

            <ImageModal
                isOpen={isImageModalOpen}
                onClose={() => setIsImageModalOpen(false)}
                post={selectedPost}
                onUpdate={() => handleEditPost(selectedPost)}
            />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                {/* Header Section */}
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
                    <div>
                        <h1 className="text-3xl font-bold font-display text-surface-900 dark:text-white">
                            Welcome back, {user?.displayName?.split(' ')[0] || 'Contributor'}! 👋
                        </h1>
                        <p className="text-surface-600 dark:text-surface-400 mt-1">
                            Manage your memories and track your impact.
                        </p>
                    </div>
                    <div className="flex gap-3 w-full md:w-auto">
                        <Button
                            variant="secondary"
                            icon={<Plus size={18} />}
                            onClick={() => setIsAlbumModalOpen(true)}
                        >
                            Create Album
                        </Button>
                        <Button
                            icon={<Upload size={18} />}
                            onClick={() => { setSelectedPost(null); setIsUploadModalOpen(true); }}
                        >
                            Upload New Memory
                        </Button>
                    </div>
                </div>

                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                    <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl p-6 text-white shadow-lg">
                        <div className="flex justify-between items-start mb-4">
                            <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
                                <ImageIcon size={24} />
                            </div>
                            <span className="text-xs font-bold bg-white/20 px-2 py-1 rounded-full">+12%</span>
                        </div>
                        <h3 className="text-3xl font-bold mb-1">{posts.length}</h3>
                        <p className="text-indigo-100 text-sm">Total Uploads</p>
                    </div>

                    <div className="bg-white dark:bg-surface-800 rounded-2xl p-6 shadow-sm border border-surface-200 dark:border-surface-700">
                        <div className="flex justify-between items-start mb-4">
                            <div className="p-2 bg-pink-100 dark:bg-pink-900/30 text-pink-600 dark:text-pink-400 rounded-lg">
                                <Heart size={24} />
                            </div>
                        </div>
                        <h3 className="text-3xl font-bold mb-1 text-surface-900 dark:text-white">
                            {posts.reduce((acc, curr) => acc + (curr.likes || 0), 0)}
                        </h3>
                        <p className="text-surface-500 text-sm">Total Likes</p>
                    </div>

                    <div className="bg-white dark:bg-surface-800 rounded-2xl p-6 shadow-sm border border-surface-200 dark:border-surface-700">
                        <div className="flex justify-between items-start mb-4">
                            <div className="p-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg">
                                <MessageSquare size={24} />
                            </div>
                        </div>
                        <h3 className="text-3xl font-bold mb-1 text-surface-900 dark:text-white">0</h3>
                        <p className="text-surface-500 text-sm">Comments Received</p>
                    </div>

                    <div className="bg-white dark:bg-surface-800 rounded-2xl p-6 shadow-sm border border-surface-200 dark:border-surface-700">
                        <div className="flex justify-between items-start mb-4">
                            <div className="p-2 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-lg">
                                <Sparkles size={24} />
                            </div>
                        </div>
                        <h3 className="text-3xl font-bold mb-1 text-surface-900 dark:text-white">Top 5%</h3>
                        <p className="text-surface-500 text-sm">Campus Rank</p>
                    </div>
                </div>

                {/* Main Content Tabs */}
                <div className="flex items-center gap-6 border-b border-surface-200 dark:border-surface-700 mb-6 overflow-x-auto">
                    {['uploads', 'analytics', 'saved', 'activity'].map((tab) => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab)}
                            className={`pb-4 text-sm font-bold capitalize transition-colors relative whitespace-nowrap
                                ${activeTab === tab ? 'text-primary-600 dark:text-primary-400' : 'text-surface-500 hover:text-surface-900 dark:hover:text-white'}
                            `}
                        >
                            {tab}
                            {activeTab === tab && (
                                <motion.div
                                    layoutId="activeTab"
                                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary-600 dark:bg-primary-400 rounded-full"
                                />
                            )}
                        </button>
                    ))}
                </div>

                <AnimatePresence mode="wait">
                    {activeTab === 'uploads' && (
                        <motion.div
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            transition={{ duration: 0.2 }}
                        >
                            {/* Toolbar */}
                            <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-6">
                                <div className="relative w-full sm:w-64">
                                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-400" size={18} />
                                    <input
                                        type="text"
                                        placeholder="Search memories..."
                                        value={searchQuery}
                                        onChange={(e) => setSearchQuery(e.target.value)}
                                        className="w-full pl-10 pr-4 py-2 rounded-xl bg-white dark:bg-surface-800 border border-surface-200 dark:border-surface-700 focus:ring-2 focus:ring-primary-500 outline-none text-sm"
                                    />
                                </div>
                                <div className="flex items-center gap-2 self-end sm:self-auto">
                                    <div className="bg-white dark:bg-surface-800 p-1 rounded-lg border border-surface-200 dark:border-surface-700 flex">
                                        <button
                                            onClick={() => setViewMode('grid')}
                                            className={`p-1.5 rounded-md transition-colors ${viewMode === 'grid' ? 'bg-surface-100 dark:bg-surface-700 text-primary-600' : 'text-surface-400'}`}
                                        >
                                            <Grid size={18} />
                                        </button>
                                        <button
                                            onClick={() => setViewMode('list')}
                                            className={`p-1.5 rounded-md transition-colors ${viewMode === 'list' ? 'bg-surface-100 dark:bg-surface-700 text-primary-600' : 'text-surface-400'}`}
                                        >
                                            <ListIcon size={18} />
                                        </button>
                                    </div>
                                    <Button variant="ghost" size="sm" icon={<Filter size={18} />}>Filter</Button>
                                </div>
                            </div>

                            {/* Content Grid */}
                            {loading ? (
                                <div className="flex justify-center py-20">
                                    <Loader2 className="animate-spin text-primary-600" size={32} />
                                </div>
                            ) : filteredPosts.length > 0 ? (
                                <div className={`grid gap-6 ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'}`}>
                                    {filteredPosts.map((post) => (
                                        <motion.div
                                            layout
                                            key={post.id}
                                            initial={{ opacity: 0 }}
                                            animate={{ opacity: 1 }}
                                        >
                                            <div className="relative group rounded-xl overflow-hidden bg-white dark:bg-surface-800 border border-surface-200 dark:border-surface-700 shadow-sm hover:shadow-md transition-all">
                                                <div
                                                    className={`relative cursor-pointer ${viewMode === 'grid' ? 'aspect-[4/3]' : 'aspect-video md:aspect-[21/9]'}`}
                                                    onClick={() => { setSelectedPost(post); setIsImageModalOpen(true); }}
                                                >
                                                    <img
                                                        src={post.imageUrl}
                                                        alt={post.caption}
                                                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                                                    />
                                                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />

                                                    {/* Status Badge */}
                                                    {post.status === 'pending_review' && (
                                                        <div className="absolute top-3 left-3 bg-yellow-500 text-white text-xs font-bold px-2 py-1 rounded-full shadow-lg">
                                                            Under Review
                                                        </div>
                                                    )}
                                                </div>

                                                <div className="p-4">
                                                    <div className="flex justify-between items-start mb-2">
                                                        <div>
                                                            <h3 className="font-bold text-surface-900 dark:text-white line-clamp-1">{String(post.caption || 'Untitled Memory')}</h3>
                                                            <p className="text-xs text-surface-500">{String(post.category || '')} • {String(post.year || '')}</p>
                                                        </div>
                                                        <button className="text-surface-400 hover:text-surface-900 dark:hover:text-white transition-colors">
                                                            <MoreVertical size={18} />
                                                        </button>
                                                    </div>

                                                    <div className="flex items-center justify-between mt-4 pt-4 border-t border-surface-100 dark:border-surface-700">
                                                        <div className="flex items-center gap-3 text-sm text-surface-500">
                                                            <span className="flex items-center gap-1"><Heart size={14} /> {post.likes || 0}</span>
                                                            <span className="flex items-center gap-1"><MessageSquare size={14} /> 0</span>
                                                        </div>
                                                        <div className="flex gap-2">
                                                            <button
                                                                onClick={() => handleEditPost(post)}
                                                                className="text-xs font-semibold text-primary-600 hover:text-primary-700 dark:text-primary-400 dark:hover:text-primary-300 transition-colors"
                                                            >
                                                                Edit
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-center py-20 bg-surface-50 dark:bg-surface-800/50 rounded-2xl border-2 border-dashed border-surface-200 dark:border-surface-700">
                                    <div className="w-16 h-16 bg-surface-100 dark:bg-surface-700 rounded-full flex items-center justify-center mx-auto mb-4 text-surface-400">
                                        <ImageIcon size={32} />
                                    </div>
                                    <h3 className="text-lg font-bold text-surface-900 dark:text-white mb-1">No uploads found</h3>
                                    <p className="text-surface-500 mb-6">Start building your gallery by uploading your first memory.</p>
                                    <Button onClick={() => setIsUploadModalOpen(true)}>Upload Now</Button>
                                </div>
                            )}
                        </motion.div>
                    )}

                    {activeTab === 'saved' && (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                        >
                            <SavedEventsList savedEventIds={userData?.savedEvents || []} />
                        </motion.div>
                    )}

                    {activeTab === 'activity' && (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="max-w-3xl mx-auto"
                        >
                            <ActivityList userId={user?.uid} />
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
};

export default Dashboard;
