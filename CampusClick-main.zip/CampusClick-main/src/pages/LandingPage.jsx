
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Camera, ArrowRight, Shield, Users, Zap, Globe, Heart, Award, ArrowUpRight } from 'lucide-react';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';

const LandingPage = () => {


    return (
        <div className="min-h-screen bg-background-light dark:bg-background-dark text-surface-900 dark:text-white overflow-hidden relative">

            {/* Background Ambience */}
            <div className="fixed inset-0 pointer-events-none overflow-hidden">
                <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-primary-500/10 dark:bg-primary-500/20 rounded-full blur-[120px] animate-pulse-slow" />
                <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-secondary-500/10 dark:bg-secondary-500/20 rounded-full blur-[120px] animate-pulse-slow delay-1000" />
            </div>

            {/* Hero Section */}
            <section className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto flex flex-col items-center text-center z-10">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8 }}
                    className="mb-8 inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-primary-200 dark:border-primary-500/30"
                >
                    <span className="relative flex h-2.5 w-2.5">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-success"></span>
                    </span>
                    <span className="text-xs font-bold tracking-wider uppercase text-primary-700 dark:text-primary-300">Live Campus Archive v2.0</span>
                </motion.div>

                <motion.h1
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.2 }}
                    className="text-5xl md:text-7xl lg:text-8xl font-black font-display tracking-tight mb-8 leading-[1.1]"
                >
                    CampusClick: The AI-Powered <br />
                    <span className="text-gradient animate-gradient">
                        Digital Legacy of College.
                    </span>
                </motion.h1>

                <motion.p
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.4 }}
                    className="text-lg md:text-xl text-surface-600 dark:text-surface-300 max-w-2xl mb-10 leading-relaxed font-medium"
                >
                    Don't let your college memories get buried in your phone gallery. Archive, tag, and relive every moment with AI-driven categorization.
                </motion.p>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.6 }}
                    className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto"
                >
                    <Link to="/auth/register">
                        <Button size="lg" className="w-full sm:w-auto shadow-xl shadow-primary-500/20">
                            Get Started <ArrowRight className="ml-2 w-5 h-5" />
                        </Button>
                    </Link>
                    <Link to="/gallery">
                        <Button variant="glass" size="lg" className="w-full sm:w-auto">
                            Explore Archive
                        </Button>
                    </Link>
                </motion.div>

                {/* Decorative Elements */}
                <div className="absolute top-1/2 -translate-y-1/2 left-0 hidden xl:block pointer-events-none opacity-20 dark:opacity-40">
                    <img src="https://cdn-icons-png.flaticon.com/512/2907/2907253.png" className="w-24 h-24 animate-bounce" style={{ animationDuration: '3s' }} alt="" />
                </div>
                <div className="absolute top-1/3 right-10 hidden xl:block pointer-events-none opacity-20 dark:opacity-40">
                    <img src="https://cdn-icons-png.flaticon.com/512/1042/1042304.png" className="w-20 h-20 animate-pulse" style={{ animationDuration: '4s' }} alt="" />
                </div>
            </section>

            {/* Features Grid */}
            <section className="section-padding container-custom relative z-10">
                <div className="text-center mb-16">
                    <h2 className="text-3xl md:text-5xl font-bold font-display mb-6">Why CampusClick?</h2>
                    <p className="text-surface-600 dark:text-surface-400 max-w-2xl mx-auto text-lg">
                        Built with modern technology to ensure your memories last forever.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <FeatureCard
                        icon={<Zap className="text-warning" />}
                        title="Smart Tagging"
                        desc="AI automatically identifies events, faces, and departments from your photos."
                    />
                    <FeatureCard
                        icon={<Shield className="text-success" />}
                        title="Privacy First"
                        desc="End-to-end encrypted storage. You control who sees your memories."
                    />
                    <FeatureCard
                        icon={<Users className="text-info" />}
                        title="Collaborative Albums"
                        desc="Create shared folders for your batch, club, or event."
                    />
                </div>
            </section>

            {/* Stats Section */}
            <section className="py-20 border-y border-surface-200 dark:border-surface-800 bg-surface-50/50 dark:bg-black/20 backdrop-blur-sm">
                <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-3 gap-12 text-center">
                    <StatItem value="1000+" label="Memories Archived" />
                    <StatItem value="50+" label="Campus Events" />
                    <StatItem value="100%" label="Secure Storage" />
                </div>
            </section>
        </div>
    );
};

const FeatureCard = ({ icon, title, desc }) => (
    <Card
        variant="glass"
        hoverEffect={true}
        className="p-8 group hover:border-primary-500/30 transition-colors"
    >
        <div className="w-14 h-14 rounded-2xl bg-surface-100 dark:bg-surface-800 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-inner">
            {React.cloneElement(icon, { size: 28 })}
        </div>
        <h3 className="text-xl font-bold mb-3 font-display text-surface-900 dark:text-white group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">{title}</h3>
        <p className="text-surface-600 dark:text-surface-400 leading-relaxed">{desc}</p>
    </Card>
);

const StatItem = ({ value, label }) => (
    <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
    >
        <h4 className="text-5xl md:text-6xl font-black font-display text-transparent bg-clip-text bg-gradient-to-b from-primary-500 to-secondary-600 mb-2">{value}</h4>
        <p className="text-surface-500 dark:text-surface-400 font-bold uppercase tracking-widest text-sm">{label}</p>
    </motion.div>
);

export default LandingPage;
