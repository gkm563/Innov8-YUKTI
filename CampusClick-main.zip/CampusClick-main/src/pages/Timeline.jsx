import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { getEvents } from '../services/eventService';
import { Calendar, MapPin, ArrowRight, Clock, Star } from 'lucide-react';
import Button from '../components/ui/Button';
import SEO from '../components/SEO';

const Timeline = () => {
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchEvents = async () => {
            try {
                const data = await getEvents();
                // Sort events by date (descending for "latest first" or ascending for "chronological")
                const sorted = data.sort((a, b) => {
                    const dateA = a.startDate?.toDate ? a.startDate.toDate() : new Date(a.startDate);
                    const dateB = b.startDate?.toDate ? b.startDate.toDate() : new Date(b.startDate);
                    return dateB - dateA; // Descending
                });
                setEvents(sorted);
            } catch (error) {
                console.error("Failed to load events", error);
            } finally {
                setLoading(false);
            }
        };
        fetchEvents();
    }, []);

    if (loading) {
        return (
            <div className="min-h-screen pt-24 pb-20 flex items-center justify-center bg-background-light dark:bg-background-dark">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
            </div>
        );
    }

    return (
        <div className="min-h-screen pt-24 pb-20 bg-background-light dark:bg-background-dark">
            <SEO title="Campus Timeline" description="Explore the chronological journey of our campus events, fests, and memories." />
            <div className="max-w-4xl mx-auto px-4 sm:px-6">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center mb-16"
                >
                    <h1 className="text-4xl md:text-5xl font-bold mb-4 font-display text-surface-900 dark:text-white">
                        Campus <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-500 to-secondary-500">Timeline</span>
                    </h1>
                    <p className="text-lg text-surface-600 dark:text-surface-300">
                        A journey through our most memorable moments.
                    </p>
                </motion.div>

                <div className="relative">
                    {/* Vertical Line */}
                    <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary-500 via-secondary-500 to-transparent md:-translate-x-1/2 opacity-30"></div>

                    <div className="space-y-12">
                        {events.map((event, index) => {
                            const isLeft = index % 2 === 0;
                            const date = event.startDate?.toDate ? event.startDate.toDate() : new Date(event.startDate || Date.now());
                            const month = date.toLocaleDateString('default', { month: 'short' });
                            const day = date.getDate();
                            const year = date.getFullYear();

                            return (
                                <motion.div
                                    key={event.id}
                                    initial={{ opacity: 0, y: 50 }}
                                    whileInView={{ opacity: 1, y: 0 }}
                                    viewport={{ once: true, margin: "-100px" }}
                                    transition={{ duration: 0.5, delay: index * 0.1 }}
                                    className={`relative flex items-center ${isLeft ? 'md:flex-row' : 'md:flex-row-reverse'} flex-row gap-8`}
                                >
                                    {/* Mobile Date Marker (Left side always) */}
                                    <div className="md:hidden absolute left-0 top-0 w-8 h-8 rounded-full bg-primary-500 border-4 border-background-light dark:border-background-dark z-10 flex items-center justify-center text-xs font-bold text-white shadow-lg">
                                        {/* Simple dot or small date */}
                                    </div>

                                    {/* Timeline Node (Desktop) */}
                                    <div className="hidden md:flex absolute left-1/2 top-1/2 -translate-y-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-primary-500 border-[3px] border-white dark:border-gray-900 z-10 shadow-[0_0_0_4px_rgba(99,102,241,0.2)]"></div>

                                    {/* Content Card */}
                                    <div className={`w-full md:w-[calc(50%-2rem)] ml-12 md:ml-0 ${isLeft ? 'md:text-right' : 'md:text-left'}`}>
                                        <Link to={`/events/${event.id}`} className="group block">
                                            <div className="relative overflow-hidden rounded-2xl bg-white dark:bg-surface-800 shadow-xl border border-surface-200 dark:border-surface-700/50 hover:shadow-2xl hover:border-primary-500/30 transition-all duration-300 group-hover:-translate-y-1">

                                                {/* Image Banner */}
                                                <div className="h-40 overflow-hidden relative">
                                                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent z-10" />
                                                    <img
                                                        src={event.bannerUrl || "https://images.unsplash.com/photo-1540575467063-178a50937177?auto=format&fit=crop&q=80"}
                                                        alt={event.title}
                                                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                                                    />
                                                    <div className={`absolute bottom-3 ${isLeft ? 'md:right-3 right-auto left-3 md:left-auto' : 'left-3'} z-20`}>
                                                        <span className="bg-primary-600/90 text-white text-xs font-bold px-3 py-1 rounded-full backdrop-blur-md">
                                                            {year}
                                                        </span>
                                                    </div>
                                                </div>

                                                <div className="p-6">
                                                    <div className={`flex flex-col ${isLeft ? 'md:items-end' : 'md:items-start'} gap-1 mb-3`}>
                                                        <span className="text-sm font-bold tracking-wider text-primary-600 dark:text-primary-400 uppercase">
                                                            {month} {day}
                                                        </span>
                                                        <h3 className="text-xl font-bold text-surface-900 dark:text-white leading-tight group-hover:text-primary-500 transition-colors">
                                                            {event.title}
                                                        </h3>
                                                    </div>

                                                    <p className="text-surface-600 dark:text-surface-400 text-sm line-clamp-2 mb-4">
                                                        {event.description}
                                                    </p>

                                                    <div className={`flex items-center ${isLeft ? 'md:justify-end' : 'md:justify-start'} gap-4 text-xs font-medium text-surface-500 dark:text-surface-500`}>
                                                        <div className="flex items-center gap-1">
                                                            <MapPin size={14} /> {event.venue || 'Campus'}
                                                        </div>
                                                        {/* <div className="flex items-center gap-1">
                                                            <Star size={14} className="text-yellow-500" /> {event.status}
                                                         </div> */}
                                                    </div>
                                                </div>
                                            </div>
                                        </Link>
                                    </div>

                                    {/* Empty Space for the other side */}
                                    <div className="hidden md:block w-[calc(50%-2rem)]"></div>
                                </motion.div>
                            );
                        })}

                        {/* End Node */}
                        <div className="relative flex justify-center pt-8">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center text-white text-xs font-bold shadow-lg z-10 animate-pulse">
                                ★
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Timeline;
