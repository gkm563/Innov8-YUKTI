import React from 'react';
import { motion } from 'framer-motion';
import { Link, Routes, Route, useLocation } from 'react-router-dom';
import { Shield, Lock, Heart, Map, HelpCircle, FileText, ArrowLeft, CheckCircle, Smartphone, AlertCircle, Linkedin, Github, Twitter, Instagram, Globe } from 'lucide-react';

// --- Animation Variants ---
const containerVariants = {
    hidden: { opacity: 0 },
    show: {
        opacity: 1,
        transition: {
            staggerChildren: 0.1
        }
    }
};

const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
};

// --- Shared Layout Component ---
const InfoPageLayout = ({ title, icon, children }) => {
    return (
        <div className="min-h-screen pt-24 pb-12 px-4 sm:px-6 lg:px-8 bg-gray-50 dark:bg-charcoal text-gray-900 dark:text-white relative overflow-hidden transition-colors duration-300">
            {/* Background Glow */}
            <div className="fixed top-20 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-brand-blue/10 rounded-full blur-[120px] pointer-events-none" />

            <div className="max-w-4xl mx-auto relative z-10">
                <Link to="/" className="inline-flex items-center gap-2 text-gray-400 hover:text-gray-900 dark:hover:text-white mb-8 transition-colors group">
                    <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" /> Back to Home
                </Link>

                <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5 }}
                    className="glass-card p-8 md:p-12 border border-gray-200 dark:border-white/10 shadow-xl"
                >
                    <div className="flex items-center gap-4 mb-8 pb-8 border-b border-gray-200 dark:border-white/5">
                        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-brand-blue to-neon-purple flex items-center justify-center text-white shadow-lg shadow-brand-blue/20">
                            {icon}
                        </div>
                        <h1 className="text-4xl font-bold text-gray-900 dark:text-white">{title}</h1>
                    </div>

                    <motion.div
                        variants={containerVariants}
                        initial="hidden"
                        animate="show"
                        className="prose prose-lg max-w-none text-gray-600 dark:text-gray-300"
                    >
                        {children}
                    </motion.div>
                </motion.div>
            </div>
        </div>
    );
};

// --- Page Components ---

const AboutUs = () => (
    <InfoPageLayout title="About Us" icon={<Heart size={32} />}>
        <h2 className="text-2xl font-bold mb-4">Beyond Just Photos – We Build Legacies.</h2>
        <motion.p variants={itemVariants} className="text-lg leading-relaxed mb-6">
            CampusClick was born out of a simple problem: thousands of photos are taken during college fests, lectures, and hangouts, but they are lost forever when a student changes their phone or graduates.
        </motion.p>
        <motion.p variants={itemVariants} className="text-lg leading-relaxed mb-6">
            As a Data Science student, I realized we could use AI to not just store, but organize these memories. Our mission is to create a 'Living Archive' for United Institute of Technology (UIT) where every click tells a story.
        </motion.p>
    </InfoPageLayout>
);

const Security = () => (
    <InfoPageLayout title="Security & AI" icon={<Shield size={32} />}>
        <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="p-6 rounded-xl bg-white/5 border border-white/10">
                <Shield className="text-green-400 mb-4" size={32} />
                <h3 className="text-xl font-bold mb-2">AI Moderation</h3>
                <p>Your images are analyzed by Google Gemini AI. Offensive or inappropriate content is automatically rejected to ensure a safe community.</p>
            </div>
            <div className="p-6 rounded-xl bg-white/5 border border-white/10">
                <Lock className="text-brand-blue mb-4" size={32} />
                <h3 className="text-xl font-bold mb-2">Data Privacy</h3>
                <p>We use your data solely for verification purposes. We do not sell your personal data to any third-party advertisers.</p>
            </div>
        </div>
        <h3>How it Works</h3>
        <ul className="list-disc pl-5 space-y-2 mt-4">
            <li>Upload: Image is sent to server.</li>
            <li>Scan: Gemini 1.5 Flash scans for safety violations.</li>
            <li>Tags: AI generates smart tags (Project, Fest, Sports).</li>
            <li>Archive: Safe images are stored in Firestore.</li>
        </ul>
    </InfoPageLayout>
);

const Privacy = () => (
    <InfoPageLayout title="Your Data, Your Control." icon={<Lock size={32} />}>
        <p className="mb-4">Effective Date: {new Date().toLocaleDateString()}</p>

        <h3>1. Data Collection</h3>
        <p>
            We only collect your Email (for login) and the Photos you voluntarily upload.
        </p>

        <h3>2. AI Processing</h3>
        <p>
            Images are processed using AI to generate tags. We do not sell your biometric data to third parties.
        </p>

        <h3>3. Ownership</h3>
        <p>
            You retain 100% ownership of your photos. You can delete them anytime.
        </p>

        <h3>4. Security</h3>
        <p>
            We use Firebase Security Rules to ensure that your private albums remain private.
        </p>
    </InfoPageLayout>
);

const CookiesPolicy = () => (
    <InfoPageLayout title="Cookies Policy" icon={<FileText size={32} />}>
        <p>
            CampusClick uses essential cookies to keep you logged in and to remember your preferences. We do not use intrusive tracking cookies or third-party advertising cookies. By using our site, you agree to our use of these functional cookies.
        </p>
    </InfoPageLayout>
);


const Terms = () => (
    <InfoPageLayout title="Terms & Conditions" icon={<FileText size={32} />}>
        <h3>1. Usage</h3>
        <p>Users must not upload any explicit, copyrighted, or offensive content.</p>

        <h3>2. Accountability</h3>
        <p>Any misuse of the platform for bullying or harassment will lead to an immediate ban.</p>

        <h3>3. Service</h3>
        <p>This is a student-led project. While we strive for 100% uptime, we are not liable for any data loss. Always keep backups.</p>
    </InfoPageLayout>
);

const Subscription = () => (
    <InfoPageLayout title="Subscription" icon={<CheckCircle size={32} />}>
        <div className="bg-gradient-to-r from-brand-blue/20 to-neon-purple/20 p-8 rounded-2xl border border-brand-blue/30 text-center">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Current Status: Free</h2>
            <p className="text-gray-600 dark:text-gray-300">Currently, this platform is completely free for all college students.</p>
        </div>
    </InfoPageLayout>
);

const Support = () => (
    <InfoPageLayout title="Contact Us" icon={<HelpCircle size={32} />}>
        <div className="max-w-xl mx-auto">
            <h2 className="text-2xl font-bold mb-6 text-center">Found a Bug? Or Have a Suggestion?</h2>

            <form className="space-y-4 mb-12">
                <div>
                    <label className="block text-sm font-medium mb-1">Name</label>
                    <input type="text" className="w-full p-3 rounded-lg bg-white/5 border border-gray-200 dark:border-white/10" placeholder="Your Name" />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Email</label>
                    <input type="email" className="w-full p-3 rounded-lg bg-white/5 border border-gray-200 dark:border-white/10" placeholder="your@email.com" />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Subject</label>
                    <input type="text" className="w-full p-3 rounded-lg bg-white/5 border border-gray-200 dark:border-white/10" placeholder="Feedback / Bug Report" />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Message</label>
                    <textarea rows="4" className="w-full p-3 rounded-lg bg-white/5 border border-gray-200 dark:border-white/10" placeholder="Tell us more..."></textarea>
                </div>
                <button type="button" className="w-full py-3 bg-brand-blue hover:bg-brand-blue/90 text-white rounded-lg font-bold transition-colors">
                    Send Message
                </button>
            </form>

            <div className="text-center pt-8 border-t border-gray-200 dark:border-white/10">
                <p className="font-bold mb-4">Connect with me:</p>
                <div className="flex justify-center gap-6 mb-8">
                    <a href="https://linkedin.com/in/gkm563" target="_blank" rel="noopener noreferrer" className="hover:text-brand-blue transition-colors flex items-center gap-1"><Linkedin size={18} /> LinkedIn</a>
                    <a href="https://github.com/gkm563" target="_blank" rel="noopener noreferrer" className="hover:text-brand-blue transition-colors flex items-center gap-1"><Github size={18} /> GitHub</a>
                    <a href="https://instagram.com/gkm3563" target="_blank" rel="noopener noreferrer" className="hover:text-brand-blue transition-colors flex items-center gap-1"><Instagram size={18} /> Instagram</a>
                    <a href="https://twitter.com/gkm563" target="_blank" rel="noopener noreferrer" className="hover:text-brand-blue transition-colors flex items-center gap-1"><Twitter size={18} /> Twitter</a>
                    <a href="https://gkm563.github.io/gkmportfolio/" target="_blank" rel="noopener noreferrer" className="hover:text-brand-blue transition-colors flex items-center gap-1"><Globe size={18} /> Portfolio</a>
                </div>
                <p className="text-sm text-gray-500">Built with ❤️ by Gautam Kumar Maurya | B.Tech CSE (DS) 2nd Year.</p>
            </div>
        </div>
    </InfoPageLayout>
);

const TeamCard = ({ name, role, subRole, image }) => (
    <motion.div
        variants={itemVariants}
        whileHover={{ y: -10, rotate: 1 }}
        className="flex flex-col items-center p-6 bg-white/5 rounded-2xl border border-gray-200 dark:border-white/10 hover:border-brand-blue/30 transition-all shadow-lg hover:shadow-brand-blue/10"
    >
        <img
            src={image}
            alt={name}
            className="w-24 h-24 rounded-full mb-4 border-2 border-brand-blue/20 shadow-lg object-cover"
        />
        <h3 className="text-lg font-bold text-gray-900 dark:text-white text-center">{name}</h3>
        <p className="text-brand-blue text-sm font-medium mt-1">{role}</p>
        {subRole && <p className="text-gray-500 dark:text-gray-400 text-xs mt-1">{subRole}</p>}
    </motion.div>
);

const SiteMap = () => {
    const sections = [
        {
            title: "Main",
            links: [
                { name: "Home", path: "/" },
                { name: "Gallery", path: "/gallery" },
                { name: "Events", path: "/events" },
                { name: "Tech Hub", path: "/tech-hub" }
            ]
        },
        {
            title: "Account",
            links: [
                { name: "Login", path: "/auth/login" },
                { name: "Sign Up", path: "/auth/register" },
                { name: "Profile", path: "/profile" },
                { name: "Dashboard", path: "/dashboard" }
            ]
        },
        {
            title: "Company",
            links: [
                { name: "About Us", path: "/about" },
                { name: "Features", path: "/features" }, // Assuming this route exists or will exist, keeping as is
                { name: "Team Innov8", path: "/support" }
            ]
        },
        {
            title: "Legal & Support",
            links: [
                { name: "Privacy Policy", path: "/privacy" },
                { name: "Terms of Use", path: "/terms" },
                { name: "Security", path: "/security" },
                { name: "Help & Support", path: "/support" }
            ]
        }
    ];

    return (
        <InfoPageLayout title="Site Map" icon={<Map size={32} />}>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {sections.map((section, index) => (
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="bg-white/50 dark:bg-charcoal-light border border-gray-200 dark:border-white/5 rounded-2xl p-6 hover:shadow-xl hover:border-brand-blue/30 transition-all group"
                    >
                        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2 group-hover:text-brand-blue transition-colors">
                            <span className="w-2 h-8 bg-brand-blue rounded-full"></span>
                            {section.title}
                        </h3>
                        <ul className="space-y-3">
                            {section.links.map((link, idx) => (
                                <li key={idx}>
                                    <Link
                                        to={link.path}
                                        className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-brand-blue dark:hover:text-brand-blue transition-colors font-medium transform hover:translate-x-1 duration-200"
                                    >
                                        <div className="w-1.5 h-1.5 rounded-full bg-gray-300 dark:bg-gray-600 group-hover:bg-brand-blue transition-colors" />
                                        {link.name}
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    </motion.div>
                ))}
            </div>

            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="mt-12 p-8 rounded-3xl bg-gradient-to-r from-brand-blue to-neon-purple text-white text-center shadow-2xl relative overflow-hidden"
            >
                <div className="absolute inset-0 bg-black/10 backdrop-blur-[1px]" />
                <div className="relative z-10">
                    <h3 className="text-2xl font-bold mb-2">Can't find what you're looking for?</h3>
                    <p className="mb-6 text-white/90">Our search engine is powerful and ready to help.</p>
                    <Link to="/" className="inline-block px-8 py-3 bg-white text-brand-blue rounded-full font-bold hover:bg-gray-100 transition-colors shadow-lg">
                        Go to Search
                    </Link>
                </div>
            </motion.div>
        </InfoPageLayout>
    );
};

export { AboutUs, Security, Privacy, Terms, CookiesPolicy, Subscription, Support, SiteMap };
