import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { toast } from 'react-toastify';
import { Mail, Lock, ArrowRight, Loader } from 'lucide-react';
import { motion } from 'framer-motion';
import { updateProfile } from 'firebase/auth';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState(''); // New state
    const [name, setName] = useState('');
    const [loading, setLoading] = useState(false);
    const { login, signup } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();

    // Determine mode based on URL
    const isRegister = location.pathname === '/auth/register';
    const from = location.state?.from?.pathname || '/dashboard';

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        if (isRegister && password !== confirmPassword) {
            toast.error("Passwords do not match!");
            return;
        }

        try {
            if (isRegister) {
                const userCredential = await signup(email, password);
                if (name && userCredential.user) {
                    await updateProfile(userCredential.user, {
                        displayName: name
                    });
                }
                toast.success("Account created! Welcome to CampusClick.");
            } else {
                await login(email, password);
                toast.success("Welcome back!");
            }
            navigate(from, { replace: true });
        } catch (error) {
            console.error(error);
            toast.error(error.message.replace("Firebase: ", ""));
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex bg-background-light dark:bg-background-dark text-surface-900 dark:text-surface-50 transition-colors duration-300">

            {/* Left Side - Visuals (Hidden on mobile) */}
            <div className="hidden lg:flex w-1/2 bg-surface-900 relative overflow-hidden items-center justify-center p-12 text-white">
                <div className="absolute inset-0 bg-hero-glowing opacity-30 animate-pulse-slow" />
                <div className="absolute inset-0 bg-black/20 backdrop-blur-[1px]" />

                <div className="relative z-10 max-w-lg">
                    <h1 className="text-6xl font-black tracking-tighter mb-6 font-display">
                        {isRegister ? "Join the\nCommunity." : "Welcome\nBack."}
                    </h1>
                    <p className="text-xl text-surface-300 leading-relaxed mb-8">
                        {isRegister
                            ? "Start your journey, share memories, and connect with your campus today."
                            : "Sign in to access your dashboard, manage your uploads, and connect with the campus community."
                        }
                    </p>
                    <div className="flex gap-4">
                        <div className="w-16 h-1 bg-primary-500 rounded-full" />
                        <div className="w-8 h-1 bg-surface-600 rounded-full" />
                    </div>
                </div>
            </div>

            {/* Right Side - Form */}
            <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 lg:p-24 bg-surface-50 dark:bg-surface-950">
                <div className="w-full max-w-md space-y-8">
                    <div className="text-center lg:text-left">
                        <h2 className="text-3xl font-bold tracking-tight font-display text-surface-900 dark:text-white">{isRegister ? "Create Account" : "Sign In to CampusClick"}</h2>
                        <p className="mt-2 text-sm text-surface-600 dark:text-surface-400">
                            {isRegister ? "Already have an account? " : "Don't have an account? "}
                            <Link to={isRegister ? "/auth/login" : "/auth/register"} className="font-medium text-primary-600 hover:text-primary-700 dark:text-primary-400 dark:hover:text-primary-300 transition-colors">
                                {isRegister ? "Sign In" : "Join now"}
                            </Link>
                        </p>
                    </div>

                    <motion.form
                        key={isRegister ? 'register' : 'login'}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        onSubmit={handleSubmit}
                        className="mt-8 space-y-6"
                    >
                        <div className="space-y-4">
                            {isRegister && (
                                <div>
                                    <label htmlFor="name" className="sr-only">Full Name</label>
                                    <div className="relative group">
                                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                            <Mail className="h-5 w-5 text-surface-400 group-focus-within:text-primary-500 transition-colors" />
                                        </div>
                                        <input
                                            id="name"
                                            name="name"
                                            type="text"
                                            required
                                            value={name}
                                            onChange={(e) => setName(e.target.value)}
                                            className="block w-full pl-11 pr-4 py-4 bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-700 rounded-xl text-surface-900 dark:text-white placeholder-surface-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all shadow-sm"
                                            placeholder="Full Name"
                                        />
                                    </div>
                                </div>
                            )}

                            <div>
                                <label htmlFor="email" className="sr-only">Email address</label>
                                <div className="relative group">
                                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                        <Mail className="h-5 w-5 text-surface-400 group-focus-within:text-primary-500 transition-colors" />
                                    </div>
                                    <input
                                        id="email"
                                        name="email"
                                        type="email"
                                        autoComplete="email"
                                        required
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        className="block w-full pl-11 pr-4 py-4 bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-700 rounded-xl text-surface-900 dark:text-white placeholder-surface-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all shadow-sm"
                                        placeholder="Enter your email"
                                    />
                                </div>
                            </div>

                            <div>
                                <label htmlFor="password" className="sr-only">Password</label>
                                <div className="relative group">
                                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                        <Lock className="h-5 w-5 text-surface-400 group-focus-within:text-primary-500 transition-colors" />
                                    </div>
                                    <input
                                        id="password"
                                        name="password"
                                        type="password"
                                        autoComplete="current-password"
                                        required
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        className="block w-full pl-11 pr-4 py-4 bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-700 rounded-xl text-surface-900 dark:text-white placeholder-surface-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all shadow-sm"
                                        placeholder="Enter your password"
                                    />
                                </div>
                            </div>

                            {isRegister && (
                                <div>
                                    <label htmlFor="confirmPassword" class="sr-only">Confirm Password</label>
                                    <div className="relative group">
                                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                            <Lock className="h-5 w-5 text-surface-400 group-focus-within:text-primary-500 transition-colors" />
                                        </div>
                                        <input
                                            id="confirmPassword"
                                            name="confirmPassword"
                                            type="password"
                                            autoComplete="new-password"
                                            required
                                            value={confirmPassword}
                                            onChange={(e) => setConfirmPassword(e.target.value)}
                                            className="block w-full pl-11 pr-4 py-4 bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-700 rounded-xl text-surface-900 dark:text-white placeholder-surface-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all shadow-sm"
                                            placeholder="Confirm Password"
                                        />
                                    </div>
                                </div>
                            )}
                        </div>

                        {!isRegister && (
                            <div className="flex items-center justify-end">
                                <Link to="/auth/forgot-password" className="text-sm font-medium text-primary-600 hover:text-primary-700 dark:text-primary-400 dark:hover:text-primary-300 transition-colors">
                                    Forgot your password?
                                </Link>
                            </div>
                        )}

                        <button
                            type="submit"
                            disabled={loading}
                            className="w-full flex justify-center items-center py-4 px-4 border border-transparent rounded-xl shadow-lg shadow-primary-500/20 text-sm font-bold text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-[0.98]"
                        >
                            {loading ? (
                                <Loader className="animate-spin h-5 w-5" />
                            ) : (
                                <>{isRegister ? "Create Account" : "Sign In"} <ArrowRight className="ml-2 h-5 w-5" /></>
                            )}
                        </button>
                    </motion.form>
                </div>
            </div>
        </div>
    );
};

export default Login;
