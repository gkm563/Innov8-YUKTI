import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Check, User, Users, Mail, Lock, BookOpen, Star, LayoutDashboard, LifeBuoy } from 'lucide-react';

const ContributorRegister = () => {
    const [step, setStep] = useState(1);
    const { loginWithGoogle } = useAuth();
    const navigate = useNavigate();

    const handleNext = () => setStep(2);
    const handleBack = () => setStep(1);

    const handleGoogleLogin = async () => {
        // In a real flow, checking if user exists/saving additional data could happen here
        await loginWithGoogle();
        navigate('/dashboard');
    };

    return (
        <div className="min-h-screen pt-20 pb-12 flex items-center justify-center bg-background-light dark:bg-background-dark px-4">
            <div className="max-w-xl w-full">
                {/* Progress Bar */}
                <div className="mb-8 flex items-center justify-center gap-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${step >= 1 ? 'bg-primary-600 text-white' : 'bg-surface-200 dark:bg-surface-800 text-surface-500'}`}>1</div>
                    <div className={`h-1 w-20 rounded-full ${step >= 2 ? 'bg-primary-600' : 'bg-surface-200 dark:bg-surface-800'}`}></div>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${step >= 2 ? 'bg-primary-600 text-white' : 'bg-surface-200 dark:bg-surface-800 text-surface-500'}`}>2</div>
                </div>

                <motion.div
                    layout
                    className="bg-white dark:bg-surface-900 rounded-2xl shadow-xl dark:shadow-none border border-surface-200 dark:border-surface-800 overflow-hidden p-8"
                >
                    <AnimatePresence mode="wait">
                        {step === 1 && (
                            <motion.div
                                key="step1"
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: 20 }}
                                transition={{ duration: 0.3 }}
                            >
                                <h2 className="text-3xl font-bold font-display text-surface-900 dark:text-white mb-2">Create Account</h2>
                                <p className="text-surface-500 dark:text-surface-400 mb-8">Step 1: Basic Information</p>

                                <div className="space-y-4">
                                    <div>
                                        <label className="block text-sm font-medium text-surface-700 dark:text-surface-300 mb-1">Full Name</label>
                                        <div className="relative">
                                            <User className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-400 w-5 h-5" />
                                            <input type="text" className="w-full pl-10 pr-4 py-3 rounded-xl bg-surface-50 dark:bg-surface-800 border border-surface-200 dark:border-surface-700 focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none text-surface-900 dark:text-white placeholder-surface-400" placeholder="John Doe" />
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-surface-700 dark:text-surface-300 mb-1">College Email</label>
                                        <div className="relative">
                                            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-400 w-5 h-5" />
                                            <input type="email" className="w-full pl-10 pr-4 py-3 rounded-xl bg-surface-50 dark:bg-surface-800 border border-surface-200 dark:border-surface-700 focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none text-surface-900 dark:text-white placeholder-surface-400" placeholder="student@university.edu" />
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-surface-700 dark:text-surface-300 mb-1">Password</label>
                                        <div className="relative">
                                            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-400 w-5 h-5" />
                                            <input type="password" className="w-full pl-10 pr-4 py-3 rounded-xl bg-surface-50 dark:bg-surface-800 border border-surface-200 dark:border-surface-700 focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none text-surface-900 dark:text-white placeholder-surface-400" placeholder="••••••••" />
                                        </div>
                                    </div>
                                </div>

                                <div className="mt-8">
                                    <button onClick={handleNext} className="w-full py-3 bg-primary-600 text-white rounded-xl font-bold hover:bg-primary-700 transition-colors shadow-lg shadow-primary-500/20">
                                        Continue
                                    </button>
                                </div>

                                <div className="mt-6 text-center">
                                    <div className="relative">
                                        <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-surface-200 dark:border-surface-800"></div></div>
                                        <div className="relative flex justify-center text-sm"><span className="px-2 bg-white dark:bg-surface-900 text-surface-500">Or continue with</span></div>
                                    </div>
                                    <button onClick={handleGoogleLogin} className="mt-4 w-full py-3 border border-surface-300 dark:border-surface-700 rounded-xl flex items-center justify-center gap-2 hover:bg-surface-50 dark:hover:bg-surface-800 font-medium text-surface-700 dark:text-surface-300 transition-colors">
                                        <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-5 h-5" alt="Google" />
                                        Google Sign In
                                    </button>
                                </div>
                            </motion.div>
                        )}

                        {step === 2 && (
                            <motion.div
                                key="step2"
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: 20 }}
                                transition={{ duration: 0.3 }}
                            >
                                <h2 className="text-3xl font-bold font-display text-surface-900 dark:text-white mb-2">Almost Done!</h2>
                                <p className="text-surface-500 dark:text-surface-400 mb-8">Step 2: Review your benefits</p>

                                <div className="bg-primary-50 dark:bg-primary-900/10 rounded-xl p-6 mb-8 border border-primary-100 dark:border-primary-500/10">
                                    <h3 className="text-lg font-bold text-primary-900 dark:text-primary-100 mb-4 flex items-center gap-2">
                                        <Star className="w-5 h-5 text-primary-600 dark:text-primary-400" /> Contributor Benefits
                                    </h3>
                                    <ul className="space-y-3">
                                        <BenefitItem icon={<Users size={18} />} text="Reach thousands of students & alumni" />
                                        <BenefitItem icon={<BookOpen size={18} />} text="Build your verified campus portfolio" />
                                        <BenefitItem icon={<LayoutDashboard size={18} />} text="Full access to edit/delete your posts" />
                                        <BenefitItem icon={<LifeBuoy size={18} />} text="24/7 Support from the team" />
                                    </ul>
                                </div>

                                <div className="flex gap-4">
                                    <button onClick={handleBack} className="flex-1 py-3 border border-surface-300 dark:border-surface-700 text-surface-700 dark:text-surface-300 rounded-xl font-bold hover:bg-surface-50 dark:hover:bg-surface-800 transition-colors">
                                        Back
                                    </button>
                                    <button onClick={handleGoogleLogin} className="flex-1 py-3 bg-primary-600 text-white rounded-xl font-bold hover:bg-primary-700 transition-colors shadow-lg shadow-primary-500/20 flex items-center justify-center gap-2">
                                        Finish & Join <Check size={18} />
                                    </button>
                                </div>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </motion.div>
            </div>
        </div>
    );
};

const BenefitItem = ({ icon, text }) => (
    <li className="flex items-center gap-3 text-primary-700 dark:text-primary-200 font-medium text-sm">
        <div className="bg-white dark:bg-surface-800 p-1.5 rounded-md shadow-sm text-primary-500 dark:text-primary-400">{icon}</div> {text}
    </li>
);

export default ContributorRegister;
