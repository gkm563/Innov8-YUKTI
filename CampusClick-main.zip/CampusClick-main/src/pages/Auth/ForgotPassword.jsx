import React, { useState } from 'react';
import { sendPasswordResetEmail } from 'firebase/auth';
import { auth } from '../../services/firebase';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, ArrowLeft } from 'lucide-react';
import { toast } from 'react-toastify';

const ForgotPassword = () => {
    const [email, setEmail] = useState('');
    const [sent, setSent] = useState(false);
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            await sendPasswordResetEmail(auth, email);
            setSent(true);
            toast.success("Reset link sent!");
        } catch (error) {
            console.error(error);
            toast.error(error.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex bg-background-light dark:bg-background-dark text-surface-900 dark:text-surface-50 transition-colors duration-300">

            {/* Left Side - Visuals (Hidden on mobile) */}
            <div className="hidden lg:flex w-1/2 bg-surface-900 relative overflow-hidden items-center justify-center p-12 text-white">
                <div className="absolute inset-0 bg-hero-glowing opacity-30 animate-pulse-slow" />
                <div className="absolute inset-0 bg-black/20 backdrop-blur-[1px]" />

                <div className="relative z-10 max-w-lg">
                    <h1 className="text-6xl font-black tracking-tighter mb-6 font-display">
                        Reset Your<br />Password.
                    </h1>
                    <p className="text-xl text-surface-300 leading-relaxed mb-8">
                        Don't worry, it happens to the best of us. Enter your email and we'll help you get back into your account.
                    </p>
                    <div className="flex gap-4">
                        <div className="w-16 h-1 bg-primary-500 rounded-full" />
                        <div className="w-8 h-1 bg-surface-600 rounded-full" />
                    </div>
                </div>
            </div>

            {/* Right Side - Form */}
            <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 lg:p-24 bg-surface-50 dark:bg-surface-950">
                <div className="w-full max-w-md space-y-8">
                    <div className="text-center lg:text-left">
                        <h2 className="text-3xl font-bold tracking-tight font-display text-surface-900 dark:text-white">Forgot Password?</h2>
                        <p className="mt-2 text-sm text-surface-600 dark:text-surface-400">
                            Remember your password?{' '}
                            <Link to="/auth/login" className="font-medium text-primary-600 hover:text-primary-700 dark:text-primary-400 dark:hover:text-primary-300 transition-colors">
                                Sign In
                            </Link>
                        </p>
                    </div>

                    {!sent ? (
                        <motion.form
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.2 }}
                            onSubmit={handleSubmit}
                            className="mt-8 space-y-6"
                        >
                            <div>
                                <label htmlFor="email" className="sr-only">Email address</label>
                                <div className="relative group">
                                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                        <Mail className="h-5 w-5 text-surface-400 group-focus-within:text-primary-500 transition-colors" />
                                    </div>
                                    <input
                                        id="email"
                                        name="email"
                                        type="email"
                                        autoComplete="email"
                                        required
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        className="block w-full pl-11 pr-4 py-4 bg-white dark:bg-surface-900 border border-surface-200 dark:border-surface-700 rounded-xl text-surface-900 dark:text-white placeholder-surface-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all shadow-sm"
                                        placeholder="Enter your email"
                                    />
                                </div>
                            </div>

                            <button
                                type="submit"
                                disabled={loading}
                                className="w-full flex justify-center items-center py-4 px-4 border border-transparent rounded-xl shadow-lg shadow-primary-500/20 text-sm font-bold text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-[0.98]"
                            >
                                {loading ? "Sending..." : "Send Reset Link"}
                            </button>
                        </motion.form>
                    ) : (
                        <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className="mt-8 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 p-6 rounded-2xl text-center"
                        >
                            <div className="w-12 h-12 bg-green-100 dark:bg-green-800 rounded-full flex items-center justify-center mx-auto mb-4">
                                <Mail className="text-green-600 dark:text-green-400" size={24} />
                            </div>
                            <h3 className="text-lg font-bold text-surface-900 dark:text-white mb-2">Check your inbox</h3>
                            <p className="text-surface-600 dark:text-surface-300">
                                We've sent a password reset link to <br />
                                <span className="font-semibold">{email}</span>
                            </p>
                        </motion.div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ForgotPassword;
