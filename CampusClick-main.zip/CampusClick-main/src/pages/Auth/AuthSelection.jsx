import React from 'react';
import { motion } from 'framer-motion';
import { User, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';

const AuthSelection = () => {
    return (
        <div className="min-h-screen pt-20 flex items-center justify-center bg-background-light dark:bg-background-dark px-4 transition-colors duration-300 relative z-0">
            <div className="fixed inset-0 pointer-events-none z-[-1]">
                <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary-500/10 rounded-full blur-[100px]" />
                <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-secondary-500/10 rounded-full blur-[100px]" />
            </div>

            <div className="max-w-4xl w-full">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-bold font-display text-surface-900 dark:text-white mb-4">Welcome to CampusClick</h1>
                    <p className="text-surface-600 dark:text-surface-400 text-lg">Choose how you want to contribute to the archive.</p>
                </div>

                <div className="flex justify-center">
                    <Link to="/auth/register" className="w-full max-w-md">
                        <motion.div
                            whileHover={{ y: -5 }}
                            className="bg-white dark:bg-surface-800 p-8 rounded-2xl shadow-lg border border-surface-200 dark:border-surface-700 hover:border-primary-200 dark:hover:border-primary-500/30 hover:shadow-xl transition-all h-full cursor-pointer group"
                        >
                            <div className="w-16 h-16 bg-primary-100 dark:bg-primary-900/30 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-primary-600 transition-colors">
                                <User className="w-8 h-8 text-primary-600 dark:text-primary-400 group-hover:text-white" />
                            </div>
                            <h2 className="text-2xl font-bold font-display text-surface-900 dark:text-white mb-3">Join as Contributor</h2>
                            <p className="text-surface-600 dark:text-surface-400">
                                For students, faculty, and alumni. Upload photos, share memories, and build your portfolio.
                            </p>
                        </motion.div>
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default AuthSelection;
