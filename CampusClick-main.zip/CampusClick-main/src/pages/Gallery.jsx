import React from 'react';
import MasonryGrid from '../components/MasonryGrid';
import { motion } from 'framer-motion';

const Gallery = () => {
    return (
        <div className="min-h-screen bg-background-light dark:bg-background-dark">
            {/* Background Ambience */}
            <div className="fixed inset-0 pointer-events-none overflow-hidden">
                <div className="absolute top-[-10%] right-[-5%] w-[40%] h-[40%] bg-primary-500/10 rounded-full blur-[120px] animate-pulse-slow" />
                <div className="absolute bottom-[10%] left-[-10%] w-[40%] h-[40%] bg-secondary-500/10 rounded-full blur-[120px] animate-pulse-slow delay-1000" />
            </div>

            <div className="relative z-10 container-custom section-padding pt-8">
                {/* Hero Header */}
                <div className="text-center mb-12 pt-8">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="inline-block px-4 py-1.5 mb-6 rounded-full glass border border-primary-500/30 text-primary-600 dark:text-primary-400 font-medium text-sm tracking-wider uppercase"
                    >
                        Memories stored on-chain
                    </motion.div>
                    <motion.h1
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="text-4xl md:text-6xl font-bold mb-6 font-display tracking-tight text-surface-900 dark:text-white"
                    >
                        The Smart <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-500 to-secondary-500 animate-gradient">Gallery</span>
                    </motion.h1>
                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="text-lg text-surface-600 dark:text-surface-300 max-w-2xl mx-auto leading-relaxed"
                    >
                        A decentralized collection of moments. Secure, permanent, and community-driven.
                    </motion.p>
                </div>

                {/* Main Grid */}
                <MasonryGrid selectedYear="All" />
            </div>
        </div>
    );
};

export default Gallery;
