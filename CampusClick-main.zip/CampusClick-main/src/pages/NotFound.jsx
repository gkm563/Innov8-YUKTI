import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Home, Compass, Radio } from 'lucide-react';

const NotFound = () => {
    return (
        <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4 overflow-hidden relative">

            {/* Background Animations */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
                <motion.div
                    animate={{
                        scale: [1, 1.2, 1],
                        opacity: [0.3, 0.5, 0.3]
                    }}
                    transition={{ duration: 8, repeat: Infinity }}
                    className="absolute -top-1/2 -left-1/2 w-[200%] h-[200%] bg-[radial-gradient(circle,rgba(59,130,246,0.1)_0%,rgba(0,0,0,0)_50%)]"
                />
            </div>

            <div className="max-w-2xl w-full text-center relative z-10">
                <motion.div
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ type: "spring", duration: 0.8 }}
                    className="mb-8"
                >
                    <div className="relative inline-block">
                        <span className="text-9xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-purple-600 opacity-20 select-none">
                            404
                        </span>
                        <div className="absolute inset-0 flex items-center justify-center">
                            <motion.div
                                animate={{ rotate: 360 }}
                                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                                className="w-40 h-40 border-4 border-dashed border-blue-500/30 rounded-full"
                            />
                            <Compass className="w-20 h-20 text-blue-400 absolute" />
                        </div>
                    </div>
                </motion.div>

                <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                >
                    <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
                        Oops! This memory is lost.
                    </h1>
                    <p className="text-xl text-gray-400 mb-8 max-w-lg mx-auto leading-relaxed">
                        The page you are looking for has drifted into deep space or doesn't exist.
                    </p>

                    <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                        <Link to="/">
                            <motion.button
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                                className="px-8 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-blue-500/20 transition-all"
                            >
                                <Home size={20} />
                                Return to Base
                            </motion.button>
                        </Link>

                        <div className="flex items-center gap-2 text-gray-500 text-sm bg-gray-800/50 px-4 py-2 rounded-full border border-gray-700">
                            <Radio className="w-4 h-4 text-green-500 animate-pulse" />
                            <span>System Status: Normal</span>
                        </div>
                    </div>
                </motion.div>
            </div>
        </div>
    );
};

export default NotFound;
