import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { getEvents } from '../services/eventService';
import EventCard from '../components/EventCard';
import EventGalleryModal from '../components/EventGalleryModal';
import { Filter, Music, Palette, Mic, Smile, Search, Calendar as CalendarIcon } from 'lucide-react';
import Card from '../components/ui/Card';

const CampusEvents = () => {
    const [events, setEvents] = useState([]);
    const [filteredEvents, setFilteredEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('Upcoming');
    const [categoryFilter, setCategoryFilter] = useState('All');
    const [error, setError] = useState(null);
    const [selectedEventForGallery, setSelectedEventForGallery] = useState(null);

    useEffect(() => {
        const fetch = async () => {
            try {
                const allEvents = await getEvents();
                // We show all events here, not just cultural, as per user request for "Timeline"
                // Or stick to original filter if desired. Let's show all for "Campus Timeline" feel.
                setEvents(allEvents);
            } catch (err) {
                console.error(err);
                if (err.code === 'permission-denied') {
                    setError("Access Denied: Please check permissions.");
                } else {
                    setError("Unable to load events.");
                }
            } finally {
                setLoading(false);
            }
        };
        fetch();
    }, []);

    useEffect(() => {
        let result = events.filter(e => e.status === activeTab);
        if (categoryFilter !== 'All') {
            result = result.filter(e => e.category === categoryFilter.toLowerCase());
        }
        setFilteredEvents(result);
    }, [events, activeTab, categoryFilter]);

    const categories = [
        { name: 'All', icon: Filter },
        { name: 'Cultural', icon: Music, label: 'Cultural' },
        { name: 'Technical', icon: Mic, label: 'Technical' },
        { name: 'Exhibition', icon: Palette },
        { name: 'Other', icon: Smile },
    ];

    return (
        <div className="min-h-screen bg-background-light dark:bg-background-dark pb-20">
            {/* Background Ambience */}
            <div className="fixed inset-0 pointer-events-none overflow-hidden">
                <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-secondary-500/10 rounded-full blur-[100px] animate-pulse-slow" />
                <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-primary-500/10 rounded-full blur-[100px] animate-pulse-slow delay-1000" />
            </div>

            <div className="relative z-10 container-custom pt-12">
                {/* Hero Section */}
                <div className="text-center mb-16 pt-12">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="inline-flex items-center gap-2 px-4 py-1.5 mb-6 rounded-full glass border border-secondary-500/30 text-secondary-600 dark:text-secondary-400 font-medium text-sm tracking-wider uppercase"
                    >
                        <CalendarIcon size={14} /> Campus Timeline
                    </motion.div>
                    <motion.h1
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="text-5xl md:text-7xl font-bold mb-6 font-display tracking-tight text-surface-900 dark:text-white"
                    >
                        Moments in <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary-500 to-primary-500">Motion</span>
                    </motion.h1>
                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="text-xl text-surface-600 dark:text-surface-300 max-w-2xl mx-auto leading-relaxed"
                    >
                        Explore the pulse of our university through upcoming fests, ongoing workshops, and the gallery of past memories.
                    </motion.p>
                </div>

                <div className="flex flex-col lg:flex-row gap-10">
                    {/* Sidebar Filters */}
                    <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.3 }}
                        className="w-full lg:w-72 flex-shrink-0"
                    >
                        <Card variant="glass" className="p-6 sticky top-28">
                            <h3 className="font-bold text-surface-900 dark:text-white uppercase text-xs mb-6 tracking-widest flex items-center gap-2">
                                <Filter size={14} className="text-secondary-500" /> Filter Categories
                            </h3>
                            <div className="space-y-2">
                                {categories.map(cat => (
                                    <button
                                        key={cat.name}
                                        onClick={() => setCategoryFilter(cat.name)}
                                        className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm border ${categoryFilter === cat.name
                                            ? 'bg-secondary-500/10 text-secondary-600 dark:text-secondary-400 border-secondary-500/20 shadow-sm'
                                            : 'text-surface-600 dark:text-surface-400 border-transparent hover:bg-surface-100 dark:hover:bg-surface-800'
                                            }`}
                                    >
                                        <cat.icon size={18} className={categoryFilter === cat.name ? 'text-secondary-500' : ''} />
                                        <span>{cat.label || cat.name}</span>
                                    </button>
                                ))}
                            </div>
                        </Card>
                    </motion.div>

                    {/* Main Content */}
                    <div className="flex-1">
                        {/* Tabs */}
                        <div className="flex gap-4 mb-8 border-b border-surface-200 dark:border-surface-700 pb-1 overflow-x-auto">
                            {['Upcoming', 'Ongoing', 'Past'].map(tab => (
                                <button
                                    key={tab}
                                    onClick={() => setActiveTab(tab)}
                                    className={`px-4 py-3 font-medium text-sm transition-all relative whitespace-nowrap ${activeTab === tab
                                        ? 'text-secondary-600 dark:text-secondary-400'
                                        : 'text-surface-500 dark:text-surface-400 hover:text-surface-800 dark:hover:text-surface-200'
                                        }`}
                                >
                                    {tab} Events
                                    {activeTab === tab && (
                                        <motion.div
                                            layoutId="activeTabEvents"
                                            className="absolute bottom-0 left-0 right-0 h-0.5 bg-secondary-500"
                                        />
                                    )}
                                </button>
                            ))}
                        </div>

                        {/* Grid */}
                        {error ? (
                            <div className="text-center py-20 rounded-2xl bg-error/5 border border-error/10">
                                <h3 className="text-lg font-bold mb-2 text-error">System Error</h3>
                                <p className="text-surface-600 dark:text-surface-400">{error}</p>
                            </div>
                        ) : loading ? (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {[1, 2, 3, 4].map(n => (
                                    <div key={n} className="h-96 rounded-2xl bg-surface-100 dark:bg-surface-800 animate-pulse" />
                                ))}
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <AnimatePresence mode="popLayout">
                                    {filteredEvents.length > 0 ? (
                                        filteredEvents.map(event => (
                                            <EventCard
                                                key={event.id}
                                                event={event}
                                                onExploreGallery={() => setSelectedEventForGallery(event)}
                                            />
                                        ))
                                    ) : (
                                        <motion.div
                                            initial={{ opacity: 0 }}
                                            animate={{ opacity: 1 }}
                                            className="col-span-full py-24 text-center border-2 border-dashed border-surface-200 dark:border-surface-700 rounded-3xl"
                                        >
                                            <div className="w-16 h-16 bg-surface-100 dark:bg-surface-800 rounded-full flex items-center justify-center mx-auto mb-4 text-surface-400">
                                                <Search size={24} />
                                            </div>
                                            <p className="text-surface-500 dark:text-surface-400 font-medium">
                                                No {activeTab.toLowerCase()} events found in this category.
                                            </p>
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Gallery Modal */}
            <EventGalleryModal
                event={selectedEventForGallery}
                onClose={() => setSelectedEventForGallery(null)}
            />
        </div>
    );
};

export default CampusEvents;
