import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Trophy, Medal, Award, TrendingUp, Search, Crown } from 'lucide-react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../services/firebase';
import Card from '../components/ui/Card';
import SEO from '../components/SEO';
import UserUploadsModal from '../components/UserUploadsModal';

const Leaderboard = () => {
    const [contributors, setContributors] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedUser, setSelectedUser] = useState(null);
    const [isUploadsModalOpen, setIsUploadsModalOpen] = useState(false);

    useEffect(() => {
        fetchLeaderboardData();
    }, []);

    const fetchLeaderboardData = async () => {
        try {
            // Fetch users and posts in parallel
            const [usersSnapshot, postsSnapshot] = await Promise.all([
                getDocs(collection(db, 'users')),
                getDocs(collection(db, 'posts'))
            ]);

            // Map users for easy lookup
            const usersMap = {};
            usersSnapshot.docs.forEach(doc => {
                usersMap[doc.id] = { id: doc.id, ...doc.data() };
            });

            // Aggregate upload counts per user
            const uploadCounts = {};
            postsSnapshot.docs.forEach(doc => {
                const data = doc.data();
                const userId = data.userId || data.uploadedBy?.uid; // robust check
                if (userId) {
                    uploadCounts[userId] = (uploadCounts[userId] || 0) + 1;
                }
            });

            // Create leaderboard array
            let leaderboardData = [];
            Object.keys(uploadCounts).forEach(userId => {
                const user = usersMap[userId];
                if (user) {
                    leaderboardData.push({
                        ...user,
                        uploads: uploadCounts[userId],
                        name: user.displayName || 'Anonymous User',
                        avatar: user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName || 'User'}&background=random`,
                        dept: user.department || 'General' // Assuming 'department' field exists or defaulting
                    });
                }
            });

            // Sort by uploads descending
            leaderboardData.sort((a, b) => b.uploads - a.uploads);

            // Assign ranks (handling ties if needed, but simple index for now)
            leaderboardData = leaderboardData.map((user, index) => ({
                ...user,
                rank: index + 1
            }));

            setContributors(leaderboardData);
        } catch (error) {
            console.error("Error loading leaderboard:", error);
        } finally {
            setLoading(false);
        }
    };

    const contributorOfTheMonth = contributors.length > 0 ? contributors[0] : null;

    const getBadges = (user, index) => {
        const badges = [];
        if (index === 0) badges.push({ icon: '👑', title: 'Campus King/Queen' });
        if (index === 1) badges.push({ icon: '🥈', title: 'Silver Star' });
        if (index === 2) badges.push({ icon: '🥉', title: 'Bronze Hero' });

        if (user.uploads >= 50) badges.push({ icon: '🔥', title: 'On Fire (50+)' });
        if (user.uploads >= 20 && user.uploads < 50) badges.push({ icon: '📸', title: 'Shutterbug (20+)' });
        if (user.uploads >= 10 && user.uploads < 20) badges.push({ icon: '⭐', title: 'Rising Star (10+)' });

        return badges;
    };

    return (
        <div className="min-h-screen pt-24 pb-20 bg-background-light dark:bg-background-dark">
            <SEO title="Leaderboard" description="See the top contributors and active members of the CampusClick community." />

            <UserUploadsModal
                isOpen={isUploadsModalOpen}
                onClose={() => setIsUploadsModalOpen(false)}
                user={selectedUser}
            />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

                {/* Header */}
                <div className="text-center mb-16">
                    <motion.div
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        className="inline-block p-3 bg-yellow-100 dark:bg-yellow-900/30 rounded-full mb-4 text-yellow-600 dark:text-yellow-400"
                    >
                        <Trophy size={32} />
                    </motion.div>
                    <h1 className="text-4xl md:text-5xl font-bold mb-4 font-display text-surface-900 dark:text-white">
                        Discovery <span className="text-primary-600">Leaderboard</span>
                    </h1>
                    <p className="text-lg text-surface-600 dark:text-surface-300">
                        Celebrating the top curators of our campus memories.
                    </p>
                </div>

                {loading ? (
                    <div className="text-center py-20">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto"></div>
                        <p className="mt-4 text-surface-500">Calculating rankings...</p>
                    </div>
                ) : (
                    <>
                        {/* Contributor of the Month */}
                        {contributorOfTheMonth && (
                            <motion.div
                                initial={{ y: 20, opacity: 0 }}
                                animate={{ y: 0, opacity: 1 }}
                                transition={{ delay: 0.2 }}
                                className="mb-16 cursor-pointer transform transition-transform hover:scale-[1.01]"
                                onClick={() => { setSelectedUser(contributorOfTheMonth); setIsUploadsModalOpen(true); }}
                            >
                                <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-2xl p-8 md:p-12 flex flex-col md:flex-row items-center gap-8 md:gap-16">
                                    <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16"></div>
                                    <div className="absolute bottom-0 left-0 w-64 h-64 bg-black/10 rounded-full blur-3xl -ml-16 -mb-16"></div>

                                    <div className="relative z-10 flex-shrink-0">
                                        <div className="w-32 h-32 md:w-48 md:h-48 rounded-full border-4 border-white/30 shadow-2xl overflow-hidden relative">
                                            <img src={contributorOfTheMonth.avatar} alt={contributorOfTheMonth.name} className="w-full h-full object-cover" />
                                            <div className="absolute inset-0 bg-black/20" />
                                            <div className="absolute bottom-0 left-0 right-0 bg-yellow-500 text-xs font-bold text-center py-1 uppercase tracking-wider">
                                                #1 Ranked
                                            </div>
                                        </div>
                                        <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-white text-indigo-600 px-4 py-1.5 rounded-full font-bold shadow-lg whitespace-nowrap text-sm flex items-center gap-2">
                                            <Crown size={16} className="text-yellow-500" /> Top Contributor
                                        </div>
                                    </div>

                                    <div className="relative z-10 text-center md:text-left">
                                        <h2 className="text-xl md:text-2xl font-bold text-indigo-200 uppercase tracking-widest mb-2">Contributor of the Month</h2>
                                        <h3 className="text-4xl md:text-6xl font-black mb-4">{contributorOfTheMonth.name}</h3>
                                        <div className="flex flex-wrap justify-center md:justify-start gap-4 text-indigo-100 font-medium text-lg">
                                            <span className="px-4 py-2 bg-white/10 rounded-lg backdrop-blur-sm border border-white/10">Department: {contributorOfTheMonth.dept}</span>
                                            <span className="px-4 py-2 bg-white/10 rounded-lg backdrop-blur-sm border border-white/10 flex items-center gap-2">
                                                <TrendingUp size={20} /> {contributorOfTheMonth.uploads} Uploads
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </motion.div>
                        )}

                        {/* Table */}
                        <motion.div
                            initial={{ y: 20, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            transition={{ delay: 0.3 }}
                        >
                            <Card className="overflow-hidden border border-surface-200 dark:border-surface-700">
                                <div className="overflow-x-auto">
                                    <table className="w-full">
                                        <thead className="bg-surface-50 dark:bg-surface-800 border-b border-surface-200 dark:border-surface-700">
                                            <tr>
                                                <th className="px-6 py-4 text-left text-xs font-bold text-surface-500 dark:text-surface-400 uppercase tracking-wider">Rank</th>
                                                <th className="px-6 py-4 text-left text-xs font-bold text-surface-500 dark:text-surface-400 uppercase tracking-wider">Name</th>
                                                <th className="px-6 py-4 text-left text-xs font-bold text-surface-500 dark:text-surface-400 uppercase tracking-wider">Department</th>
                                                <th className="px-6 py-4 text-left text-xs font-bold text-surface-500 dark:text-surface-400 uppercase tracking-wider">Total Uploads</th>
                                                <th className="px-6 py-4 text-left text-xs font-bold text-surface-500 dark:text-surface-400 uppercase tracking-wider">Badges</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-surface-200 dark:divide-surface-700">
                                            {contributors.map((c, i) => (
                                                <tr
                                                    key={c.id}
                                                    className="hover:bg-surface-50 dark:hover:bg-surface-800/50 transition-colors cursor-pointer"
                                                    onClick={() => { setSelectedUser(c); setIsUploadsModalOpen(true); }}
                                                >
                                                    <td className="px-6 py-4 whitespace-nowrap">
                                                        <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold overflow-visible
                                                            ${c.rank === 1 ? 'bg-yellow-100 text-yellow-600' :
                                                                c.rank === 2 ? 'bg-gray-100 text-gray-600' :
                                                                    c.rank === 3 ? 'bg-orange-100 text-orange-600' : 'text-surface-500'} 
                                                        `}>
                                                            {c.rank <= 3 ? <Medal size={20} /> : `#${c.rank}`}
                                                        </div>
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap">
                                                        <div className="flex items-center gap-3">
                                                            <img src={c.avatar} alt="" className="w-10 h-10 rounded-full object-cover" />
                                                            <div className="font-semibold text-surface-900 dark:text-white group-hover:text-primary-600 transition-colors">{c.name}</div>
                                                        </div>
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap">
                                                        <span className="px-3 py-1 rounded-full text-xs font-medium bg-surface-100 dark:bg-surface-800 text-surface-600 dark:text-surface-300">
                                                            {c.dept}
                                                        </span>
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap">
                                                        <div className="text-surface-900 dark:text-white font-bold">{c.uploads}</div>
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap">
                                                        <div className="flex gap-1" title="User Capabilities">
                                                            {getBadges(c, i).map((badge, idx) => (
                                                                <span key={idx} title={badge.title} className="hover:scale-125 transition-transform cursor-help">
                                                                    {badge.icon}
                                                                </span>
                                                            ))}
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                    {contributors.length === 0 && (
                                        <div className="p-8 text-center text-surface-500">
                                            No contributors found yet. Be the first!
                                        </div>
                                    )}
                                </div>
                            </Card>
                        </motion.div>
                    </>
                )}
            </div>
        </div>
    );
};

export default Leaderboard;
