import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { updateProfile, updatePassword, deleteUser } from 'firebase/auth';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { collection, query, where, getDocs, writeBatch } from 'firebase/firestore';
import { auth, storage, db } from '../services/firebase';
import { toast } from 'react-toastify';
import { User, Lock, Trash2, Camera, Save, AlertTriangle } from 'lucide-react';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';

const Profile = () => {
    const { user } = useAuth();
    const [displayName, setDisplayName] = useState(user?.displayName || '');
    const [newPassword, setNewPassword] = useState('');
    const [photo, setPhoto] = useState(null);
    const [loading, setLoading] = useState(false);

    if (!user) return <div className="pt-32 text-center text-surface-600">Please log in.</div>;

    const handleUpdateProfile = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            let photoURL = user.photoURL;

            if (photo) {
                const storageRef = ref(storage, `profile_photos/${user.uid}`);
                await uploadBytes(storageRef, photo);
                photoURL = await getDownloadURL(storageRef);
            }

            await updateProfile(auth.currentUser, {
                displayName,
                photoURL
            });

            // Update all past posts with new name (Batch Operation)
            const batch = writeBatch(db);
            const q = query(collection(db, 'posts'), where('uploadedBy.uid', '==', user.uid));
            const querySnapshot = await getDocs(q);

            querySnapshot.forEach((doc) => {
                batch.update(doc.ref, {
                    userName: displayName,
                    'uploadedBy.displayName': displayName,
                    'uploadedBy.photoURL': photoURL
                });
            });
            await batch.commit();

            if (newPassword) {
                await updatePassword(auth.currentUser, newPassword);
            }

            toast.success("Profile updated! Name sync active.");
        } catch (error) {
            console.error(error);
            toast.error("Failed to update profile: " + error.message);
        } finally {
            setLoading(false);
        }
    };

    const handleDeleteAccount = async () => {
        if (window.confirm("ARE YOU SURE? This action cannot be undone. All your data will be lost.")) {
            try {
                await deleteUser(auth.currentUser);
                toast.info("Account deleted.");
            } catch (error) {
                console.error(error);
                toast.error("Failed to delete account. You may need to re-login first.");
            }
        }
    };

    return (
        <div className="min-h-screen pt-24 pb-20 px-4 bg-background-light dark:bg-background-dark transition-colors duration-300">
            {/* Background Ambience */}
            <div className="fixed inset-0 pointer-events-none overflow-hidden">
                <div className="absolute -top-40 -right-40 w-[600px] h-[600px] bg-secondary-500/10 rounded-full blur-[120px]" />
                <div className="absolute top-40 left-0 w-[400px] h-[400px] bg-primary-500/10 rounded-full blur-[100px]" />
            </div>

            <div className="relative z-10 max-w-2xl mx-auto">
                <h1 className="text-3xl font-bold font-display text-surface-900 dark:text-white mb-8 text-center">Profile Settings</h1>

                <Card className="p-8 border-surface-200 dark:border-surface-700 bg-white/50 dark:bg-surface-800/80 backdrop-blur-xl">

                    {/* Header with Photo */}
                    <div className="flex flex-col items-center gap-6 mb-10">
                        <div className="relative group cursor-pointer">
                            <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-surface-50 dark:border-surface-700 shadow-2xl ring-4 ring-primary-500/20">
                                <img
                                    src={photo ? URL.createObjectURL(photo) : (user.photoURL || 'https://via.placeholder.com/150')}
                                    alt="Profile"
                                    className="w-full h-full object-cover"
                                />
                            </div>
                            <label className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-full text-white cursor-pointer backdrop-blur-sm">
                                <Camera size={32} />
                                <input type="file" className="hidden" onChange={(e) => setPhoto(e.target.files[0])} />
                            </label>
                        </div>
                        <div className="text-center">
                            <h2 className="text-2xl font-bold text-surface-900 dark:text-white">{user.displayName || 'Contributor'}</h2>
                            <p className="text-surface-500 font-medium">{user.email}</p>
                        </div>
                    </div>

                    <form onSubmit={handleUpdateProfile} className="space-y-6">
                        <div>
                            <label className="block text-xs font-bold text-surface-500 uppercase tracking-wider mb-2">Display Name</label>
                            <div className="relative">
                                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-surface-400 w-5 h-5" />
                                <input
                                    type="text"
                                    value={displayName}
                                    onChange={(e) => setDisplayName(e.target.value)}
                                    className="w-full pl-12 pr-4 py-3 rounded-xl border border-surface-200 dark:border-surface-600 bg-surface-50 dark:bg-surface-800/50 text-surface-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none transition-all placeholder:text-surface-400"
                                />
                            </div>
                        </div>

                        <div>
                            <label className="block text-xs font-bold text-surface-500 uppercase tracking-wider mb-2">New Password <span className="text-surface-400 font-normal normal-case">(Optional)</span></label>
                            <div className="relative">
                                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-surface-400 w-5 h-5" />
                                <input
                                    type="password"
                                    value={newPassword}
                                    onChange={(e) => setNewPassword(e.target.value)}
                                    className="w-full pl-12 pr-4 py-3 rounded-xl border border-surface-200 dark:border-surface-600 bg-surface-50 dark:bg-surface-800/50 text-surface-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none transition-all placeholder:text-surface-400"
                                    placeholder="••••••••"
                                />
                            </div>
                        </div>

                        <div className="pt-6">
                            <Button
                                type="submit"
                                isLoading={loading}
                                className="w-full"
                                icon={<Save size={18} />}
                            >
                                Save Changes
                            </Button>
                        </div>
                    </form>

                    <div className="mt-12 pt-8 border-t border-surface-200 dark:border-surface-700">
                        <div className="flex items-start gap-4 p-4 rounded-xl bg-error/5 border border-error/10">
                            <AlertTriangle className="text-error shrink-0" size={24} />
                            <div className="flex-1">
                                <h3 className="text-error font-bold mb-1">Danger Zone</h3>
                                <p className="text-sm text-surface-600 dark:text-surface-400 mb-4">Once you delete your account, there is no going back. Please be certain.</p>
                                <Button
                                    onClick={handleDeleteAccount}
                                    variant="outline"
                                    className="!border-error/30 !text-error hover:!bg-error hover:!text-white w-full sm:w-auto"
                                    icon={<Trash2 size={16} />}
                                >
                                    Delete Account
                                </Button>
                            </div>
                        </div>
                    </div>
                </Card>
            </div>
        </div>
    );
};

export default Profile;
