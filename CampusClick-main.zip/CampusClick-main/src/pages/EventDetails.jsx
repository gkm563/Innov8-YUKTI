import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, updateDoc, arrayUnion, arrayRemove } from 'firebase/firestore';
import { db } from '../services/firebase';
import { motion } from 'framer-motion';
import { Calendar, MapPin, Clock, Share2, ArrowLeft, Tag, Globe, User, Shield, Trophy, FileText, DollarSign, Users, AlertCircle, CheckCircle, Bookmark } from 'lucide-react';
import { toast } from 'react-toastify';
import { useAuth } from '../context/AuthContext';

const EventDetails = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const { user, userData } = useAuth();
    const [event, setEvent] = useState(null);
    const [loading, setLoading] = useState(true);
    const [isSaved, setIsSaved] = useState(false);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        const fetchEvent = async () => {
            try {
                const docRef = doc(db, 'events', id);
                const docSnap = await getDoc(docRef);

                if (docSnap.exists()) {
                    setEvent({ id: docSnap.id, ...docSnap.data() });
                } else {
                    toast.error("Event not found");
                    navigate('/events');
                }
            } catch (error) {
                console.error("Error fetching event:", error);
                toast.error("Failed to load event details");
            } finally {
                setLoading(false);
            }
        };

        fetchEvent();
    }, [id, navigate]);

    useEffect(() => {
        if (userData?.savedEvents && event) {
            setIsSaved(userData.savedEvents.includes(event.id));
        }
    }, [userData, event]);

    const handleSave = async () => {
        if (!user) {
            toast.info("Please log in to save events for later!");
            // navigate('/auth/login'); // Optional: could redirect, but maybe just a toast is better UX for now
            return;
        }

        const newSavedState = !isSaved;
        setIsSaved(newSavedState); // Optimistic UI
        setSaving(true);

        try {
            const userRef = doc(db, 'users', user.uid);
            await updateDoc(userRef, {
                savedEvents: newSavedState ? arrayUnion(event.id) : arrayRemove(event.id)
            });
            toast.success(newSavedState ? "Event saved to Dashboard!" : "Event removed from saved.");
        } catch (error) {
            console.error("Error saving event:", error);
            setIsSaved(!newSavedState); // Revert
            toast.error("Failed to update saved events.");
        } finally {
            setSaving(false);
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen pt-24 flex items-center justify-center bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-600"></div>
            </div>
        );
    }

    if (!event) return null;

    const isTech = event.type === 'tech';
    const accentColor = isTech ? 'cyan' : 'pink';

    const formatDate = (date) => {
        if (!date) return 'TBA';
        const d = date.toDate ? date.toDate() : new Date(date);
        return d.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    };

    const formatTime = (date) => {
        if (!date) return '';
        const d = date.toDate ? date.toDate() : new Date(date);
        return d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
    };

    return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
            {/* Hero Section */}
            <div className="relative h-[60vh] md:h-[70vh] overflow-hidden">
                <div className="absolute inset-0 bg-black/50 z-10" />
                <div className={`absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent z-20`} />
                <img
                    src={event.bannerUrl}
                    alt={event.title}
                    className="w-full h-full object-cover"
                />

                <div className="absolute top-24 left-4 z-30">
                    <button
                        onClick={() => navigate(-1)}
                        className="p-3 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-full text-white transition-colors"
                    >
                        <ArrowLeft size={24} />
                    </button>
                </div>

                <div className="absolute bottom-0 left-0 right-0 p-6 md:p-12 z-30 max-w-7xl mx-auto w-full">
                    <motion.div
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        className="space-y-6"
                    >
                        <div className="flex flex-wrap gap-2">
                            <span className={`px-4 py-1.5 rounded-full text-sm font-bold uppercase tracking-wider bg-${accentColor}-600 text-white shadow-lg`}>
                                {event.category.replace('_', ' ')}
                            </span>
                            <span className={`px-4 py-1.5 rounded-full text-sm font-bold uppercase tracking-wider border border-white/30 text-white backdrop-blur-md`}>
                                {event.status || 'Upcoming'}
                            </span>
                        </div>
                        <h1 className="text-4xl md:text-7xl font-black text-white leading-tight drop-shadow-2xl">
                            {event.title}
                        </h1>
                        <div className="flex flex-wrap items-center gap-6 text-gray-200 text-sm md:text-lg font-medium">
                            <div className="flex items-center gap-2 bg-black/30 px-4 py-2 rounded-full backdrop-blur-sm">
                                <Calendar size={20} className={`text-${accentColor}-400`} />
                                <span>{formatDate(event.startDate)}</span>
                            </div>
                            <div className="flex items-center gap-2 bg-black/30 px-4 py-2 rounded-full backdrop-blur-sm">
                                <MapPin size={20} className={`text-${accentColor}-400`} />
                                <span>{event.venue || 'To be announced'}</span>
                            </div>
                        </div>
                    </motion.div>
                </div>
            </div>

            <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-12 relative z-30 -mt-20">

                {/* Main Content */}
                <div className="lg:col-span-2 space-y-8">

                    {/* Description */}
                    <motion.div
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.1 }}
                        className="bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-xl border border-gray-200 dark:border-gray-700"
                    >
                        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white flex items-center gap-2">
                            <FileText className={`text-${accentColor}-500`} /> About the Event
                        </h2>
                        <div className="prose dark:prose-invert max-w-none text-gray-600 dark:text-gray-300 leading-relaxed whitespace-pre-line text-lg">
                            {event.description}
                        </div>
                    </motion.div>

                    {/* Rules & Guidelines */}
                    {event.rules && (
                        <motion.div
                            initial={{ y: 20, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            transition={{ delay: 0.2 }}
                            className="bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-xl border border-gray-200 dark:border-gray-700"
                        >
                            <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white flex items-center gap-2">
                                <AlertCircle className={`text-${accentColor}-500`} /> Rules & Guidelines
                            </h2>
                            <div className="prose dark:prose-invert max-w-none text-gray-600 dark:text-gray-300 whitespace-pre-line">
                                {event.rules}
                            </div>
                        </motion.div>
                    )}

                    {/* Hackathon Specs if type=tech */}
                    {isTech && (
                        <motion.div
                            initial={{ y: 20, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            transition={{ delay: 0.25 }}
                            className="bg-gradient-to-br from-indigo-900 to-purple-900 rounded-3xl p-8 shadow-xl text-white relative overflow-hidden"
                        >
                            <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -mr-16 -mt-16"></div>
                            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2 relative z-10">
                                <Trophy className="text-yellow-400" /> Hackathon Highlights
                            </h2>
                            <div className="grid md:grid-cols-2 gap-8 relative z-10">
                                <div>
                                    <p className="text-indigo-200 text-sm font-bold uppercase tracking-wider mb-1">Prize Pool</p>
                                    <p className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-yellow-500">
                                        {event.prizePool || 'TBA'}
                                    </p>
                                </div>
                                <div>
                                    <p className="text-indigo-200 text-sm font-bold uppercase tracking-wider mb-2">Team Structure</p>
                                    <div className="flex items-center gap-3">
                                        <Users className="text-indigo-300" />
                                        <span className="text-xl font-bold">{event.teamSizeMin || 1} - {event.teamSizeMax || 4} Members</span>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    )}

                    {/* Sponsors */}
                    {event.sponsors && (
                        <motion.div
                            initial={{ y: 20, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            transition={{ delay: 0.3 }}
                            className="bg-gray-100 dark:bg-gray-800/50 rounded-3xl p-8 border border-dashed border-gray-300 dark:border-gray-700"
                        >
                            <h3 className="text-lg font-bold text-gray-500 uppercase tracking-widest text-center mb-6">Supported By</h3>
                            <div className="flex flex-wrap justify-center gap-4">
                                {event.sponsors.split(',').map((sponsor, idx) => (
                                    <span key={idx} className="px-6 py-3 bg-white dark:bg-gray-800 rounded-xl font-bold text-gray-700 dark:text-gray-300 shadow-sm">
                                        {sponsor.trim()}
                                    </span>
                                ))}
                            </div>
                        </motion.div>
                    )}
                </div>

                {/* Sidebar / Actions */}
                <div className="lg:col-span-1 space-y-6">
                    <motion.div
                        initial={{ x: 20, opacity: 0 }}
                        animate={{ x: 0, opacity: 1 }}
                        transition={{ delay: 0.3 }}
                        className="bg-white dark:bg-gray-800 rounded-3xl p-6 shadow-xl border border-gray-200 dark:border-gray-700 sticky top-24"
                    >
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6 border-b border-gray-200 dark:border-gray-700 pb-4">
                            Event Logistics
                        </h3>

                        <div className="space-y-6 mb-8">
                            <div className="flex items-start gap-4">
                                <Clock className={`w-6 h-6 text-${accentColor}-500 mt-1`} />
                                <div>
                                    <p className="font-semibold text-gray-900 dark:text-white">Date & Time</p>
                                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                                        Start: {formatDate(event.startDate)} @ {formatTime(event.startDate)} <br />
                                        End: {formatDate(event.endDate)} @ {formatTime(event.endDate)}
                                    </p>
                                </div>
                            </div>
                            <div className="flex items-start gap-4">
                                <MapPin className={`w-6 h-6 text-${accentColor}-500 mt-1`} />
                                <div>
                                    <p className="font-semibold text-gray-900 dark:text-white">Location</p>
                                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{event.venue}</p>
                                </div>
                            </div>
                            <div className="flex items-start gap-4">
                                <User className={`w-6 h-6 text-${accentColor}-500 mt-1`} />
                                <div>
                                    <p className="font-semibold text-gray-900 dark:text-white">Eligibility</p>
                                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{event.audience || 'Open to all students'}</p>
                                </div>
                            </div>
                            {event.registrationDeadline && (
                                <div className="flex items-start gap-4 p-3 bg-red-50 dark:bg-red-900/20 rounded-xl border border-red-100 dark:border-red-900/30">
                                    <AlertCircle className="w-6 h-6 text-red-500 mt-1" />
                                    <div>
                                        <p className="font-semibold text-red-700 dark:text-red-400">Register By</p>
                                        <p className="text-sm text-red-600 dark:text-red-300 mt-1">{formatDate(event.registrationDeadline)}</p>
                                    </div>
                                </div>
                            )}
                        </div>

                        {event.registrationLink ? (
                            <a
                                href={event.registrationLink}
                                target="_blank"
                                rel="noopener noreferrer"
                                className={`block w-full py-4 rounded-xl font-bold text-center text-white shadow-lg transition-transform transform hover:scale-105 bg-${accentColor}-600 hover:bg-${accentColor}-500 flex items-center justify-center gap-2`}
                            >
                                <CheckCircle size={20} /> Register Now
                            </a>
                        ) : (
                            <button disabled className="w-full py-4 rounded-xl font-bold bg-gray-200 dark:bg-gray-700 text-gray-500 cursor-not-allowed">
                                Registration Closed
                            </button>
                        )}

                        <button
                            onClick={handleSave}
                            disabled={saving}
                            className={`w-full mt-3 py-3 rounded-xl font-bold border-2 transition-all flex items-center justify-center gap-2
                                ${isSaved
                                    ? `bg-white dark:bg-gray-800 text-${accentColor}-500 border-${accentColor}-500`
                                    : 'border-gray-200 dark:border-gray-700 hover:border-gray-400 dark:hover:border-gray-600 text-gray-600 dark:text-gray-300'
                                }`}
                        >
                            <Bookmark size={20} fill={isSaved ? "currentColor" : "none"} />
                            {isSaved ? 'Saved to Dashboard' : 'Save Event'}
                        </button>

                        <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center font-bold text-gray-500">
                                    {event.coordinatorName ? event.coordinatorName.charAt(0) : '?'}
                                </div>
                                <div>
                                    <p className="text-sm font-bold text-gray-900 dark:text-white">{event.coordinatorName || 'Event Coordinator'}</p>
                                    <p className="text-xs text-gray-500">{event.coordinatorPhone}</p>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                </div>

            </div>
        </div>
    );
};

export default EventDetails;
