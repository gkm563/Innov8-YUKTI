import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell, Legend } from 'recharts';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../services/firebase';
import Card from '../components/ui/Card';
import SEO from '../components/SEO';

const COLORS = ['#6366f1', '#ec4899', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444'];
const RADIAN = Math.PI / 180;

const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, index }) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
        <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central">
            {`${(percent * 100).toFixed(0)}%`}
        </text>
    );
};

const Insights = () => {
    const [loading, setLoading] = useState(true);
    const [peakHoursData, setPeakHoursData] = useState([]);
    const [categoryData, setCategoryData] = useState([]);
    const [deptData, setDeptData] = useState([]);
    const [trendingTags, setTrendingTags] = useState([]);

    useEffect(() => {
        fetchInsightsData();
    }, []);

    const fetchInsightsData = async () => {
        try {
            const [postsSnap, usersSnap] = await Promise.all([
                getDocs(collection(db, 'posts')),
                getDocs(collection(db, 'users'))
            ]);

            const posts = postsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            const users = usersSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));

            // 1. Peak Activity Hours
            const hoursMap = new Array(24).fill(0);
            posts.forEach(post => {
                if (post.createdAt?.seconds) {
                    const date = new Date(post.createdAt.seconds * 1000);
                    const hour = date.getHours();
                    hoursMap[hour]++;
                }
            });

            // Format for Recharts (every 2 hours for readability)
            const peakData = hoursMap.map((count, hour) => ({
                hour: `${hour % 12 || 12} ${hour < 12 ? 'AM' : 'PM'}`,
                activity: count
            })).filter((_, i) => i % 2 === 0); // Sampling for cleaner chart

            // 2. Content Distribution (Categories)
            const catMap = {};
            posts.forEach(post => {
                const cat = post.category || 'Uncategorized';
                catMap[cat] = (catMap[cat] || 0) + 1;
            });
            const catData = Object.keys(catMap).map(key => ({
                name: key,
                value: catMap[key]
            })).sort((a, b) => b.value - a.value);

            // 3. Dept Contribution
            // Create user->dept map
            const userDeptMap = {};
            users.forEach(u => {
                userDeptMap[u.id] = u.department || 'General';
            });

            const deptMap = {};
            posts.forEach(post => {
                const userId = post.userId || post.uploadedBy?.uid;
                if (userId && userDeptMap[userId]) {
                    const dept = userDeptMap[userId];
                    deptMap[dept] = (deptMap[dept] || 0) + 1;
                }
            });
            const dData = Object.keys(deptMap).map(key => ({
                name: key,
                uploads: deptMap[key]
            })).sort((a, b) => b.uploads - a.uploads).slice(0, 6); // Top 6

            // 4. Trending Tags (Simulated from categories + random words if not enough real tags)
            // Real implementation would look at post.tags array
            const tags = ['Campus', 'Event', 'Fun', 'Study', 'Library', 'Sports'];
            const wordCloud = tags.map((t, i) => ({
                text: t,
                size: ['text-4xl', 'text-3xl', 'text-2xl', 'text-xl'][i % 4],
                color: ['text-primary-500', 'text-secondary-500', 'text-green-500', 'text-rose-500'][i % 4]
            }));

            setPeakHoursData(peakData);
            setCategoryData(catData);
            setDeptData(dData);
            setTrendingTags(wordCloud);

        } catch (error) {
            console.error("Error fetching insights:", error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen pt-24 pb-20 bg-background-light dark:bg-background-dark">
            <SEO title="Campus Insights" description="Data visualization of campus activity, trends, and top contributing departments." />
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-12"
                >
                    <h1 className="text-4xl font-bold text-surface-900 dark:text-white mb-4">
                        Campus <span className="text-primary-600">Insights</span>
                    </h1>
                    <p className="text-surface-600 dark:text-surface-400 max-w-2xl text-lg">
                        Dive into the data behind the memories. See which departments are most active, when the campus comes alive, and what's trending.
                    </p>
                </motion.div>

                {loading ? (
                    <div className="flex h-96 items-center justify-center">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">

                        {/* Chart 1: Peak Activity Hours */}
                        <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 0.1 }}
                            className="col-span-1 lg:col-span-2"
                        >
                            <Card variant="glass" className="p-6 h-full border border-surface-200 dark:border-surface-700 min-h-[400px]">
                                <h3 className="text-lg font-bold text-surface-900 dark:text-white mb-6">Peak Activity Hours</h3>
                                <div className="h-80 w-full">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <AreaChart data={peakHoursData}>
                                            <defs>
                                                <linearGradient id="colorActivity" x1="0" y1="0" x2="0" y2="1">
                                                    <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8} />
                                                    <stop offset="95%" stopColor="#8884d8" stopOpacity={0} />
                                                </linearGradient>
                                            </defs>
                                            <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                                            <XAxis dataKey="hour" tick={{ fill: '#888', fontSize: 12 }} />
                                            <YAxis tick={{ fill: '#888', fontSize: 12 }} />
                                            <Tooltip
                                                contentStyle={{ backgroundColor: '#1f2937', borderColor: '#374151', color: '#f9fafb' }}
                                                itemStyle={{ color: '#fff' }}
                                            />
                                            <Area type="monotone" dataKey="activity" stroke="#8884d8" fillOpacity={1} fill="url(#colorActivity)" />
                                        </AreaChart>
                                    </ResponsiveContainer>
                                </div>
                            </Card>
                        </motion.div>

                        {/* Chart 2: Content Distribution (Pie) */}
                        <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 0.2 }}
                            className="col-span-1"
                        >
                            <Card variant="glass" className="p-6 h-full border border-surface-200 dark:border-surface-700 min-h-[400px]">
                                <h3 className="text-lg font-bold text-surface-900 dark:text-white mb-6">Content Distribution</h3>
                                <div className="h-80 flex items-center justify-center">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <PieChart>
                                            <Pie
                                                data={categoryData}
                                                cx="50%"
                                                cy="50%"
                                                labelLine={false}
                                                label={renderCustomizedLabel}
                                                outerRadius={80}
                                                fill="#8884d8"
                                                dataKey="value"
                                            >
                                                {categoryData.map((entry, index) => (
                                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                                ))}
                                            </Pie>
                                            <Tooltip />
                                            <Legend verticalAlign="bottom" height={36} />
                                        </PieChart>
                                    </ResponsiveContainer>
                                </div>
                            </Card>
                        </motion.div>

                        {/* Chart 3: Dept Uploads */}
                        <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 0.3 }}
                            className="col-span-1 lg:col-span-2"
                        >
                            <Card variant="glass" className="p-6 h-full border border-surface-200 dark:border-surface-700 min-h-[400px]">
                                <h3 className="text-lg font-bold text-surface-900 dark:text-white mb-6">Top Departments</h3>
                                <div className="h-80">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <BarChart data={deptData}>
                                            <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                                            <XAxis dataKey="name" tick={{ fill: '#888' }} />
                                            <YAxis tick={{ fill: '#888' }} />
                                            <Tooltip
                                                cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                                                contentStyle={{ backgroundColor: '#1f2937', borderColor: '#374151', color: '#f9fafb' }}
                                            />
                                            <Bar dataKey="uploads" fill="#6366f1" radius={[4, 4, 0, 0]} />
                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>
                            </Card>
                        </motion.div>

                        {/* Word Cloud / Trending */}
                        <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 0.4 }}
                            className="col-span-1"
                        >
                            <Card variant="glass" className="p-6 h-full border border-surface-200 dark:border-surface-700 flex flex-col min-h-[200px]">
                                <h3 className="text-lg font-bold text-surface-900 dark:text-white mb-6">Trending Tags</h3>
                                <div className="flex-1 flex flex-wrap content-center justify-center gap-4">
                                    {trendingTags.map((tag, i) => (
                                        <span key={i} className={`${tag.size} ${tag.color} font-display font-bold hover:scale-110 transition-transform cursor-pointer`}>
                                            {tag.text}
                                        </span>
                                    ))}
                                </div>
                            </Card>
                        </motion.div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Insights;
