import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Minus, Search, HelpCircle, Shield, File, Image as ImageIcon, Cpu } from 'lucide-react';
import Card from '../components/ui/Card';
import SEO from '../components/SEO';

const FAQ = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [activeIndex, setActiveIndex] = useState(null);

    const faqs = [
        {
            question: "What is the maximum file size for uploads?",
            answer: "You can upload images up to 5MB in size. We recommend compressing extremely high-resolution images for faster loading, but our system handles standard high-quality photos easily.",
            icon: File
        },
        {
            question: "How is my privacy protected?",
            answer: "Your privacy is our top priority. We use strict database rules to ensure only authorized users can manage content. Your personal data is encrypted, and we never share your information with third parties without consent.",
            icon: Shield
        },
        {
            question: "Can I delete a photo after uploading?",
            answer: "Yes! If you are the owner of the photo (or an admin), you can delete it at any time. Simply open the photo in the gallery, click the 'Delete' icon, and confirm your action.",
            icon: ImageIcon
        },
        {
            question: "How does the AI tagging work?",
            answer: "Our intelligent AI analyzes your uploaded photos to automatically detect scenes, objects, and events (like 'Crowd', 'Stage', 'Sports'). This helps in organizing the gallery and makes searching for specific memories effortless.",
            icon: Cpu
        },
        {
            question: "Who can view the photos?",
            answer: "By default, the gallery is viewable by all registered students and faculty. Some specific albums might be private to certain departments or clubs, depending on the uploader's settings.",
            icon: HelpCircle
        },
        {
            question: "How do I report inappropriate content?",
            answer: "If you see something that violates our community guidelines, please contact the admin team via the 'Contact Us' page or use the 'Report' button on the specific image.",
            icon: Shield
        }
    ];

    const filteredFaqs = faqs.filter(faq =>
        faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
        faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const toggleAccordion = (index) => {
        setActiveIndex(activeIndex === index ? null : index);
    };

    return (
        <div className="min-h-screen pt-24 pb-20 bg-background-light dark:bg-background-dark">
            <SEO title="FAQ / Help Center" description="Common questions about CampusClick, privacy, uploads, and more." />
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">

                <div className="text-center mb-16">
                    <motion.h1
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-4xl md:text-5xl font-bold mb-6 font-display text-surface-900 dark:text-white"
                    >
                        Frequently Asked <span className="text-primary-600">Questions</span>
                    </motion.h1>
                    <motion.p
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="text-lg text-surface-600 dark:text-surface-300 mb-8"
                    >
                        Everything you need to know about CampusClick.
                    </motion.p>

                    {/* Search Bar */}
                    <div className="relative max-w-xl mx-auto">
                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <Search className="h-5 w-5 text-surface-400" />
                        </div>
                        <input
                            type="text"
                            placeholder="Search for answers..."
                            className="block w-full pl-12 pr-4 py-4 bg-white dark:bg-surface-800 border border-surface-200 dark:border-surface-700 rounded-2xl shadow-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all outline-none text-surface-900 dark:text-white"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                </div>

                <div className="space-y-4">
                    <AnimatePresence>
                        {filteredFaqs.length > 0 ? (
                            filteredFaqs.map((faq, index) => (
                                <motion.div
                                    key={index}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, height: 0 }}
                                    transition={{ delay: index * 0.05 }}
                                >
                                    <div
                                        className={`bg-white dark:bg-surface-800 rounded-2xl border transition-all duration-300 overflow-hidden ${activeIndex === index
                                            ? 'border-primary-500 shadow-md ring-1 ring-primary-500/20'
                                            : 'border-surface-200 dark:border-surface-700 hover:border-primary-300 dark:hover:border-primary-700'}`}
                                    >
                                        <button
                                            onClick={() => toggleAccordion(index)}
                                            className="w-full px-6 py-5 flex items-center justify-between text-left focus:outline-none"
                                        >
                                            <div className="flex items-center gap-4">
                                                <div className={`p-2 rounded-lg ${activeIndex === index ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400' : 'bg-surface-100 dark:bg-surface-700 text-surface-500 dark:text-surface-400'}`}>
                                                    <faq.icon size={20} />
                                                </div>
                                                <span className={`font-bold text-lg ${activeIndex === index ? 'text-primary-700 dark:text-primary-400' : 'text-surface-900 dark:text-white'}`}>
                                                    {faq.question}
                                                </span>
                                            </div>
                                            <div className={`transition-transform duration-300 ${activeIndex === index ? 'rotate-180' : ''} text-surface-400`}>
                                                {activeIndex === index ? <Minus size={20} /> : <Plus size={20} />}
                                            </div>
                                        </button>

                                        <AnimatePresence>
                                            {activeIndex === index && (
                                                <motion.div
                                                    initial={{ height: 0, opacity: 0 }}
                                                    animate={{ height: "auto", opacity: 1 }}
                                                    exit={{ height: 0, opacity: 0 }}
                                                    transition={{ duration: 0.3, ease: "easeInOut" }}
                                                >
                                                    <div className="px-6 pb-6 pl-20 text-surface-600 dark:text-surface-300 leading-relaxed">
                                                        {faq.answer}
                                                    </div>
                                                </motion.div>
                                            )}
                                        </AnimatePresence>
                                    </div>
                                </motion.div>
                            ))
                        ) : (
                            <div className="text-center py-12">
                                <p className="text-surface-500 dark:text-surface-400">No matching answers found.</p>
                            </div>
                        )}
                    </AnimatePresence>
                </div>

                {/* Contact Support CTA */}
                <div className="mt-16 text-center">
                    <p className="text-surface-600 dark:text-surface-400 mb-4">Still have questions?</p>
                    <a href="/contact" className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-xl text-white bg-primary-600 hover:bg-primary-700 transition-colors shadow-lg shadow-primary-500/25">
                        Contact Support
                    </a>
                </div>

            </div>
        </div>
    );
};

export default FAQ;
