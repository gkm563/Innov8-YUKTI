import React, { useEffect, useState } from 'react';
import { collection, getDocs, deleteDoc, doc, query, orderBy } from 'firebase/firestore';
import { db } from '../../services/firebase';
import { getEvents, deleteEvent } from '../../services/eventService';
import { motion, AnimatePresence } from 'framer-motion';
import { Trash2, Users, Image as ImageIcon, Eye, AlertTriangle, Calendar, Plus, MapPin, LayoutDashboard, Shield, LogOut, Menu, X, Check, Database, Edit } from 'lucide-react';
import { toast } from 'react-toastify';
import { useNavigate, useLocation } from 'react-router-dom';
import AdminEventModal from '../../components/AdminEventModal';
import ImageModal from '../../components/ImageModal';
import { seedDatabase } from '../../services/seedEvents';
import { useTheme } from '../../context/ThemeContext';
import AdminLayout from '../../components/Layout/AdminLayout';
import Button from '../../components/ui/Button';
import Card from '../../components/ui/Card';

const AdminDashboard = () => {
    const [stats, setStats] = useState({ photos: 0, users: 0, views: 0, events: 0 });
    const [posts, setPosts] = useState([]);
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeSection, setActiveSection] = useState('memories');
    const [isEventModalOpen, setIsEventModalOpen] = useState(false);
    const [eventToEdit, setEventToEdit] = useState(null);
    const [selectedPost, setSelectedPost] = useState(null);
    const [isImageModalOpen, setIsImageModalOpen] = useState(false);
    const { theme } = useTheme();
    const navigate = useNavigate();
    const location = useLocation();

    const [filter, setFilter] = useState('all'); // all, today, week, month

    // Sync activeSection with URL
    useEffect(() => {
        const params = new URLSearchParams(location.search);
        const section = params.get('section');
        if (section === 'events') setActiveSection('events');
        else setActiveSection('memories');
    }, [location.search]);

    const fetchAllData = async () => {
        setLoading(true);
        try {
            // 1. Fetch Posts
            const postsSnap = await getDocs(query(collection(db, 'posts'), orderBy('timestamp', 'desc')));
            let fetchedPosts = postsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));

            // 2. Fetch Events
            const fetchedEvents = await getEvents();
            setEvents(fetchedEvents);

            // 3. Stats (Calculate before filtering)
            const uniqueUsers = new Set(fetchedPosts.map(p => p.uploadedBy?.uid || p.usersName)).size;
            const totalViews = fetchedPosts.reduce((acc, curr) => acc + (curr.views || 0), 0);

            setStats({
                photos: fetchedPosts.length,
                users: uniqueUsers,
                views: totalViews,
                events: fetchedEvents.length
            });

            // 4. Apply Filter to Posts
            const now = new Date();
            const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            const weekStart = new Date(now.setDate(now.getDate() - 7));
            const monthStart = new Date(new Date().setMonth(new Date().getMonth() - 1));

            fetchedPosts = fetchedPosts.filter(post => {
                if (filter === 'all') return true;
                if (!post.timestamp) return false;

                const postDate = post.timestamp.toDate();

                if (filter === 'today') return postDate >= todayStart;
                if (filter === 'week') return postDate >= weekStart;
                if (filter === 'month') return postDate >= monthStart;
                return true;
            });

            setPosts(fetchedPosts);

        } catch (error) {
            console.error("Admin fetch error:", error);
            toast.error("Failed to load admin data.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchAllData();
    }, [filter]);

    const handleDeletePost = async (id) => {
        if (window.confirm("ADMIN ALERT: Delete this memory permanently?")) {
            try {
                await deleteDoc(doc(db, 'posts', id));
                setPosts(posts.filter(p => p.id !== id));
                setStats(prev => ({ ...prev, photos: prev.photos - 1 }));
                toast.success("Memory removed.");
            } catch (error) {
                toast.error("Failed to delete memory.");
            }
        }
    };

    const handleDeleteEvent = async (id) => {
        if (window.confirm("ADMIN ALERT: Delete this event?")) {
            try {
                await deleteEvent(id);
                setEvents(events.filter(e => e.id !== id));
                setStats(prev => ({ ...prev, events: prev.events - 1 }));
                toast.success("Event removed.");
            } catch (error) {
                toast.error("Failed to delete event.");
            }
        }
    };

    const handleEditEvent = (event) => {
        setEventToEdit(event);
        setIsEventModalOpen(true);
    };

    const handleSeedData = async () => {
        await seedDatabase();
        fetchAllData();
    };

    const openImageModal = (post) => {
        setSelectedPost(post);
        setIsImageModalOpen(true);
    };

    if (loading && !posts.length && !events.length) return (
        <div className="min-h-screen pt-24 flex items-center justify-center bg-background-light dark:bg-background-dark">
            <div className="text-primary-500 font-bold animate-pulse">Loading Command Center...</div>
        </div>
    );

    return (
        <AdminLayout>
            <div className="max-w-7xl mx-auto space-y-8">

                {/* Top Stats Row */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div>
                        <h1 className="text-3xl font-bold font-display text-surface-900 dark:text-white flex items-center gap-3">
                            Dashboard <span className="p-1.5 bg-success/20 text-success rounded-full" title="Super Admin"><Check size={16} strokeWidth={4} /></span>
                        </h1>
                        <p className="text-surface-500 dark:text-surface-400 mt-1">Overview of system health and content.</p>
                    </div>

                    <div className="flex gap-4">
                        <Card className="px-5 py-2.5 flex items-center gap-3 !rounded-xl border-surface-200 dark:border-surface-700">
                            <div className="w-2.5 h-2.5 rounded-full bg-success animate-pulse"></div>
                            <span className="text-xs font-bold text-surface-600 dark:text-surface-300 uppercase tracking-wider">System Normal</span>
                        </Card>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <StatCard icon={<ImageIcon className="text-primary-500" />} label="Memories" value={stats.photos} trend="+12%" />
                    <StatCard icon={<Calendar className="text-warning" />} label="Events" value={stats.events} trend="Active" />
                    <StatCard icon={<Users className="text-success" />} label="Contributors" value={stats.users} trend="+5" />
                    <StatCard icon={<Eye className="text-info" />} label="Total Views" value={stats.views} trend="+1.2k" />
                </div>

                {/* Main Content Area */}
                <Card className="border-surface-200 dark:border-surface-700 bg-white/50 dark:bg-surface-800/50 backdrop-blur-xl">
                    <div className="p-6 border-b border-surface-100 dark:border-surface-700 flex flex-col sm:flex-row justify-between items-center gap-4">
                        <div className="flex items-center gap-4">
                            <h3 className="text-xl font-bold text-surface-900 dark:text-white">
                                {activeSection === 'memories' ? 'Recent Memory Uploads' : 'Event Coordination'}
                            </h3>
                        </div>

                        <div className="flex items-center gap-3">
                            {activeSection === 'memories' && (
                                <select
                                    value={filter}
                                    onChange={(e) => setFilter(e.target.value)}
                                    className="bg-surface-50 dark:bg-surface-900 border border-surface-200 dark:border-surface-700 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 text-surface-700 dark:text-surface-200"
                                >
                                    <option value="all">All Time</option>
                                    <option value="today">Today</option>
                                    <option value="week">This Week</option>
                                    <option value="month">This Month</option>
                                </select>
                            )}

                            {activeSection === 'events' && (
                                <>
                                    <Button
                                        onClick={() => navigate('/admin/users')}
                                        variant="outline"
                                        size="sm"
                                        icon={<Users size={14} />}
                                    >
                                        Users
                                    </Button>
                                    <Button
                                        onClick={handleSeedData}
                                        variant="outline"
                                        size="sm"
                                        icon={<Database size={14} />}
                                    >
                                        Seed Data
                                    </Button>
                                    <Button
                                        onClick={() => { setEventToEdit(null); setIsEventModalOpen(true); }}
                                        size="sm"
                                        icon={<Plus size={16} />}
                                    >
                                        Add Event
                                    </Button>
                                </>
                            )}
                        </div>
                    </div>

                    <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <thead className="bg-surface-50 dark:bg-surface-900/50 text-surface-500 dark:text-surface-400 text-xs uppercase tracking-wider">
                                <tr>
                                    {activeSection === 'memories' ? (
                                        <>
                                            <th className="px-6 py-4 font-semibold">Asset</th>
                                            <th className="px-6 py-4 font-semibold">Context</th>
                                            <th className="px-6 py-4 font-semibold">Contributor</th>
                                            <th className="px-6 py-4 font-semibold">Status</th>
                                        </>
                                    ) : (
                                        <>
                                            <th className="px-6 py-4 font-semibold">Event Details</th>
                                            <th className="px-6 py-4 font-semibold">Category</th>
                                            <th className="px-6 py-4 font-semibold">Logistics</th>
                                            <th className="px-6 py-4 font-semibold">Status</th>
                                        </>
                                    )}
                                    <th className="px-6 py-4 text-right font-semibold">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-surface-100 dark:divide-surface-700/50">
                                {activeSection === 'memories' ? (
                                    posts.map(post => (
                                        <tr key={post.id} className="hover:bg-surface-50 dark:hover:bg-surface-700/30 transition-colors group">
                                            <td className="px-6 py-4">
                                                <div
                                                    className="w-16 h-12 rounded-lg bg-surface-200 dark:bg-surface-700 overflow-hidden relative cursor-pointer ring-2 ring-transparent group-hover:ring-primary-500 transition-all shadow-sm"
                                                    onClick={() => openImageModal(post)}
                                                >
                                                    <img src={post.imageUrl} alt="" className="w-full h-full object-cover" />
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 max-w-xs">
                                                <p className="text-sm font-semibold text-surface-900 dark:text-surface-100 line-clamp-1">{post.caption}</p>
                                                <p className="text-xs text-surface-500">{post.category}</p>
                                            </td>
                                            <td className="px-6 py-4">
                                                <div className="flex items-center gap-2">
                                                    <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-primary-500 to-secondary-500 flex items-center justify-center text-[10px] text-white font-bold">
                                                        {post.uploadedBy?.displayName?.[0] || 'U'}
                                                    </div>
                                                    <span className="text-sm text-surface-700 dark:text-surface-300">{post.uploadedBy?.displayName || 'Unknown'}</span>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4">
                                                <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-success/10 text-success border border-success/20">Verified</span>
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                                <button onClick={() => handleDeletePost(post.id)} className="p-2 text-surface-400 hover:text-error hover:bg-error/10 rounded-lg transition-all">
                                                    <Trash2 size={18} />
                                                </button>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    events.map(event => (
                                        <tr key={event.id} className="hover:bg-surface-50 dark:hover:bg-surface-700/30 transition-colors">
                                            <td className="px-6 py-4">
                                                <div className="flex items-center gap-4">
                                                    <div className="w-12 h-12 rounded-lg bg-surface-200 dark:bg-surface-700 overflow-hidden shadow-sm">
                                                        {event.bannerUrl ? <img src={event.bannerUrl} alt="" className="w-full h-full object-cover" /> : <div className="w-full h-full bg-gradient-to-br from-gray-200 to-gray-300" />}
                                                    </div>
                                                    <div>
                                                        <span className="font-bold text-sm text-surface-900 dark:text-white block">{event.title}</span>
                                                        <span className="text-xs text-surface-500 font-mono">{event.id.substring(0, 6)}...</span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4">
                                                <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase border ${event.type === 'tech' ? 'bg-info/10 text-info border-info/20' : 'bg-primary-500/10 text-primary-600 dark:text-primary-400 border-primary-500/20'}`}>
                                                    {event.type}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4">
                                                <div className="text-sm text-surface-600 dark:text-surface-300 space-y-1">
                                                    <div className="flex items-center gap-1.5"><Calendar size={13} className="text-surface-400" /> {new Date(event.startDate?.toDate ? event.startDate.toDate() : event.startDate).toLocaleDateString()}</div>
                                                    <div className="flex items-center gap-1.5 text-xs text-surface-500"><MapPin size={13} className="text-surface-400" /> {event.venue || 'TBA'}</div>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4">
                                                <span className={`px-2.5 py-1 rounded-full text-xs font-bold inline-flex items-center gap-1 ${event.status === 'Ongoing' ? 'bg-success/10 text-success animate-pulse' :
                                                    event.status === 'Upcoming' ? 'bg-info/10 text-info' :
                                                        'bg-surface-100 text-surface-500 dark:bg-surface-700 dark:text-surface-400'
                                                    }`}>
                                                    {event.status === 'Ongoing' && <span className="w-1.5 h-1.5 rounded-full bg-success"></span>}
                                                    {event.status}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                                <div className="flex justify-end gap-2">
                                                    <button onClick={() => handleEditEvent(event)} className="p-2 text-info hover:bg-info/10 rounded-lg transition-colors">
                                                        <Edit size={18} />
                                                    </button>
                                                    <button onClick={() => handleDeleteEvent(event.id)} className="p-2 text-surface-400 hover:text-error hover:bg-error/10 rounded-lg transition-colors">
                                                        <Trash2 size={18} />
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))
                                )}

                                {activeSection === 'events' && events.length === 0 && (
                                    <tr><td colSpan="5" className="text-center py-16 text-surface-500">No events scheduled. Create one to get started!</td></tr>
                                )}
                                {activeSection === 'memories' && posts.length === 0 && (
                                    <tr><td colSpan="5" className="text-center py-16 text-surface-500">No memories found for this filter.</td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </Card>

                <AdminEventModal
                    isOpen={isEventModalOpen}
                    onClose={() => { setIsEventModalOpen(false); setEventToEdit(null); }}
                    onEventAdded={fetchAllData}
                    eventToEdit={eventToEdit}
                />

                <ImageModal
                    isOpen={isImageModalOpen}
                    onClose={() => setIsImageModalOpen(false)}
                    post={selectedPost}
                    onUpdate={fetchAllData}
                />
            </div>
        </AdminLayout>
    );
};

const StatCard = ({ icon, label, value, trend }) => (
    <Card className="p-6 border-surface-200 dark:border-surface-700 flex items-center gap-5 hover:border-primary-500/30 transition-colors">
        <div className="p-3.5 bg-surface-50 dark:bg-surface-800 rounded-xl shadow-inner">
            {React.cloneElement(icon, { size: 24 })}
        </div>
        <div>
            <p className="text-surface-500 dark:text-surface-400 text-xs font-bold uppercase tracking-wide mb-0.5">{label}</p>
            <div className="flex items-end gap-2">
                <p className="text-2xl font-black text-surface-900 dark:text-white leading-none">{value}</p>
                {trend && <span className="text-[10px] font-bold text-success bg-success/10 px-1.5 py-0.5 rounded-full mb-0.5">{trend}</span>}
            </div>
        </div>
    </Card>
);

export default AdminDashboard;
