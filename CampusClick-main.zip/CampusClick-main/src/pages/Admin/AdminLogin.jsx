import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Shield, Lock, Loader2 } from 'lucide-react';
import { toast } from 'react-toastify';
import { useAuth } from '../../context/AuthContext';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../services/firebase';

const AdminLogin = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();
    const { login, signup } = useAuth();

    const handleLogin = async (e) => {
        e.preventDefault();
        setLoading(true);

        try {
            // Special Bootstrap for "Demo Admin"
            if (email === 'admin@campusclick.com' && password === 'admin123') {
                try {
                    await login(email, password);
                } catch (error) {
                    if (error.code === 'auth/user-not-found' || error.code === 'auth/invalid-credential') {
                        // Create the admin user if it doesn't exist (Demo purposes)
                        const userCred = await signup(email, password);
                        // Force Admin Role
                        await setDoc(doc(db, 'users', userCred.user.uid), {
                            uid: userCred.user.uid,
                            email: email,
                            displayName: 'System Administrator',
                            role: 'admin',
                            createdAt: serverTimestamp(),
                            lastLogin: serverTimestamp()
                        });
                        toast.success("Admin Account Created & Logged In");
                    } else {
                        throw error;
                    }
                }
            } else {
                // Normal Admin Login
                await login(email, password);
                // AuthContext handles the role check via redirect if not admin
            }

            // Check if actually admin happens in RequireAdmin, but we can hint here
            // We'll let the router handle the redirect logic
            toast.success("Welcome, Administrator.");
            navigate('/admin/dashboard', { replace: true });

        } catch (error) {
            console.error(error);
            toast.error("Access Denied: " + error.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen pt-20 flex items-center justify-center bg-background-light dark:bg-background-dark px-4">
            <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white dark:bg-surface-900 p-8 rounded-2xl shadow-2xl w-full max-w-md border border-surface-200 dark:border-surface-700 text-center"
            >
                <div className="w-16 h-16 bg-red-50 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Shield className="w-8 h-8 text-red-600 dark:text-red-500" />
                </div>

                <h1 className="text-2xl font-bold font-display text-surface-900 dark:text-white mb-2">Admin Portal</h1>
                <p className="text-surface-500 dark:text-surface-400 mb-8">Restricted Access only.</p>

                <form onSubmit={handleLogin} className="space-y-4">
                    <div className="relative text-left">
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full px-4 py-3 rounded-xl border border-surface-200 dark:border-surface-700 bg-surface-50 dark:bg-surface-800 text-surface-900 dark:text-white focus:ring-2 focus:ring-red-500 outline-none placeholder-surface-400"
                            placeholder="Admin Email"
                        />
                    </div>
                    <div className="relative text-left">
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full px-4 py-3 rounded-xl border border-surface-200 dark:border-surface-700 bg-surface-50 dark:bg-surface-800 text-surface-900 dark:text-white focus:ring-2 focus:ring-red-500 outline-none placeholder-surface-400"
                            placeholder="Password"
                        />
                    </div>
                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full py-3 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 transition-colors shadow-lg shadow-red-500/25 flex items-center justify-center gap-2"
                    >
                        {loading && <Loader2 className="animate-spin w-5 h-5" />}
                        {loading ? 'Authenticating...' : 'Access Dashboard'}
                    </button>
                </form>
            </motion.div>
        </div>
    );
};

export default AdminLogin;
