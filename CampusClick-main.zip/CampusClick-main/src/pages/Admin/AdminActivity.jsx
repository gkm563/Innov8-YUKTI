import React, { useEffect, useState } from 'react';
import { getAllActivities } from '../../services/activityService';
import { collection, getDocs, query, orderBy, limit } from 'firebase/firestore';
import { db } from '../../services/firebase';
import AdminLayout from '../../components/Layout/AdminLayout';
import Card from '../../components/ui/Card';
import { Activity, Search, Filter, Clock, CheckCircle, XCircle, User, Shield, AlertTriangle } from 'lucide-react';

const AdminActivity = () => {
    const [activities, setActivities] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState('ALL'); // ALL, LOGIN, UPLOAD, DELETE
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        const fetchActivities = async () => {
            setLoading(true);
            const data = await getAllActivities(100); // Fetch last 100
            setActivities(data);
            setLoading(false);
        };
        fetchActivities();
    }, []);

    const filteredActivities = activities.filter(act => {
        const matchesType = filter === 'ALL' || act.action === filter;
        const matchesSearch =
            (act.userName?.toLowerCase().includes(searchTerm.toLowerCase())) ||
            (act.details?.toLowerCase().includes(searchTerm.toLowerCase())) ||
            (act.userId?.includes(searchTerm));
        return matchesType && matchesSearch;
    });

    const getActionIcon = (action) => {
        switch (action) {
            case 'LOGIN': return <CheckCircle className="text-green-500" size={18} />;
            case 'LOGOUT': return <CheckCircle className="text-gray-400" size={18} />;
            case 'UPLOAD': return <Activity className="text-blue-500" size={18} />;
            case 'DELETE': return <XCircle className="text-red-500" size={18} />;
            case 'SIGNUP': return <User className="text-purple-500" size={18} />; // Handled 'New User' case
            default: return <Activity className="text-gray-500" size={18} />;
        }
    };

    const getActionColor = (action) => {
        switch (action) {
            case 'LOGIN': return 'bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-400 border-green-200 dark:border-green-800';
            case 'LOGOUT': return 'bg-gray-50 text-gray-600 dark:bg-gray-800 dark:text-gray-400 border-gray-200 dark:border-gray-700';
            case 'UPLOAD': return 'bg-blue-50 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400 border-blue-200 dark:border-blue-800';
            case 'DELETE': return 'bg-red-50 text-red-700 dark:bg-red-900/20 dark:text-red-400 border-red-200 dark:border-red-800';
            case 'SIGNUP': return 'bg-purple-50 text-purple-700 dark:bg-purple-900/20 dark:text-purple-400 border-purple-200 dark:border-purple-800';
            default: return 'bg-gray-50 text-gray-600 dark:bg-gray-800 dark:text-gray-400';
        }
    };

    return (
        <AdminLayout>
            <div className="max-w-7xl mx-auto space-y-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div>
                        <h1 className="text-2xl font-bold text-surface-900 dark:text-white flex items-center gap-2">
                            <Shield className="text-primary-500" /> Activity Log
                        </h1>
                        <p className="text-surface-500 dark:text-surface-400 text-sm">Monitor user actions and system events.</p>
                    </div>
                </div>

                <Card className="border-surface-200 dark:border-surface-700">
                    {/* Toolbar */}
                    <div className="p-4 border-b border-surface-200 dark:border-surface-700 flex flex-col sm:flex-row gap-4 justify-between bg-surface-50/50 dark:bg-surface-800/20">
                        <div className="flex items-center gap-2 bg-white dark:bg-surface-800 px-3 py-2 rounded-lg border border-surface-200 dark:border-surface-700 w-full sm:w-auto">
                            <Search size={16} className="text-surface-400" />
                            <input
                                type="text"
                                placeholder="Search user, action..."
                                className="bg-transparent outline-none text-sm text-surface-900 dark:text-white placeholder-surface-400 w-full"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                        <div className="flex gap-2 overflow-x-auto pb-1 sm:pb-0">
                            {['ALL', 'LOGIN', 'UPLOAD', 'DELETE'].map(type => (
                                <button
                                    key={type}
                                    onClick={() => setFilter(type)}
                                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors whitespace-nowrap
                                        ${filter === type
                                            ? 'bg-primary-600 text-white shadow-lg shadow-primary-500/20'
                                            : 'bg-white dark:bg-surface-800 text-surface-600 dark:text-surface-300 border border-surface-200 dark:border-surface-700 hover:bg-surface-100 dark:hover:bg-surface-700'}
                                    `}
                                >
                                    {type}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Table / List */}
                    <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <thead className="bg-surface-50 dark:bg-surface-800/50 text-xs text-surface-500 uppercase font-semibold border-b border-surface-200 dark:border-surface-700">
                                <tr>
                                    <th className="px-6 py-4">User</th>
                                    <th className="px-6 py-4">Action</th>
                                    <th className="px-6 py-4">Details</th>
                                    <th className="px-6 py-4 text-right">Time</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-surface-100 dark:divide-surface-700/50">
                                {loading ? (
                                    <tr>
                                        <td colSpan="4" className="text-center py-12 text-surface-500">
                                            Loading logs...
                                        </td>
                                    </tr>
                                ) : filteredActivities.length > 0 ? (
                                    filteredActivities.map((act) => (
                                        <tr key={act.id} className="hover:bg-surface-50 dark:hover:bg-surface-800/30 transition-colors">
                                            <td className="px-6 py-4">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-primary-500 to-secondary-500 flex items-center justify-center text-white text-xs font-bold shadow-sm">
                                                        {act.userName?.[0]?.toUpperCase() || 'U'}
                                                    </div>
                                                    <div>
                                                        <p className="text-sm font-semibold text-surface-900 dark:text-white">{act.userName}</p>
                                                        <p className="text-xs text-surface-500 font-mono tracking-tight">{act.userId?.slice(0, 8)}...</p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4">
                                                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold border ${getActionColor(act.action)}`}>
                                                    {getActionIcon(act.action)}
                                                    {act.action}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4">
                                                <p className="text-sm text-surface-600 dark:text-surface-300 max-w-sm truncate">{act.details}</p>
                                                {/* Optional: Show metadata link if relevant (e.g. view photo) */}
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                                <div className="flex items-center justify-end gap-1.5 text-xs text-surface-500">
                                                    <Clock size={12} />
                                                    {act.timestamp?.toDate ? act.timestamp.toDate().toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Just now'}
                                                </div>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="4" className="text-center py-12 text-surface-500">
                                            No activity found matching filters.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </Card>
            </div>
        </AdminLayout>
    );
};

export default AdminActivity;
