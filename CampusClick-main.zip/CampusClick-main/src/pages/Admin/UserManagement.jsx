import React, { useEffect, useState } from 'react';
import { collection, getDocs, updateDoc, deleteDoc, doc, query, orderBy } from 'firebase/firestore';
import { db } from '../../services/firebase';
import { toast } from 'react-toastify';
import { motion } from 'framer-motion';
import { Trash2, Ban, CheckCircle, Shield, Search, User, UserX, Eye } from 'lucide-react';
import Button from '../../components/ui/Button';
import Card from '../../components/ui/Card';
import UserDetailsModal from '../../components/UserDetailsModal';
import AdminLayout from '../../components/Layout/AdminLayout';

const UserManagement = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedUser, setSelectedUser] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);

    useEffect(() => {
        fetchUsers();
    }, []);

    const fetchUsers = async () => {
        try {
            const q = query(collection(db, 'users')); // Removed orderBy to ensure all users are fetched (legacy docs might miss createdAt)
            const snapshot = await getDocs(q);
            const userData = snapshot.docs
                .map(doc => ({ id: doc.id, ...doc.data() }))
                .filter(user => user.role !== 'admin') // Hide System Administrator
                .sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0)); // Client-side sort
            setUsers(userData);
        } catch (error) {
            console.error("Error fetching users:", error);
            // toast.error("Failed to load users.");
        } finally {
            setLoading(false);
        }
    };

    const toggleBlockUser = async (user) => {
        if (!window.confirm(`Are you sure you want to ${user.isBlocked ? 'unblock' : 'block'} ${user.displayName}?`)) return;

        try {
            await updateDoc(doc(db, 'users', user.id), {
                isBlocked: !user.isBlocked
            });
            toast.success(`User ${user.isBlocked ? 'unblocked' : 'blocked'} successfully.`);
            fetchUsers(); // Refresh
        } catch (error) {
            console.error("Error updating user:", error);
            toast.error("Failed to update user status.");
        }
    };

    const handleDeleteUser = async (userId) => {
        if (!window.confirm("Are you sure? This action cannot be undone and will delete the user's data record.")) return;

        try {
            await deleteDoc(doc(db, 'users', userId));
            toast.success("User deleted.");
            setUsers(users.filter(u => u.id !== userId));
        } catch (error) {
            console.error("Error deleting user:", error);
            toast.error("Error deleting user.");
        }
    };

    const filteredUsers = users.filter(u =>
        u.displayName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        u.email?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <AdminLayout>
            <div className="max-w-7xl mx-auto space-y-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div>
                        <h1 className="text-3xl font-bold font-display text-surface-900 dark:text-white flex items-center gap-3">
                            <User className="text-primary-500" />
                            User Management
                        </h1>
                        <p className="text-surface-600 dark:text-surface-400 mt-2">Manage user access and roles.</p>
                    </div>

                    <div className="relative w-full md:w-96">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-400" size={20} />
                        <input
                            type="text"
                            placeholder="Search users..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full pl-10 pr-4 py-2 rounded-xl bg-white dark:bg-surface-800 border border-surface-200 dark:border-surface-700 focus:ring-2 focus:ring-primary-500 outline-none"
                        />
                    </div>
                </div>

                {loading ? (
                    <div className="text-center py-12 text-surface-500">Loading users...</div>
                ) : (
                    <div className="grid gap-4">
                        {filteredUsers.map(user => (
                            <Card key={user.id} className="p-4 flex flex-col md:flex-row items-center justify-between gap-4">
                                <div className="flex items-center gap-4 w-full md:w-auto">
                                    <img
                                        src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName || 'User'}&background=random`}
                                        alt={user.displayName}
                                        className="w-12 h-12 rounded-full object-cover ring-2 ring-surface-100 dark:ring-surface-700"
                                    />
                                    <div>
                                        <h3 className="font-bold text-surface-900 dark:text-white flex items-center gap-2">
                                            {user.displayName || 'Anonymous User'}
                                            {user.role === 'admin' && <Shield size={14} className="text-red-500" title="Admin" />}
                                        </h3>
                                        <p className="text-sm text-surface-500">{user.email}</p>
                                        <div className="flex gap-2 mt-1 text-xs">
                                            <span className={`px-2 py-0.5 rounded-full ${user.isBlocked ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                                                {user.isBlocked ? 'Blocked' : 'Active'}
                                            </span>
                                            <span className="text-surface-400">UID: {user.uid?.slice(0, 8)}...</span>
                                        </div>
                                    </div>
                                </div>

                                <div className="flex items-center gap-2 w-full md:w-auto justify-end">
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => { setSelectedUser(user); setIsModalOpen(true); }}
                                        className="text-primary-600 border-primary-200 hover:bg-primary-50"
                                        title="View Uploads & Details"
                                    >
                                        <Eye size={18} />
                                        <span className="ml-2">View Uploads</span>
                                    </Button>

                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => toggleBlockUser(user)}
                                        className={`${user.isBlocked ? 'text-green-600 hover:bg-green-50' : 'text-orange-500 hover:bg-orange-50'}`}
                                        title={user.isBlocked ? "Unblock User" : "Block User"}
                                    >
                                        {user.isBlocked ? <CheckCircle size={18} /> : <Ban size={18} />}
                                    </Button>

                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => handleDeleteUser(user.id)}
                                        className="text-error hover:bg-error/10"
                                        title="Delete User"
                                    >
                                        <Trash2 size={18} />
                                    </Button>
                                </div>
                            </Card>
                        ))}

                        {filteredUsers.length === 0 && (
                            <div className="text-center py-12 text-surface-500 bg-surface-50 dark:bg-surface-800/50 rounded-2xl border border-dashed border-surface-200 dark:border-surface-700">
                                <UserX size={48} className="mx-auto mb-4 opacity-50" />
                                <p>No users found matching "{searchTerm}"</p>
                            </div>
                        )}
                    </div>
                )}

                <UserDetailsModal
                    isOpen={isModalOpen}
                    onClose={() => { setIsModalOpen(false); setSelectedUser(null); }}
                    user={selectedUser}
                    onUserUpdated={fetchUsers}
                />
            </div>
        </AdminLayout>
    );
};

export default UserManagement;
