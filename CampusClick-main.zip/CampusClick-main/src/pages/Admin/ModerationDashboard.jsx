import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db, storage } from '../../services/firebase';
import { ref, deleteObject } from 'firebase/storage';
import { toast } from 'react-toastify';
import { Check, X, AlertTriangle, Shield, Calendar, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import AdminLayout from '../../components/Layout/AdminLayout';
import Button from '../../components/ui/Button';
import Card from '../../components/ui/Card';

const ModerationDashboard = () => {
    const [pendingPosts, setPendingPosts] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const q = query(collection(db, 'posts'), where('status', '==', 'pending_review'));

        const unsubscribe = onSnapshot(q, (snapshot) => {
            const posts = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            }));
            setPendingPosts(posts);
            setLoading(false);
        }, (error) => {
            console.error("Error fetching pending posts:", error);
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    const handleApprove = async (postId) => {
        try {
            await updateDoc(doc(db, 'posts', postId), {
                status: 'approved',
                moderatedAt: new Date()
            });
            toast.success("Post approved and published!");
        } catch (error) {
            console.error("Approval error:", error);
            toast.error("Failed to approve post.");
        }
    };

    const handleReject = async (post) => {
        if (!window.confirm("Are you sure you want to permanently delete this post?")) return;

        try {
            // 1. Delete from Firestore
            await deleteDoc(doc(db, 'posts', post.id));

            // 2. Delete Image from Storage
            try {
                const imageRef = ref(storage, post.imageUrl);
                await deleteObject(imageRef);
            } catch (storageError) {
                console.warn("Could not delete file from storage:", storageError);
            }

            toast.success("Post rejected and deleted.");
        } catch (error) {
            console.error("Rejection error:", error);
            toast.error("Failed to reject post.");
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-[400px]">
                <Loader2 className="animate-spin h-10 w-10 text-primary-500" />
            </div>
        );
    }

    return (
        <AdminLayout>
            <div className="max-w-7xl mx-auto space-y-8">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div>
                        <h1 className="text-3xl font-bold font-display text-surface-900 dark:text-white flex items-center gap-3">
                            Moderation Queue
                        </h1>
                        <p className="text-surface-500 dark:text-surface-400 mt-1">Review flagged content before it goes live.</p>
                    </div>

                    <div className="px-4 py-2 bg-warning/10 text-warning rounded-lg border border-warning/20 font-bold text-sm flex items-center gap-2">
                        <AlertTriangle size={16} />
                        {pendingPosts.length} Pending Items
                    </div>
                </div>

                {pendingPosts.length === 0 ? (
                    <Card className="text-center py-24 border-dashed border-2 border-surface-200 dark:border-surface-700 bg-surface-50/50 dark:bg-surface-800/30">
                        <div className="w-20 h-20 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-6">
                            <Check className="h-10 w-10 text-success" />
                        </div>
                        <h3 className="text-xl font-bold text-surface-900 dark:text-white mb-2">All Caught Up!</h3>
                        <p className="text-surface-500 dark:text-surface-400">No posts pending review at the moment.</p>
                    </Card>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <AnimatePresence mode="popLayout">
                            {pendingPosts.map(post => (
                                <Card
                                    key={post.id}
                                    className="overflow-hidden border-surface-200 dark:border-surface-700 hover:shadow-xl transition-shadow duration-300"
                                >
                                    <div className="relative group">
                                        <div className="aspect-[4/3] overflow-hidden">
                                            <img
                                                src={post.imageUrl}
                                                alt="Flagged content"
                                                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                                            />
                                        </div>
                                        <div className="absolute top-4 right-4 bg-warning/90 backdrop-blur-md text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg flex items-center gap-1.5 border border-white/20">
                                            <AlertTriangle size={12} fill="currentColor" /> Flagged
                                        </div>
                                    </div>

                                    <div className="p-5">
                                        <div className="mb-5">
                                            <h4 className="text-xs font-bold text-surface-400 uppercase tracking-wider mb-2">Reason for Flag</h4>
                                            <div className="bg-error/5 border border-error/10 text-error font-medium p-3 rounded-lg text-sm leading-snug">
                                                "{post.flagReason || "Unspecified safety violation"}"
                                            </div>
                                        </div>

                                        <div className="mb-6 space-y-3">
                                            <div>
                                                <span className="text-xs font-bold text-surface-400 uppercase tracking-wider block mb-1">Caption</span>
                                                <p className="text-surface-700 dark:text-surface-200 text-sm font-medium italic">"{post.caption}"</p>
                                            </div>
                                            <div className="flex justify-between items-center text-xs text-surface-500 pt-3 border-t border-surface-100 dark:border-surface-700/50">
                                                <span className="flex items-center gap-1.5"><Shield size={12} className="text-surface-400" /> {post.userName}</span>
                                                <span className="flex items-center gap-1.5"><Calendar size={12} className="text-surface-400" /> {new Date(post.timestamp?.seconds * 1000).toLocaleDateString()}</span>
                                            </div>
                                        </div>

                                        <div className="grid grid-cols-2 gap-3">
                                            <Button
                                                onClick={() => handleReject(post)}
                                                variant="outline"
                                                className="w-full !border-error/30 !text-error hover:!bg-error/5"
                                                icon={<X size={16} />}
                                            >
                                                Reject
                                            </Button>
                                            <Button
                                                onClick={() => handleApprove(post.id)}
                                                variant="primary" // Assuming primary is green or we can override style
                                                className="w-full !bg-success hover:!bg-success/90 border-transparent"
                                                icon={<Check size={16} />}
                                            >
                                                Approve
                                            </Button>
                                        </div>
                                    </div>
                                </Card>
                            ))}
                        </AnimatePresence>
                    </div>
                )}
            </div>
        </AdminLayout>
    );
};

export default ModerationDashboard;
