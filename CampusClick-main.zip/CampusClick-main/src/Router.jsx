import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import Header from './components/Layout/Header';
import Footer from './components/Layout/Footer';
import LandingPage from './pages/LandingPage';
import { AboutUs, Security, Privacy, Terms, CookiesPolicy, Subscription, Support, SiteMap } from './pages/StaticPages';
import MasonryGrid from './components/MasonryGrid';

import AuthSelection from './pages/Auth/AuthSelection';
import ContributorRegister from './pages/Auth/ContributorRegister';
import AdminLogin from './pages/Admin/AdminLogin';
import AdminDashboard from './pages/Admin/AdminDashboard';
import ModerationDashboard from './pages/Admin/ModerationDashboard';
import UserManagement from './pages/Admin/UserManagement';
import AdminActivity from './pages/Admin/AdminActivity';
import Login from './pages/Auth/Login';
import ForgotPassword from './pages/Auth/ForgotPassword';
import Profile from './pages/Profile';
import Dashboard from './pages/Dashboard';
import NotFound from './pages/NotFound';

import TechHub from './pages/TechHub';
import CampusEvents from './pages/CampusEvents';
import EventDetails from './pages/EventDetails';
import Gallery from './pages/Gallery';
import Timeline from './pages/Timeline';
import Leaderboard from './pages/Leaderboard';
import Insights from './pages/Insights';
import FAQ from './pages/FAQ';

import RequireAuth from './components/Auth/RequireAuth';
import RequireAdmin from './components/Auth/RequireAdmin';
import PageTransition from './components/Layout/PageTransition';

const AppRouter = () => {
  const location = useLocation();

  return (
    <div className="flex flex-col min-h-screen transition-colors duration-300 bg-background-light dark:bg-background-dark text-surface-900 dark:text-surface-50">
      <Header />
      <main className={`flex-grow ${location.pathname === '/' ||
        location.pathname.startsWith('/admin/dashboard') ||
        location.pathname.startsWith('/admin/users') ||
        location.pathname.startsWith('/admin/moderation') ||
        location.pathname.startsWith('/admin/activity')
        ? ''
        : 'pt-24'
        }`}>
        <AnimatePresence mode="wait">
          <Routes location={location} key={location.pathname}>
            <Route path="/" element={<PageTransition><LandingPage /></PageTransition>} />
            <Route path="/admin" element={<PageTransition><AdminLogin /></PageTransition>} />
            <Route path="/admin/dashboard" element={
              <RequireAdmin>
                <PageTransition><AdminDashboard /></PageTransition>
              </RequireAdmin>
            } />
            <Route path="/admin/moderation" element={
              <RequireAdmin>
                <PageTransition><ModerationDashboard /></PageTransition>
              </RequireAdmin>
            } />
            <Route path="/admin/users" element={
              <RequireAdmin>
                <PageTransition><UserManagement /></PageTransition>
              </RequireAdmin>
            } />
            <Route path="/admin/activity" element={
              <RequireAdmin>
                <PageTransition><AdminActivity /></PageTransition>
              </RequireAdmin>
            } />

            {/* Main Features */}
            <Route path="/gallery" element={
              <PageTransition>
                <Gallery />
              </PageTransition>
            } />
            <Route path="/events" element={<PageTransition><CampusEvents /></PageTransition>} />
            <Route path="/events/:id" element={<PageTransition><EventDetails /></PageTransition>} />
            <Route path="/tech-hub" element={<PageTransition><TechHub /></PageTransition>} />

            {/* New Pages */}
            <Route path="/timeline" element={<PageTransition><Timeline /></PageTransition>} />
            <Route path="/leaderboard" element={<PageTransition><Leaderboard /></PageTransition>} />
            <Route path="/insights" element={<PageTransition><Insights /></PageTransition>} />
            <Route path="/faq" element={<PageTransition><FAQ /></PageTransition>} />

            <Route path="/auth/selection" element={<PageTransition><AuthSelection /></PageTransition>} />
            <Route path="/auth/register" element={<PageTransition><Login /></PageTransition>} />
            <Route path="/auth/login" element={<PageTransition><Login /></PageTransition>} />
            <Route path="/auth/forgot-password" element={<PageTransition><ForgotPassword /></PageTransition>} />

            <Route path="/dashboard" element={
              <RequireAuth>
                <PageTransition><Dashboard /></PageTransition>
              </RequireAuth>
            } />
            <Route path="/profile" element={
              <RequireAuth>
                <PageTransition><Profile /></PageTransition>
              </RequireAuth>
            } />

            {/* Static Pages */}
            <Route path="/about" element={<PageTransition><AboutUs /></PageTransition>} />
            <Route path="/contact" element={<PageTransition><Support /></PageTransition>} />
            <Route path="/help" element={<PageTransition><Support /></PageTransition>} />
            <Route path="/terms" element={<PageTransition><Terms /></PageTransition>} />
            <Route path="/cookies" element={<PageTransition><CookiesPolicy /></PageTransition>} />
            <Route path="/privacy" element={<PageTransition><Privacy /></PageTransition>} />
            <Route path="/security" element={<PageTransition><Security /></PageTransition>} />
            <Route path="/subscription" element={<PageTransition><Subscription /></PageTransition>} />
            <Route path="/features" element={<PageTransition><AboutUs /></PageTransition>} />
            <Route path="/sitemap" element={<PageTransition><SiteMap /></PageTransition>} />

            {/* Catch all - 404 */}
            <Route path="*" element={<PageTransition><NotFound /></PageTransition>} />
          </Routes>
        </AnimatePresence>
      </main>
      <Footer />
    </div>
  );
};

export default AppRouter;
