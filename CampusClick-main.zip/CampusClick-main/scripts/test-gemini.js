import { GoogleGenerativeAI } from "@google/generative-ai";
import dotenv from 'dotenv';
import fs from 'fs';
dotenv.config();

const API_KEY = process.env.VITE_GEMINI_API_KEY;

if (!API_KEY) {
  console.error("Error: VITE_GEMINI_API_KEY is missing in environment variables.");
  process.exit(1);
}

const genAI = new GoogleGenerativeAI(API_KEY);

async function main() {
  let logs = "";
  try {
    const fetch = await import('node-fetch').then(m => m.default).catch(() => global.fetch);
    
    logs += "Attempting to list models via REST API...\n";
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${API_KEY}`);
    
    if (response.ok) {
        const data = await response.json();
        logs += "SUCCESS: Retrieved model list:\n";
        if (data.models) {
            data.models.forEach(m => logs += ` - ${m.name} (methods: ${m.supportedGenerationMethods})\n`);
        } else {
            logs += JSON.stringify(data, null, 2);
        }
    } else {
        const errorText = await response.text();
        logs += `FAILED to list models via REST. Status: ${response.status}\nResponse: ${errorText}\n`;
    }

  } catch (error) {
    logs += `Global Error: ${error.message}\n`;
    console.error("Global Error:", error);
  }
  
  // Write to file
  fs.writeFileSync('scripts/test-result.txt', logs);
  console.log("Docs written to scripts/test-result.txt");
}

main();
